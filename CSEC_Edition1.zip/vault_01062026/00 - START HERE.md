# 🛡️ START HERE — Peta Belajar Cyber Security

Selamat datang di vault belajarmu. Ini adalah **peta utama (Map of Content)** untuk seluruh materi. Mulai dari sini setiap kali kamu bingung "habis ini ngapain?".

> [!tip] Baru pertama buka? Baca [[README]] dulu (cara install Obsidian, alur belajar, disclaimer etika).

> [!info] Cara pakai vault ini
> - Setiap folder bernomor adalah satu **tahap belajar**. Ikuti urutannya: `01 → 02 / 03`.
> - File **(MOC)** di tiap folder adalah daftar isi + urutan belajar folder itu.
> - Kata yang dikurung **dua siku** (wikilink) adalah **link** ke catatan lain — klik untuk lompat.
> - Buka **Graph View** (ikon lingkaran-titik di kiri) untuk melihat semua koneksi sebagai jaring. Itu cara terbaik melihat "peta" cyber security secara utuh.
> - Istilah asing? Cek `[[Glosarium Istilah]]`.

---

## 🧭 Dua Jalur (Path)

Cyber security punya banyak peran, tapi dua yang paling utama:

| | 🔴 **Red Team** | 🔵 **Blue Team** |
|---|---|---|
| Peran | Menyerang (offensive) | Bertahan (defensive) |
| Tujuan | Menemukan celah dengan **berpikir seperti penyerang** | Mendeteksi, mencegah, & merespons serangan |
| Contoh job | Penetration Tester, Red Teamer, Bug Hunter | SOC Analyst, Incident Responder, Threat Hunter |
| Mindset | "Bagaimana cara masuk?" | "Bagaimana cara menangkap & menghentikan?" |

Keduanya **dua sisi mata uang yang sama**. Memahami satu membuatmu lebih jago di yang lain. Itulah kenapa banyak catatan saling terhubung antar-jalur. (Pertemuan keduanya disebut [[Purple Team]].)

---

## 📚 Urutan Belajar yang Disarankan

### Tahap 1 — Fondasi (WAJIB dulu, untuk semua orang)
Jangan lewati ini. Tanpa fondasi, materi red/blue akan terasa seperti sihir.

➡️ **Mulai di:** [[Fondasi (MOC)]]

### Tahap 2 — Pilih jalurmu (atau pelajari keduanya)

- 🔴 **Jalur menyerang:** [[Red Team (MOC)]]
- 🔵 **Jalur bertahan:** [[Blue Team (MOC)]]

### Tahap 3 — Materi lintas-jalur
- [[Threat Modeling]] — berpikir sistematis soal ancaman
- [[Purple Team]] — kolaborasi red + blue
- [[Sumber Belajar & Platform Latihan]] — tempat latihan gratis (TryHackMe, HTB, dll)
- [[Glosarium Istilah]] — kamus istilah

---

## ⚖️ Etika & Legalitas (BACA INI)

> [!warning] Hanya hack sistem yang kamu punya izin tertulis untuk diuji.
> Semua teknik di vault ini untuk **belajar dan pengujian yang sah** (lab pribadi, platform CTF, atau klien dengan kontrak). Menyerang sistem tanpa izin adalah **ilegal** di hampir semua negara (di Indonesia: UU ITE). Latihan selalu di lab sendiri atau platform legal seperti yang ada di [[Setup Lab (Virtualisasi)]] dan [[Sumber Belajar & Platform Latihan]].

---

## 🗺️ Daftar Isi Lengkap

- **01 - Fondasi** → [[Fondasi (MOC)]]
- **02 - Red Team** → [[Red Team (MOC)]]
- **03 - Blue Team** → [[Blue Team (MOC)]]
- **04 - Bersama** → [[Threat Modeling]] · [[Purple Team]] · [[Sumber Belajar & Platform Latihan]] · [[Glosarium Istilah]]
- **05 - Templates** → [[Template Catatan Materi]]
