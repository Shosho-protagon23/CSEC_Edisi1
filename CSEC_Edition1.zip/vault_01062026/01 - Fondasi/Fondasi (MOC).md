# 🏗️ Fondasi (MOC)

> [!summary] Ringkasan
> Tahap pertama dan **wajib** untuk semua orang. Sebelum bisa menyerang ([[Red Team (MOC)]]) atau bertahan ([[Blue Team (MOC)]]), kamu harus paham cara komputer & jaringan bekerja, dan prinsip dasar keamanan.

⬅️ Kembali ke [[00 - START HERE]]

---

## 🎯 Kenapa fondasi dulu?

Hacking dan defending pada dasarnya adalah **memahami sistem lebih dalam daripada orang yang membangunnya**. Kamu tidak bisa mengeksploitasi atau melindungi sesuatu yang tidak kamu pahami. Pemula yang langsung loncat ke "cara hack WiFi" biasanya stuck karena tidak paham apa yang sebenarnya terjadi.

## 📋 Urutan Belajar

1. [[Konsep Dasar Keamanan (CIA Triad)]] — fondasi filosofis: apa itu "aman"?
2. [[Jaringan Komputer]] — bagaimana data berpindah antar komputer.
3. [[Model OSI & TCP-IP]] — peta lapisan komunikasi jaringan.
4. [[Linux Dasar untuk Security]] — OS utama hacker & banyak server.
5. [[Windows & Active Directory Dasar]] — target paling umum di dunia korporat.
6. [[Kriptografi Dasar]] — bagaimana data diamankan & dibobol.
7. [[Setup Lab (Virtualisasi)]] — bangun lab aman untuk latihan.
   - Jaringan lab: [[Lab — Setup Jaringan Lab]] (GUI) · [[Lab — Setup Jaringan via CLI]] (terminal, opsional)
   - Setup per-platform: [[Lab — Metasploitable]] · [[Lab — VulnHub]] (contoh: [[Lab — Mr-Robot (Setup)|Mr-Robot]] · [[Lab — Kioptrix (Setup)|Kioptrix]] · [[Lab — DC-1 (Setup)|DC-1]] · [[Lab — DC-2 (Setup)|DC-2]] · [[Lab — Symfonos 1 (Setup)|Symfonos 1]] · [[Lab — Brainpan (Setup)|Brainpan]]) · [[Lab — Vulnyx]] · [[Lab — Platform Lab Lainnya]]
   - Lab Active Directory: [[Lab — AD Lab Lokal (GOAD)]]
   - Lab aplikasi mobile: [[Lab — Mobile (Android-iOS) Hacking]] (APK/IPA, Frida, intercept API, OWASP MASVS)
   - Lab jaringan vulnerable: [[Lab — Jaringan Vulnerable (Networking)]] (GNS3/EVE-NG/CML/Packet Tracer/Containerlab + [[Lab — Serangan Jaringan (Network Pentest)|serangan]] & [[Lab — Hardening Perangkat Jaringan|hardening]] L2/L3) · nirkabel: [[Lab — WiFi Hacking (Wireless)]] · IoT/embedded: [[Lab — IoT & Embedded Hacking]] · industri: [[Lab — OT-ICS-SCADA Hacking]]

## 🔗 Setelah ini

Setelah nyaman dengan ketujuh topik di atas, lanjut ke salah satu (atau keduanya):

- 🔴 [[Red Team (MOC)]]
- 🔵 [[Blue Team (MOC)]]

## 📖 Sumber fondasi terbaik (gratis)

- **Professor Messer — Network+ / Security+** (YouTube) — penjelasan fondasi paling jernih untuk pemula.
- **TryHackMe — "Pre Security" & "Cyber Security 101" path** — interaktif, dari nol. https://tryhackme.com
- **Cisco Networking Academy — Networking Basics** (gratis) — https://www.netacad.com
