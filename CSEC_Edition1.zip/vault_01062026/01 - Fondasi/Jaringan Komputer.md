# 🌐 Jaringan Komputer

> [!summary] Ringkasan
> Hampir semua serangan terjadi lewat jaringan. Memahami IP, port, protokol, dan cara paket berpindah adalah skill #1 yang membedakan pemula yang stuck dengan yang berkembang.

**Bagian dari:** [[Fondasi (MOC)]]
**Lanjut ke:** [[Model OSI & TCP-IP]]

---

## 🧠 Konsep Inti

### IP Address
Alamat unik tiap perangkat di jaringan.
- **IPv4**: `192.168.1.10` (4 angka 0–255). **Private** (`10.x`, `172.16–31.x`, `192.168.x` — untuk jaringan lokal) vs **Public** (di internet).
- **IPv6**: lebih panjang (`2001:db8::1`), dibuat karena IPv4 habis.

### Port
Satu IP punya 65535 port. Port = "pintu" untuk layanan berbeda. Yang wajib hafal:

| Port | Layanan | Catatan keamanan |
|---|---|---|
| 21 | FTP | transfer file, sering tanpa enkripsi |
| 22 | SSH | remote login terenkripsi (target umum brute-force) |
| 23 | Telnet | remote login **tanpa** enkripsi (berbahaya) |
| 25 | SMTP | kirim email |
| 53 | DNS | terjemahkan nama domain ↔ IP |
| 80 | HTTP | web (tidak terenkripsi) |
| 443 | HTTPS | web terenkripsi |
| 445 | SMB | file sharing Windows (sering jadi celah) |
| 3389 | RDP | Remote Desktop Windows |

### Protokol penting
- **TCP** — andal, ada "jabat tangan" (3-way handshake: SYN → SYN/ACK → ACK). Untuk web, email, SSH.
- **UDP** — cepat, tanpa jaminan. Untuk DNS, streaming, game.
- **DNS** — menerjemahkan `google.com` → IP. Sering disalahgunakan (DNS spoofing, exfiltrasi data).
- **DHCP** — memberi IP otomatis ke perangkat.
- **ARP** — memetakan IP ↔ MAC address di jaringan lokal (rentan ARP spoofing).

### Jaringan nirkabel (WiFi)
Selain kabel, data juga berpindah lewat **radio**. WiFi (standar **802.11**) bekerja di Layer 1–2 dengan karakter khasnya sendiri: band/channel, frame management/data, dan keamanan WPA2/WPA3. Karena mediumnya udara (broadcast & bocor), keamanannya berbeda dari Ethernet. → Pendalaman: [[Jaringan Nirkabel & 802.11 (WiFi)]].

## ⚙️ Praktik

```bash
ip a                 # lihat IP perangkat (Linux)
ipconfig             # versi Windows
ping 8.8.8.8         # tes konektivitas
nslookup google.com  # cek DNS
netstat -tulpn       # lihat port yang terbuka di mesinmu
traceroute google.com  # lihat jalur paket (tracert di Windows)
```

## 🧰 Tools

- **Wireshark** — "menguping" paket jaringan (packet sniffer). Wajib dipelajari. → dipakai juga di [[Log Analysis & Monitoring]].
- **Nmap** — memetakan jaringan & port → inti dari [[Scanning & Enumeration]].
- **tcpdump** — packet capture via command line.

## 🔗 Kaitan

- Detail lapisan: [[Model OSI & TCP-IP]].
- Nirkabel/WiFi: [[Jaringan Nirkabel & 802.11 (WiFi)]].
- Sisi Red: memetakan jaringan target di [[Scanning & Enumeration]].
- Sisi Blue: memantau & menyaring trafik di [[Network Security (Firewall, IDS-IPS)]].

## 🎯 Latihan

- **TryHackMe — "Network Fundamentals"** (Intro to Networking, What is Networking).

## 📖 Sumber

- **Professor Messer — Network+** (YouTube) — gratis & sangat jelas.
- **Cloudflare Learning Center** — https://www.cloudflare.com/learning/ (penjelasan protokol singkat & akurat).
