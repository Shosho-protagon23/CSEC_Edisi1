# 📡 Jaringan Nirkabel & 802.11 (WiFi)

> [!summary] Ringkasan
> Pendalaman sisi **nirkabel** dari [[Jaringan Komputer]]: bagaimana WiFi sebenarnya bekerja di level **radio & frame 802.11** — bukan cara menyerangnya (itu di [[Lab — WiFi Hacking (Wireless)]]), tapi **teori** yang harus kamu pahami lebih dulu. Tahu beda **band/channel**, jenis **frame** (management/control/data), proses **asosiasi** klien ke AP, cara medium dibagi (**CSMA/CA**), dan evolusi keamanan **WEP→WPA→WPA2→WPA3**. Ini fondasi yang membuat serangan & pertahanan WiFi masuk akal.

**Bagian dari:** [[Fondasi (MOC)]] · pendalaman [[Jaringan Komputer]]
**Prasyarat:** [[Jaringan Komputer]], [[Model OSI & TCP-IP]] (terutama Layer 1–2)

---

## 🧠 Konsep Inti

### Apa itu 802.11
**IEEE 802.11** = keluarga standar untuk WLAN (WiFi). Ia hanya mendefinisikan **Layer 1 (PHY/radio)** dan **Layer 2 (MAC)** dari [[Model OSI & TCP-IP|model OSI]] — di atasnya tetap IP/TCP yang sama seperti jaringan kabel. Beda WiFi dari Ethernet: medium-nya **udara (broadcast radio)** yang dipakai bersama dan **bocor** ke sekitar → ini akar banyak masalah keamanannya.

### Band & Channel
WiFi memancar di pita frekuensi (band) yang dibagi jadi **channel**:

| Band | Karakter | Channel |
|---|---|---|
| **2.4 GHz** | jangkauan jauh, tembus tembok, **padat/berisik** | 1–13 (hanya **1, 6, 11** yang tak tumpang tindih) |
| **5 GHz** | lebih cepat, jangkauan pendek, banyak channel | banyak (36, 40, …) |
| **6 GHz** (WiFi 6E/7) | terbaru, lega, perangkat baru | sangat banyak |

> Penting untuk serangan/sniffing: kartu monitor mendengar **satu channel** pada satu waktu — kamu harus tahu channel target ([[Lab — WiFi Hacking (Wireless)]] memakai `airodump -c`).

### Generasi 802.11 (singkat)
`b/g` (2.4GHz lama) → `a` (5GHz) → `n` (WiFi 4, dual-band, MIMO) → `ac` (WiFi 5) → `ax` (WiFi 6/6E) → `be` (WiFi 7). Makin baru = makin cepat & efisien; relevan untuk kompatibilitas adapter & mode monitor.

### Identitas jaringan: SSID / BSSID / ESSID
- **SSID** — nama jaringan yang kamu lihat (mis. `KantorWiFi`).
- **BSSID** — **MAC address radio AP** (alamat unik perangkat AP itu). Inilah yang dipakai untuk "mengunci" target.
- **ESSID** — SSID yang sama dipakai banyak AP (roaming) → satu jaringan logis, banyak BSSID.

### Jenis Frame 802.11 (inti yang wajib paham)
Berbeda dari Ethernet, WiFi punya 3 kelas frame:

| Kelas | Fungsi | Contoh & relevansi keamanan |
|---|---|---|
| **Management** | kelola koneksi | **Beacon** (AP mengumumkan diri), **Probe** (klien mencari), **Auth/Assoc**, **Deauth/Disassoc** ← dipakai serangan deauth |
| **Control** | atur akses medium | RTS/CTS, **ACK** |
| **Data** | bawa payload (IP/TCP) | frame berisi data sesungguhnya |

> **Deauth/disassoc** adalah frame management yang (pada WPA2 lama) **tidak terlindungi** → siapa pun bisa memalsukannya untuk memutus klien. Inilah yang ditambal oleh **802.11w / PMF** (lihat keamanan di bawah).

### Cara klien terhubung (proses asosiasi)
```text
1. Discovery  : klien dengar Beacon AP, atau kirim Probe Request → Probe Response
2. Authentication (802.11) : "open system" (sekadar formalitas di WPA2/3)
3. Association : klien minta gabung → AP beri Association ID
4. (WPA2/3) 4-way handshake : buktikan tahu passphrase & turunkan kunci sesi
   → ini frame yang "ditangkap" untuk crack offline
```

### Berbagi medium: CSMA/CA
WiFi tak bisa kirim & dengar sekaligus, jadi pakai **CSMA/CA** (*Collision Avoidance*): "dengar dulu, kalau senyap baru kirim", dengan ACK & opsional RTS/CTS. Beda dari Ethernet kabel yang pakai CSMA/CD. Akibatnya WiFi rentan **interferensi** dan mudah di-DoS di level radio (jamming, flood).

### Evolusi Keamanan WiFi (teori)
| Protokol | Inti | Status |
|---|---|---|
| **WEP** | RC4 + IV 24-bit lemah | **rusak total**, jangan dipakai |
| **WPA** | TKIP (tambalan WEP) | usang |
| **WPA2** | **AES-CCMP** + 4-way handshake; PSK (rumah) / Enterprise 802.1X | standar lama yang masih luas |
| **WPA3** | **SAE** (Dragonfly) — tahan crack offline; **PMF wajib**; forward secrecy | terkini, disarankan |

- **PSK (Personal)** — satu passphrase bersama; keamanan = kekuatan passphrase.
- **Enterprise (802.1X/EAP + RADIUS)** — tiap user kredensial sendiri, jauh lebih kuat.
- **PMF (802.11w)** — melindungi frame management (anti deauth spoofing); wajib di WPA3.

## ⚙️ Praktik (mengamati, bukan menyerang)

```bash
# Lihat jaringan WiFi di sekitar (Linux)
nmcli dev wifi list                 # SSID, channel, sinyal, security
iw dev                              # interface wireless & mode
iwlist wlan0 scan | grep -E "ESSID|Frequency|Encryption"
# Detail kemampuan kartu (band/channel yang didukung)
iw list | less
```
> Untuk benar-benar melihat **frame 802.11** (beacon, probe) butuh **monitor mode** + Wireshark — itu masuk ranah [[Lab — WiFi Hacking (Wireless)]].

## 🧰 Tools

- **nmcli / iw / iwlist** — lihat jaringan & kemampuan kartu (bawaan Linux).
- **Wireshark** — bedah frame 802.11 (perlu monitor mode) → kaitan [[Jaringan Komputer]].
- **WiFi analyzer** (HP/desktop) — visualisasi channel & sinyal (memahami band/channel).

## 🔗 Kaitan

- Dasar yang diperdalam: [[Jaringan Komputer]] (IP/port/protokol) · lapisan: [[Model OSI & TCP-IP]] (802.11 = L1–L2).
- **Penerapan ofensif/defensif:** [[Lab — WiFi Hacking (Wireless)]] (monitor mode, capture handshake, evil twin, hardening WPA3) — teori di sini adalah prasyaratnya.
- **Sisi Blue ↔** [[Network Security (Firewall, IDS-IPS)]] & [[Hardening & Vulnerability Management]] (WPA3, PMF, 802.1X), deteksi rogue AP di [[Network Security Lanjutan (NSM-NDR)]].
- Kripto di balik WPA: [[Kriptografi Dasar]] (AES, handshake/turunan kunci).

## 🎯 Latihan

- Jalankan `nmcli dev wifi list` (atau WiFi analyzer di HP): catat **SSID, BSSID, channel, dan tipe keamanan** jaringan di sekitarmu — kenali mana 2.4 GHz vs 5 GHz dan mana yang masih WPA2 vs WPA3.
- Gambar diagram **proses asosiasi** klien→AP (discovery → auth → assoc → 4-way handshake) dengan kata-katamu sendiri.
- Jelaskan kenapa **frame Deauth** berbahaya di WPA2 dan bagaimana **PMF (802.11w)** menambalnya.

## 📖 Sumber

- **IEEE 802.11** — standar resmi (ringkasan di Wikipedia/Cloudflare Learning).
- **Wi-Fi Alliance** — WPA2/WPA3 — https://www.wi-fi.org/discover-wi-fi/security
- **Professor Messer — Network+ (Wireless)** (YouTube).
- **CWNP — Certified Wireless** (materi mendalam 802.11).
