# 🔐 Konsep Dasar Keamanan (CIA Triad)

> [!summary] Ringkasan
> CIA Triad adalah tiga pilar yang mendefinisikan apa artinya "aman": **Confidentiality, Integrity, Availability**. Hampir setiap serangan dan setiap pertahanan bisa dijelaskan sebagai usaha merusak atau melindungi salah satu pilar ini.

**Bagian dari:** [[Fondasi (MOC)]]

---

## 🧠 Konsep Inti

### 1. Confidentiality (Kerahasiaan)
Hanya pihak yang berhak yang boleh mengakses data. Contoh dilindungi: enkripsi, password, hak akses. Contoh dirusak: data dicuri (data breach), penyadapan.

### 2. Integrity (Integritas)
Data tidak boleh diubah secara tidak sah. Kamu harus yakin data yang kamu terima = data asli. Dilindungi: hashing, digital signature ([[Kriptografi Dasar]]). Dirusak: serangan man-in-the-middle yang mengubah transaksi, tampering file.

### 3. Availability (Ketersediaan)
Sistem & data harus bisa diakses saat dibutuhkan. Dilindungi: backup, redundansi, anti-DDoS. Dirusak: serangan **DoS/DDoS** (membanjiri server hingga down), ransomware (mengunci data).

> [!tip] Cara pakai
> Saat menganalisis serangan, tanya: "pilar mana yang diserang?" Ransomware = Availability (+ kadang Confidentiality). Pencurian password = Confidentiality. Ini membantumu memahami **dampak**, bukan cuma teknik.

## ⚙️ Konsep pendukung penting

- **AAA**: *Authentication* (kamu siapa?), *Authorization* (kamu boleh apa?), *Accounting* (apa yang kamu lakukan? — logging, lihat [[Log Analysis & Monitoring]]).
- **Non-repudiation**: pelaku tidak bisa menyangkal perbuatannya (didukung digital signature & log).
- **Least Privilege**: beri akses seminimal mungkin yang dibutuhkan. Prinsip ini melawan [[Privilege Escalation]] dan dasar dari [[Hardening & Vulnerability Management]].
- **Defense in Depth**: berlapis-lapis pertahanan → [[Defense in Depth & Security Architecture]].

## 🔗 Kaitan

- Pondasi untuk semua: [[Red Team (MOC)]] menyerang pilar; [[Blue Team (MOC)]] melindunginya.
- Mekanisme teknisnya banyak di [[Kriptografi Dasar]].
- Cara berpikir terstruktur soal ancaman: [[Threat Modeling]].

## 🎯 Latihan

- **TryHackMe — "Security Principles"** dan room di path *Cyber Security 101*.

## 📖 Sumber

- **NIST** mendefinisikan ketiga pilar ini secara formal — https://csrc.nist.gov/glossary/term/cia_triad
- **Professor Messer — Security+ SY0-701** (YouTube), bagian "Fundamentals of Security".
