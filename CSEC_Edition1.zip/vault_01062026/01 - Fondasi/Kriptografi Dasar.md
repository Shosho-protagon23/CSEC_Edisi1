# 🔑 Kriptografi Dasar

> [!summary] Ringkasan
> Kriptografi adalah ilmu mengamankan informasi. Ia menopang dua dari tiga pilar [[Konsep Dasar Keamanan (CIA Triad)|CIA]]: Confidentiality (enkripsi) & Integrity (hashing/signature). Memahaminya penting agar tahu kapan data benar-benar aman vs cuma terlihat aman.

**Bagian dari:** [[Fondasi (MOC)]]

---

## 🧠 Konsep Inti

### 1. Encoding ≠ Encryption ≠ Hashing (sering tertukar!)
- **Encoding** (mis. Base64) — mengubah format, **bukan** keamanan. Bisa dibalik tanpa kunci. Jangan pernah anggap Base64 = aman.
- **Encryption** — mengacak data dengan **kunci**; bisa dibalik (decrypt) hanya dengan kunci yang benar.
- **Hashing** — fungsi **satu arah**; tidak bisa dibalik. Untuk verifikasi integritas & menyimpan password.

### 2. Enkripsi: Symmetric vs Asymmetric
- **Symmetric** — satu kunci untuk enkripsi & dekripsi. Cepat. Contoh: **AES**. Masalah: cara berbagi kunci dengan aman?
- **Asymmetric** — sepasang kunci: **public key** (untuk enkripsi/verifikasi) & **private key** (untuk dekripsi/menandatangani). Contoh: **RSA**, **ECC**. Inti dari HTTPS & SSH.

### 3. Hashing
- Algoritma: **MD5** & **SHA-1** sudah lemah (jangan dipakai), gunakan **SHA-256** ke atas. Untuk password: **bcrypt**, **Argon2**.
- **Salt** — data acak ditambahkan sebelum hashing agar dua password sama tidak menghasilkan hash sama (melawan *rainbow table*).
- Hash bocor bisa diserang offline → [[Password Attacks]].

### 4. TLS/HTTPS (gabungan semua di atas)
HTTPS pakai asymmetric untuk bertukar kunci, lalu symmetric untuk kecepatan. **Digital certificate** + **Certificate Authority (CA)** memastikan kamu bicara dengan server asli (melawan man-in-the-middle).

## ⚙️ Praktik

```bash
echo -n "halo" | base64                 # encoding (bukan enkripsi!)
echo -n "halo" | sha256sum              # hashing
openssl enc -aes-256-cbc -in f.txt -out f.enc   # enkripsi AES
ssh-keygen -t ed25519                    # buat pasangan kunci asymmetric
hashid '5d41402abc4b2a76b9719d911017c592'   # tebak jenis hash
```

## 🧰 Tools

- **CyberChef** — "pisau Swiss" encode/decode/enkripsi di browser → https://gchq.github.io/CyberChef/
- **hashcat / John the Ripper** — memecahkan hash → [[Password Attacks]].
- **OpenSSL** — toolkit kripto command line.

## 🔗 Kaitan

- Menopang [[Konsep Dasar Keamanan (CIA Triad)]].
- Sisi Red: memecahkan hash di [[Password Attacks]]; menyalahgunakan kripto lemah di [[Web Application Hacking (OWASP Top 10)]] (kategori *Cryptographic Failures*).
- Sisi Blue: memastikan enkripsi benar saat [[Hardening & Vulnerability Management|hardening]].

## 🎯 Latihan

- **TryHackMe — "Cryptography Basics"**, **"Hashing Basics"**.
- Mainkan **CyberChef** dengan teks acak untuk merasakan encode vs encrypt.

## 📖 Sumber

- **Computerphile** (YouTube) — video singkat soal RSA, AES, hashing, sangat jelas.
- **NIST — Cryptographic Standards** — https://csrc.nist.gov/projects/cryptographic-standards-and-guidelines
