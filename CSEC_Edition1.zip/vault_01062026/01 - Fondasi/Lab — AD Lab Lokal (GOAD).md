# 🏰 Lab — AD Lab Lokal (GOAD)

> [!summary] Ringkasan
> **GOAD (Game Of Active Directory)** adalah lab **Active Directory sengaja-rentan** buatan Orange Cyberdefense: beberapa server Windows + domain & forest yang sudah dikonfigurasi penuh salah-konfigurasi (Kerberoasting, AS-REP, ACL, trust, dll.). Ini cara terbaik melatih [[Active Directory Attacks]] secara **lokal & offline** — tapi paling berat dan **bukan lab pertamamu**.

**Bagian dari:** [[Setup Lab (Virtualisasi)]]
**Prasyarat:** [[Windows & Active Directory Dasar]], [[Active Directory Attacks]], [[Lab — Setup Jaringan Lab]], nyaman dengan baris perintah.

---

> [!danger] Ini lab tingkat lanjut
> GOAD butuh **RAM besar**, unduhan **puluhan GB**, dan rantai tool (Vagrant + Ansible). Untuk **pemula AD**, mulai dulu di **TryHackMe "Attacktive Directory"** atau path *Compromising Active Directory* (lihat [[Active Directory Attacks]]). Datang ke GOAD setelah paham dasar serangan AD.

## 🧠 Konsep Inti

- GOAD = kumpulan **VM Windows Server** + **Vagrant** (membuat VM otomatis) + **Ansible** (mengisi & "merusak" konfigurasi AD).
- Ada beberapa **varian** sesuai kemampuan mesinmu:

| Varian | VM | RAM disarankan | Untuk |
|---|---|---|---|
| **GOAD** (full) | 5 | **24 GB+** | forest 2 domain + trust, paling lengkap |
| **GOAD-Light** | 3 | **~12 GB** | versi ringan, tetap kaya serangan |
| **NHA / mini / SCCM dll.** | 1–2 | bervariasi | lab fokus topik tertentu |

> [!tip] Mulai dari yang ringan
> Kecuali punya RAM ≥ 24 GB, pakai **GOAD-Light** dulu. Kamu tetap bisa latihan Kerberoasting, AS-REP, ACL abuse, dsb.

## ⚙️ Cara Kerja / Praktik

### 0. Cek prasyarat host
- **RAM**: minimal 12 GB (Light) / 24 GB+ (full). **Disk**: 50–120 GB kosong.
- **Virtualisasi (VT-x/AMD-V)** aktif di BIOS.
- Pilih **provider**: VirtualBox (paling mudah), VMware, atau **Proxmox/Ludus** (untuk yang punya server).

### 1. Pasang tooling
GOAD digerakkan oleh **Vagrant** + **Ansible**. Cara termudah & paling konsisten: jalankan installer dari Linux/WSL.
```bash
# Di Linux atau WSL2 (Ubuntu)
sudo apt update && sudo apt install -y git python3 python3-pip
# Vagrant + plugin (sesuai provider), lalu Ansible:
pip3 install ansible-core
# (ikuti requirements resmi GOAD untuk versi Vagrant & plugin yang cocok)
```
> [!note] Windows host
> Vagrant + VirtualBox bisa jalan langsung di Windows (PowerShell), tapi bagian **Ansible** lebih mulus dari **WSL2** atau VM Linux pengendali. Repo GOAD punya skrip `goad.sh` (Linux) & dukungan PowerShell.

### 2. Clone repo
```bash
git clone https://github.com/Orange-Cyberdefense/GOAD.git
cd GOAD
```

### 3. Pilih lab + provider, lalu deploy
GOAD versi baru memakai launcher `goad.sh` (interaktif):
```bash
./goad.sh
# di dalam: pilih
#   lab      -> GOAD-Light (atau GOAD)
#   provider -> virtualbox  (atau vmware / proxmox)
#   lalu jalankan: install
```
Atau manual: `vagrant up` (membuat VM) lalu jalankan **Ansible** untuk provisioning. Tahap ini **lama** (unduh + konfigurasi bisa 1–3 jam tergantung koneksi & CPU). Lihat README varian yang kamu pilih.

### 4. Jaringan & posisi Kali
- GOAD memakai jaringan **host-only/internal** sendiri (sering subnet **`192.168.56.0/24`** untuk VirtualBox). Atur sesuai [[Lab — Setup Jaringan Lab]].
- Tambahkan **Kali** ke jaringan host-only yang **sama** agar bisa menyerang.
```bash
# Dari Kali, temukan para Domain Controller / server
sudo netdiscover -i eth1 -r 192.168.56.0/24
nmap -p 88,389,445 192.168.56.0/24      # 88=Kerberos, 389=LDAP, 445=SMB → ciri DC
```

### 5. SNAPSHOT semua VM setelah deploy sukses
Provisioning itu mahal waktunya — **ambil snapshot tiap VM** begitu lab jadi, agar tak perlu mengulang.

### 6. Mulai menyerang (lihat [[Active Directory Attacks]])
```bash
# Enum awal
nxc smb 192.168.56.0/24                       # NetExec: sapu SMB/host
# Petakan jalur ke Domain Admin
bloodhound-python -d sevenkingdoms.local -u <user> -p <pass> -c all
# Kerberoasting
GetUserSPNs.py sevenkingdoms.local/<user>:<pass> -request
```

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **Ansible gagal di tengah** → jalankan ulang langkah provisioning; sering hanya butuh retry (jaringan/timeouts). Repo punya perintah untuk re-run provision per VM.
> - **VM tak dapat IP / Kali tak lihat DC** → salah jaringan host-only; samakan adapter (lihat [[Lab — Setup Jaringan Lab]]).
> - **Host kehabisan RAM / lemot** → pindah ke **GOAD-Light** atau jalankan hanya sebagian VM.
> - **Vagrant box gagal unduh** → cek koneksi & versi Vagrant/plugin sesuai requirements GOAD.

## 🧹 Membersihkan lab
```bash
vagrant destroy -f      # hapus semua VM lab (di folder GOAD)
# atau lewat ./goad.sh -> destroy
```

## 🧰 Tools

- **Vagrant** — otomasi pembuatan VM.
- **Ansible** — konfigurasi & "perusakan" AD otomatis.
- **VirtualBox / VMware / Proxmox** — provider VM.
- **NetExec (nxc), Impacket, BloodHound, Mimikatz** — senjata serangan AD ([[Active Directory Attacks]]).

## 🔗 Kaitan

- Inti latihannya: [[Active Directory Attacks]] (Kerberoasting, AS-REP, DCSync, BloodHound).
- Dasar AD: [[Windows & Active Directory Dasar]].
- Jaringan lab: [[Lab — Setup Jaringan Lab]] · hub: [[Setup Lab (Virtualisasi)]].
- **Sisi Blue ↔** [[Hardening & Vulnerability Management]] (mengeraskan AD) & [[Threat Hunting]] / [[Log Analysis & Monitoring]] — pakai GOAD untuk **melatih deteksi** serangan AD yang kamu jalankan sendiri.
- Alternatif lebih ringan tanpa setup: TryHackMe/HTB di [[Lab — Platform Lab Lainnya]] & [[Sumber Belajar & Platform Latihan]].

## 🎯 Latihan

- Deploy **GOAD-Light**, snapshot, lalu jalankan **BloodHound** untuk menemukan "shortest path to Domain Admin".
- Setelah dapat foothold, latih **Kerberoasting** lalu crack tiketnya (lihat command di [[Active Directory Attacks]]).
- **Mode Blue:** ulangi satu serangan sambil mengamati Event Log Windows (Event ID 4769 untuk Kerberoasting) → catat di [[Threat Hunting]].

## 📖 Sumber

- **GOAD — repo resmi**: https://github.com/Orange-Cyberdefense/GOAD
- **Orange Cyberdefense — seri blog "GOAD"** (penjelasan tiap serangan di lab).
- **The Hacker Recipes — AD**: https://www.thehacker.recipes/ad/
- **Ludus** (https://ludus.cloud) — cara modern men-deploy GOAD di server, bila punya hardware lebih.
