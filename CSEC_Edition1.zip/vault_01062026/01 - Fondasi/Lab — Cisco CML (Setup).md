# 📘 Lab — Cisco CML (Setup)

> [!summary] Ringkasan
> **Cisco Modeling Labs (CML)** — dulu bernama **VIRL** — adalah platform emulasi **resmi dari Cisco**. Keunggulan utamanya: **image IOS/IOS-XE/IOS-XR/NX-OS disertakan secara legal** dalam lisensi, jadi tak ada drama "cari image bajakan" seperti di GNS3/EVE-NG. Berbasis **server + browser** (mirip EVE-NG), punya editor topologi rapi dan integrasi otomasi. Berbayar (lisensi tahunan), namun ada **CML-Free** (gratis, jumlah node sangat terbatas) untuk belajar. Pilihan terbaik bila fokusmu **murni Cisco & ingin legal**.

**Bagian dari:** [[Lab — Jaringan Vulnerable (Networking)]]
**Prasyarat:** [[Lab — Jaringan Vulnerable (Networking)]], [[Setup Lab (Virtualisasi)]]

---

> [!tip] Kelebihan utama: image legal sudah termasuk
> Tidak seperti [[Lab — GNS3 (Setup)|GNS3]] / [[Lab — EVE-NG (Setup)|EVE-NG]] (kamu sediakan image sendiri), **CML membundel image Cisco resmi** (IOSv, IOSvL2, CSR1000v/Cat8000v, NX-OSv, IOS-XRv, ASAv). Inilah jalur **paling sah** untuk berlatih IOS asli.

## 🧠 Konsep Inti

- **Appliance VM** — CML dijalankan sebagai VM (di VMware ESXi/Workstation, atau bare-metal/Proxmox) lalu diakses via **browser**.
- **Node "definitions"** — image bawaan: `iosv` (router), `iosvl2` (switch L2), `csr1000v`/`cat8000v` (router XE), `nxosv9000`, `iosxrv9000`, `asav` (firewall), plus **external connector** & node Linux (Alpine/Ubuntu) untuk end host/penyerang.
- **PATty / External connectivity** — menghubungkan lab ke jaringan luar (mis. VM Kali) atau internet.
- **Editor + API** — punya REST API & integrasi (`virl2`/`pyATS`) → bagus untuk [[Lab — Containerlab (Setup)|otomasi jaringan]].

### Edisi
| Edisi | Node | Catatan |
|---|---|---|
| **CML-Free** | sangat sedikit (≈5 node kecil) | gratis, untuk coba & belajar dasar |
| **CML-Personal / Personal+** | lebih banyak | lisensi tahunan individu |
| **CML-Enterprise/Higher Ed** | besar | institusi/perusahaan |

## ⚙️ Cara Kerja / Praktik

### 1. Dapatkan & pasang
```text
1. Beli lisensi (atau daftar CML-Free) di https://developer.cisco.com/modeling-labs
2. Unduh file OVA CML + "reference platform" (berisi image node).
3. Import OVA ke hypervisor (VMware Workstation/ESXi disarankan; butuh
   nested virtualization untuk node QEMU di dalamnya).
4. Beri resource cukup (RAM 8 GB+; tiap node IOSv ~ 0.5–1 GB).
5. Boot → konfigurasi IP via console → buka https://<ip-cml> di browser
   (login admin yang kamu set saat instalasi).
```

### 2. Bangun topologi (di browser)
```text
- "Add Lab" → tarik node dari palet:
    IOSv (router) ×2, IOSvL2 (switch) ×1, Ubuntu/Alpine (PC) ×2
- Tarik link antar-node.
- Pilih node → "Edit config" untuk konfigurasi awal (Day-0), atau
  start dulu lalu buka console.
- Tombol "Start" (▶) → jalankan seluruh lab atau per-node.
```

### 3. Konfigurasi & verifikasi
```cisco
! Node IOSv — IOS asli, command lengkap
enable
configure terminal
 hostname R1
 interface GigabitEthernet0/1
  ip address 10.0.0.1 255.255.255.0
  no shutdown
 router ospf 1
  network 10.0.0.0 0.0.0.255 area 0
end
write memory
show ip ospf neighbor
show running-config
```

### 4. Sambungkan ke luar (Kali / internet)
```text
- Tambah node "External Connector" → pilih bridge ke interface host
  (mode "bridge" / "NAT").  Konsep host-only: [[Lab — Setup Jaringan Lab]].
- Atau jalankan node Linux (Ubuntu) lalu pasang tool di dalamnya,
  atau bridge ke VM Kali eksternal.
```

### 5. Snapshot / simpan state
```text
- CML menyimpan lab + konfigurasi node. Gunakan "Wipe" untuk reset
  node ke kondisi bersih, atau export lab (.yaml) untuk backup/share.
```

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **Node gagal start** → nested virtualization tidak aktif di VM CML, atau reference platform (image) belum di-upload.
> - **CML-Free mentok jumlah node** → memang dibatasi; rancang topologi minimal atau naik lisensi.
> - **Tak bisa akses internet dari lab** → External Connector belum dibridge ke interface yang benar.
> - **Lab berat** → IOSv/NX-OSv rakus RAM; kurangi node atau tambah resource VM CML.

## 🧰 Tools

- **Cisco CML / CML-Free** — platform emulasi resmi.
- **Image bundled**: IOSv, IOSvL2, CSR1000v/Cat8000v, NX-OSv9000, IOS-XRv9000, ASAv.
- **REST API / virl2 client / pyATS** — otomasi & verifikasi terprogram.
- **Wireshark** — packet capture pada link.

## 🔗 Kaitan

- Hub: [[Lab — Jaringan Vulnerable (Networking)]].
- Alternatif gratis tapi image sendiri: [[Lab — GNS3 (Setup)]], [[Lab — EVE-NG (Setup)]].
- Otomasi (pyATS/Ansible): [[Lab — Containerlab (Setup)]].
- Jaringan ke Kali: [[Lab — Setup Jaringan Lab]].
- Latihan: [[Lab — Serangan Jaringan (Network Pentest)]] · [[Lab — Hardening Perangkat Jaringan]].

## 🎯 Latihan

- Pasang **CML-Free**, bangun **2× IOSv + 1× IOSvL2 + 2 host Linux**, jalankan OSPF, verifikasi `show ip ospf neighbor`.
- Aktifkan **SSH + AAA + login local** di router (lihat [[Lab — Hardening Perangkat Jaringan]]) dan buktikan telnet ditolak.
- Pakai **pyATS** untuk `show ip route` semua node secara terprogram (cicipi otomasi).

## 📖 Sumber

- **Cisco Modeling Labs (CML)** — https://developer.cisco.com/modeling-labs/
- **Cisco DevNet — CML sandbox** (coba gratis tanpa beli).
- **pyATS / Genie** — https://developer.cisco.com/pyats/
