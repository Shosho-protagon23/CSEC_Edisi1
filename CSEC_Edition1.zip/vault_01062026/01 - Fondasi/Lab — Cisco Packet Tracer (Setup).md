# 🟢 Lab — Cisco Packet Tracer (Setup)

> [!summary] Ringkasan
> **Cisco Packet Tracer** adalah **simulator** jaringan gratis dari Cisco — meniru perilaku router/switch/PC dengan kode tiruan (bukan IOS asli). Paling **ramah pemula**, ringan (jalan di laptop biasa, ada versi Android/iOS), dan ideal untuk memahami **konsep CCNA**: IP, VLAN, routing, ACL. Keterbatasannya: bukan OS sungguhan → beberapa command/serangan tidak tersedia. Untuk latihan keamanan realistis, naik ke [[Lab — GNS3 (Setup)]].

**Bagian dari:** [[Lab — Jaringan Vulnerable (Networking)]]
**Prasyarat:** [[Jaringan Komputer]], [[Model OSI & TCP-IP]]

---

## 🧠 Konsep Inti

- **Simulator, bukan emulator** — Packet Tracer **tidak** menjalankan image IOS asli. Ia mensimulasikan subset perilaku & command IOS yang cukup untuk belajar. → tidak butuh image (semua built-in & legal).
- **Mode Simulation** — fitur khas: kamu bisa "memperlambat waktu" dan **melihat paket bergerak** hop-per-hop (PDU), termasuk isi header tiap layer OSI. Sangat bagus untuk memahami [[Model OSI & TCP-IP]].
- **Keterbatasan untuk keamanan** — tidak bisa menjalankan tool serangan nyata (tak ada Linux/Kali asli di dalamnya). Cocok untuk *konsep* serangan/mitigasi (port-security, DHCP snooping, ACL), bukan eksploitasi sungguhan.

## ⚙️ Cara Kerja / Praktik

### 1. Unduh & pasang (butuh akun gratis)
```text
1. Buat akun gratis di Cisco Networking Academy: https://www.netacad.com
2. Daftar course gratis "Getting Started with Cisco Packet Tracer"
3. Unduh installer (Windows/Linux/macOS) dari dashboard → pasang
4. Login pertama kali pakai akun NetAcad yang sama
```
> Tanpa login NetAcad, aplikasi hanya jalan "guest" dengan batas penyimpanan. Akun gratis menghilangkan batas itu.

### 2. Bangun topologi pertama
```text
- Seret perangkat dari panel kiri-bawah:
    Router (mis. 2911) ×2, Switch (2960) ×1, PC ×2
- Pakai kabel "Copper Straight-Through" (PC↔switch, switch↔router)
  dan "Copper Cross-Over" / Serial untuk router↔router
- Klik perangkat → tab "CLI" untuk mengetik konfigurasi IOS
```

### 3. Konfigurasi dasar IOS (sama persis seperti perangkat asli)
```cisco
enable
configure terminal
 hostname R1
 interface gigabitEthernet 0/0
  ip address 192.168.1.1 255.255.255.0
  no shutdown
 exit
 ip route 192.168.2.0 255.255.255.0 10.0.0.2     ! static route
end
write memory                                      ! simpan config
show ip interface brief                           ! verifikasi
show ip route
```

### 4. Uji konektivitas
```text
- Klik PC → Desktop → Command Prompt:
    ipconfig
    ping 192.168.2.10        (PC di sisi lain)
- Atau pakai mode "Simulation" (kanan bawah) → klik "Auto Capture/Play"
  untuk menonton paket ICMP melintasi router hop-demi-hop.
```

### 5. Latihan keamanan konsep (yang bisa di Packet Tracer)
```cisco
! Port-security: batasi MAC per port (lawan MAC flooding)
interface fa0/1
 switchport mode access
 switchport port-security
 switchport port-security maximum 1
 switchport port-security violation shutdown
! DHCP snooping & SSH juga didukung sebagian → lihat
! [[Lab — Hardening Perangkat Jaringan]]
```

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **Tidak bisa login / fitur terkunci** → pastikan login dengan akun NetAcad (bukan guest).
> - **Ping gagal padahal IP benar** → cek `no shutdown` di interface, kabel benar (straight vs cross), dan default gateway di PC.
> - **Command IOS ditolak** → Packet Tracer hanya dukung subset command; bila butuh command itu, pakai emulator ([[Lab — GNS3 (Setup)]]).

## 🧰 Tools

- **Cisco Packet Tracer** — simulator utama.
- **Mode Simulation (PDU)** — visualisasi paket per-layer.
- Built-in: PC, Server, Router, Switch, Wireless, IoT (tanpa image eksternal).

## 🔗 Kaitan

- Hub: [[Lab — Jaringan Vulnerable (Networking)]].
- Naik kelas ke OS asli: [[Lab — GNS3 (Setup)]], [[Lab — Cisco CML (Setup)]].
- Konsep yang dilatih: [[Jaringan Komputer]], [[Model OSI & TCP-IP]].
- Sisi defensif: [[Lab — Hardening Perangkat Jaringan]] · [[Network Security (Firewall, IDS-IPS)]].

## 🎯 Latihan

- Bangun **2 router + 1 switch + 2 PC**, beri IP & static route, buktikan ping lintas-router sukses.
- Aktifkan **port-security** di satu port switch, lalu buktikan port mati (`err-disabled`) saat MAC berubah.
- Pakai **mode Simulation** untuk menonton satu paket ICMP & buka isinya tiap layer.

## 📖 Sumber

- **Cisco NetAcad — Packet Tracer**: https://www.netacad.com/courses/packet-tracer
- **Packet Tracer — labs & tutorials** (di kursus "Introduction to Networks" / CCNA).
