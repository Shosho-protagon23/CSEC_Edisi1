# 📦 Lab — Containerlab (Setup)

> [!summary] Ringkasan
> **Containerlab** adalah engine lab jaringan modern yang membangun topologi dari **container** (dan opsional VM) — bukan menggambar di GUI, melainkan **mendeklarasikan topologi dalam satu file YAML** lalu `containerlab deploy`. Ringan & cepat (boot detik, bukan menit), reproducible, dan jadi favorit **NetDevOps/otomasi**. Cocok untuk NOS yang punya image container: **Arista cEOS, Nokia SR Linux, FRRouting, SONiC, Cisco XRd**, plus host Linux/Kali. Inilah note tempat kita rangkum **otomasi jaringan** (Ansible/Netmiko/pyATS).

**Bagian dari:** [[Lab — Jaringan Vulnerable (Networking)]]
**Prasyarat:** [[Lab — Jaringan Vulnerable (Networking)]], [[Linux Dasar untuk Security]] (Docker & terminal), [[Jaringan Komputer]]

---

> [!info] Beda paradigma: lab-as-code
> [[Lab — GNS3 (Setup)|GNS3]]/[[Lab — EVE-NG (Setup)|EVE-NG]] = gambar topologi pakai mouse. **Containerlab = tulis topologi sebagai kode (YAML)** → bangun/hancurkan dengan satu perintah, simpan di Git. Filosofi yang sama dengan [[Lab — AD Lab Lokal (GOAD)|GOAD]] (Vagrant/Ansible) dan [[Detection Engineering (Sigma-YARA Lanjutan)|detection-as-code]].

## 🧠 Konsep Inti

- **Berjalan di atas Docker** (host Linux/WSL2). Tiap node = container; link antar-node = veth pair yang dibuat otomatis.
- **Topologi deklaratif** — satu file `*.clab.yml` mendefinisikan node, kind (jenis NOS), image, dan link. Ubah file → re-deploy.
- **Ringan** — karena container, puluhan node bisa jalan di laptop; cocok untuk **otomasi & CI** (uji konfigurasi tiap commit).
- **Multivendor container-native** — Arista cEOS, Nokia SR Linux (gratis), FRR, SONiC, Juniper cRPD, Cisco XRd. Untuk image yang hanya tersedia sebagai VM (IOSv), pakai **vrnetlab** (bungkus VM jadi container) atau pilih [[Lab — GNS3 (Setup)|GNS3]]/[[Lab — Cisco CML (Setup)|CML]].

## ⚙️ Cara Kerja / Praktik

### 1. Pasang (Linux atau WSL2 + Docker)
```bash
# Pasang Docker dulu, lalu:
bash -c "$(curl -sL https://get.containerlab.dev)"
containerlab version
```

### 2. Tulis topologi (contoh 2 router FRR + 1 Linux host)
```yaml
# lab.clab.yml
name: vuln-net
topology:
  nodes:
    r1:   { kind: linux, image: frrouting/frr:latest }
    r2:   { kind: linux, image: frrouting/frr:latest }
    pc1:  { kind: linux, image: alpine:latest }
    kali: { kind: linux, image: kalilinux/kali-rolling }   # penyerang di dalam lab
  links:
    - endpoints: ["r1:eth1", "r2:eth1"]
    - endpoints: ["r1:eth2", "pc1:eth1"]
    - endpoints: ["r2:eth2", "kali:eth1"]
```

### 3. Deploy & masuk ke node
```bash
sudo containerlab deploy -t lab.clab.yml
containerlab inspect -t lab.clab.yml        # lihat node & IP manajemen
docker exec -it clab-vuln-net-r1 vtysh      # FRR CLI (mirip Cisco)
# konfigurasi routing di vtysh:
#   conf t ; interface eth1 ; ip address 10.0.0.1/24 ; router ospf ; network 10.0.0.0/24 area 0
```

### 4. Hancurkan / bangun ulang (kekuatan utama)
```bash
sudo containerlab destroy -t lab.clab.yml   # bersihkan total
sudo containerlab deploy  -t lab.clab.yml   # bangun lagi identik dalam detik
```

## 🤖 Otomasi Jaringan (rangkuman untuk semua engine)

Begitu lab jalan (Containerlab/GNS3/EVE-NG/CML), konfigurasi perangkat bisa **diprogram**, bukan diketik manual:

```bash
# Netmiko (Python) — push command ke banyak device via SSH
python3 - <<'PY'
from netmiko import ConnectHandler
dev = {"device_type":"cisco_ios","host":"10.0.0.1","username":"admin","password":"admin"}
c = ConnectHandler(**dev)
print(c.send_command("show ip route"))
c.send_config_set(["router ospf 1","network 10.0.0.0 0.0.0.255 area 0"])
PY
```
```bash
# Ansible — playbook ke grup device (idempotent, skala)
ansible-playbook -i inventory.ini configure_ospf.yml
# pyATS/Genie — verifikasi terstruktur (parse 'show' jadi data utk testing)
pyats parse "show ip route" --testbed-file testbed.yaml
```
> Skill ini sama dengan yang dipakai di otomasi nyata (NetDevOps). Pasangan defensifnya: validasi konfigurasi & deteksi drift → [[Hardening & Vulnerability Management]].

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **`containerlab: command not found`** → ulangi skrip instalasi; pastikan Docker aktif (`docker ps`).
> - **Node NOS gagal** → image vendor (cEOS/SR Linux) harus di-`docker import`/`pull` lebih dulu sesuai panduan vendor.
> - **Butuh IOSv (hanya VM)** → containerlab murni container; pakai **vrnetlab** atau pindah ke [[Lab — GNS3 (Setup)]]/[[Lab — Cisco CML (Setup)]].
> - **Di Windows** → jalankan via **WSL2** (Docker Desktop + distro Ubuntu).

## 🧰 Tools

- **Containerlab** — engine lab-as-code.
- **Docker / WSL2** — runtime container.
- **FRRouting, Arista cEOS, Nokia SR Linux, SONiC** — NOS container (sebagian gratis).
- **Netmiko / NAPALM / Ansible / pyATS** — otomasi & verifikasi konfigurasi.
- **vrnetlab** — bungkus image VM jadi container.

## 🔗 Kaitan

- Hub: [[Lab — Jaringan Vulnerable (Networking)]].
- Alternatif GUI: [[Lab — GNS3 (Setup)]], [[Lab — EVE-NG (Setup)]], [[Lab — Cisco CML (Setup)]].
- Pola lab-as-code serupa: [[Lab — AD Lab Lokal (GOAD)]] (Vagrant/Ansible).
- Sisi defensif (config drift, hardening terprogram): [[Hardening & Vulnerability Management]].
- Latihan serang/pertahanan: [[Lab — Serangan Jaringan (Network Pentest)]] · [[Lab — Hardening Perangkat Jaringan]].

## 🎯 Latihan

- Pasang Containerlab (Linux/WSL2), deploy topologi YAML **2× FRR + 1 Alpine**, konfigurasi OSPF lewat `vtysh`, buktikan ping antar segmen.
- Tambahkan node **Kali** di YAML, `destroy` lalu `deploy` ulang, dan rasakan lab bangkit kembali dalam hitungan detik.
- Tulis skrip **Netmiko/Ansible** yang mengonfigurasi OSPF ke semua router sekaligus.

## 📖 Sumber

- **Containerlab** — https://containerlab.dev
- **Nokia SR Linux / Arista cEOS** — image NOS untuk dicoba.
- **vrnetlab** — https://github.com/vrnetlab/vrnetlab
- **Netmiko / NAPALM / Ansible Network / pyATS** — dokumentasi otomasi.
