# 🎯 Lab — DC-1 (Setup)

> [!summary] Ringkasan
> **DC-1** (author *DCAU*, rilis 28 Feb 2019) adalah VM boot-to-root populer untuk pemula dari seri **DC**. Berbasis **Debian 32-bit** dengan aplikasi web **Drupal** sebagai pintu masuk, dan menyimpan **5 flag** (flag terakhir di home root). Formatnya **VirtualBox OVA** di dalam arsip `.zip`. Catatan ini = panduan setup untuk **VirtualBox** dan **VMware** + satu peringatan jaringan penting.

**Bagian dari:** [[Lab — VulnHub]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]], [[Lab — Setup Jaringan Lab]], [[Scanning & Enumeration]]

> [!info] Halaman resmi
> https://www.vulnhub.com/entry/dc-1-1,292/

---

## 🧠 Info Mesin

| Atribut | Nilai |
|---|---|
| Nama | DC-1 |
| File | `DC-1.zip` (~733 MB) berisi **OVA** |
| Format asli | VirtualBox OVA (VMware "should also work") |
| OS | Linux — Debian **32-bit** |
| Jaringan | **DHCP enabled**; default dikonfigurasi **Bridged** ⚠️ |
| Login awal | ❌ tidak ada (cari IP sendiri) |
| Tujuan | boot-to-root, kumpulkan **5 flag** (terakhir di `/root`) |
| Kesulitan | beginner |
| Pintu masuk | aplikasi web **Drupal** (Drupalgeddon) |

> [!danger] Ganti Bridged → Host-Only sebelum dinyalakan
> DC-1 dikemas dengan adapter **Bridged**, yang menaruhnya **langsung di jaringan rumahmu**. Untuk VM sengaja-rentan ini berbahaya. **Ubah ke Host-Only** sebelum power-on (lihat aturan emas di [[Setup Lab (Virtualisasi)]]).

---

## 1️⃣ Unduh & ekstrak

```bash
wget https://download.vulnhub.com/dc/DC-1.zip
unzip DC-1.zip          # menghasilkan file .ova
```
Mirror author: `http://www.five86.com/downloads/DC-1.zip`

## 2️⃣ Verifikasi integritas file (WAJIB)

```text
MD5  : D052D37F7C819A2B5488FE2BFF4571D8
SHA1 : BDDCADF7E8CFA1FF8BE04E446886EAD50B33761D
```
Cek hash **arsip `.zip`** sebelum diekstrak:
```bash
md5sum DC-1.zip            # Linux
sha1sum DC-1.zip
```
```powershell
Get-FileHash DC-1.zip -Algorithm MD5     # Windows
Get-FileHash DC-1.zip -Algorithm SHA1
```
Harus **sama persis**. Kalau beda → unduh ulang.

---

## 🟦 Setup A — VirtualBox

### A.1 Import appliance
```text
VirtualBox → File → Import Appliance…
  → pilih DC-1.ova → Next
  → centang "Reinitialize the MAC address of all network cards"
  → Import
```

### A.2 Ganti jaringan ke Host-Only (PENTING)
```text
VM DC-1 → Settings → Network → Adapter 1
  Attached to: Host-only Adapter   (host-only yang SAMA dengan Kali)
```
Ini mengganti default Bridged. Mesin DHCP-enabled → dapat IP otomatis di subnet host-only (mis. `192.168.56.0/24`).

### A.3 Snapshot bersih
```text
VirtualBox → DC-1 → tab Snapshots → Take → nama: "fresh"
```

---

## 🟩 Setup B — VMware (Workstation / Player / Fusion)

VMware bisa meng-import OVA (author bilang "should also work").

### B.1 Import OVA
```text
VMware → File → Open… → pilih DC-1.ova → beri nama → Import
```
Jika import ditolak karena pemeriksaan OVF ketat, paksa via **ovftool**:
```bash
ovftool --lax --allowExtraConfig DC-1.ova DC-1.vmx
```

### B.2 Set jaringan Host-Only (VMnet1)
```text
VM Settings → Network Adapter → Host-only (VMnet1)   — sama dgn Kali
```
Catat subnet VMnet1 dari **Virtual Network Editor**. Lihat [[Lab — Setup Jaringan Lab]].

### B.3 Jika jaringan mati (fix MAC)
Tutup VM, edit `DC-1.vmx`, hapus baris pengunci MAC lalu set generated:
```text
ethernet0.addressType = "generated"
# hapus: ethernet0.address / ethernet0.generatedAddress / ethernet0.checkMACAddress
```

### B.4 Snapshot bersih
```text
VM → Snapshot → Take Snapshot → nama: "fresh"
```

---

## 🎯 Setelah mesin hidup — boot-to-root

Sama untuk kedua hypervisor.

### 1. Temukan IP target (tak ada login!)
```bash
ip a
sudo netdiscover -i eth1 -r 192.168.56.0/24
# atau:
sudo arp-scan --interface=eth1 --localnet
nmap -sn 192.168.56.0/24
```

### 2. Enum & serang
```bash
nmap -sC -sV -p- <ip-dc1>        # port 80 → situs Drupal
```
DC-1 terkenal lewat **Drupalgeddon** (exploit Drupal). Lanjut → [[Web Application Hacking (OWASP Top 10)]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]]. Kumpulkan **5 flag**; flag terakhir butuh **root** (cek juga binari **SUID** untuk privesc). Ambil **snapshot bersih** sebelum menyerang.

---

## 🧰 Tools

- **VirtualBox / VMware** — jalankan OVA.
- **unzip** — ekstrak `DC-1.zip`. **ovftool** — import paksa ke VMware.
- **netdiscover / arp-scan / nmap -sn** — temukan IP target.
- **nmap, gobuster, droopescan, Metasploit (drupal_drupalgeddon2)** — fase serang.

## 🔗 Kaitan

- Hub VulnHub & langkah generik: [[Lab — VulnHub]].
- Setup OVA serupa: [[Lab — Mr-Robot (Setup)]]. Setup arsip VMware: [[Lab — Kioptrix (Setup)]].
- Setup jaringan & troubleshooting MAC: [[Lab — Setup Jaringan Lab]].
- Hub lab: [[Setup Lab (Virtualisasi)]].
- Alur serang: [[Reconnaissance (Information Gathering)]] → [[Scanning & Enumeration]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]].

## 🎯 Latihan

- Setup `DC-1.ova` (ingat: **ubah ke Host-Only**) sampai bisa `ping` target dari Kali.
- Selesaikan **boot-to-root**: temukan kelima flag. Tulis langkahmu sebagai write-up di vault.

## 📖 Sumber

- **VulnHub — DC-1** — https://www.vulnhub.com/entry/dc-1-1,292/
- **Mirror download** — https://download.vulnhub.com/dc/DC-1.zip
- Daftar "mirip OSCP" (TJnull): seri **DC-1 … DC-9** sering direkomendasikan untuk pemula.
