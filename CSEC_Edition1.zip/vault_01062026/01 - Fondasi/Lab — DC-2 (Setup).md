# 🎯 Lab — DC-2 (Setup)

> [!summary] Ringkasan
> **DC-2** (author *DCAU*, rilis 22 Mar 2019) adalah kelanjutan langsung dari [[Lab — DC-1 (Setup)|DC-1]] di seri **DC**. Berbasis **Debian 32-bit** dengan **WordPress** sebagai pintu masuk, dan menyimpan **5 flag** (flag terakhir butuh root). Yang khas dari DC-2: kamu **wajib menambah entri hosts** `dc-2` agar CMS jalan, lalu belajar **keluar dari `rbash`** (restricted shell) dan **privesc lewat `git`**. Formatnya **VirtualBox OVA** di dalam arsip `.zip`. Catatan ini = panduan setup untuk **VirtualBox** dan **VMware** + dua peringatan penting (jaringan & hosts).

**Bagian dari:** [[Lab — VulnHub]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]], [[Lab — Setup Jaringan Lab]], [[Scanning & Enumeration]]
**Lanjutan dari:** [[Lab — DC-1 (Setup)]]

> [!info] Halaman resmi
> https://www.vulnhub.com/entry/dc-2,311/

---

## 🧠 Info Mesin

| Atribut | Nilai |
|---|---|
| Nama | DC-2 |
| File | `DC-2.zip` (~847 MB) berisi **OVA** |
| Format asli | VirtualBox OVA (VMware biasanya jalan) |
| OS | Linux — Debian **32-bit** |
| Jaringan | **DHCP enabled**; default dikonfigurasi **Bridged** ⚠️ |
| Login awal | ❌ tidak ada (cari IP sendiri) |
| Tujuan | boot-to-root, kumpulkan **5 flag** (terakhir di `/root`) |
| Kesulitan | beginner |
| Pintu masuk | **WordPress** (enum user → password attack → `rbash` → `git` privesc) |

> [!danger] Ganti Bridged → Host-Only sebelum dinyalakan
> Seperti DC-1, DC-2 dikemas dengan adapter **Bridged** yang menaruhnya **langsung di jaringan rumahmu**. **Ubah ke Host-Only** sebelum power-on (lihat aturan emas di [[Setup Lab (Virtualisasi)]]).

> [!warning] WAJIB: tambah entri hosts `dc-2`
> WordPress di DC-2 akan **redirect ke `http://dc-2/`**, jadi kalau diakses lewat IP saja situsnya rusak. Setelah tahu IP target, tambahkan ke file hosts Kali:
> ```bash
> echo "192.168.56.x   dc-2" | sudo tee -a /etc/hosts
> ```
> Ganti `192.168.56.x` dengan IP DC-2 yang kamu temukan. (Pola yang sama dipakai [[Lab — Kioptrix (Setup)|Kioptrix #3]] dgn `kioptrix3.com`.)

---

## 1️⃣ Unduh & ekstrak

```bash
wget https://download.vulnhub.com/dc/DC-2.zip
unzip DC-2.zip          # menghasilkan file .ova
```
Mirror author: `http://www.five86.com/downloads/DC-2.zip`

## 2️⃣ Verifikasi integritas file (WAJIB)

```text
MD5  : F66A5E3AA422A20A526DD4D1018F599B
SHA1 : 906D1930E008BBA5DBA06BBC2E59B2D6E908BEC5
```
Cek hash **arsip `.zip`** sebelum diekstrak:
```bash
md5sum DC-2.zip            # Linux
sha1sum DC-2.zip
```
```powershell
Get-FileHash DC-2.zip -Algorithm MD5     # Windows
Get-FileHash DC-2.zip -Algorithm SHA1
```
Harus **sama persis**. Kalau beda → unduh ulang.

---

## 🟦 Setup A — VirtualBox

### A.1 Import appliance
```text
VirtualBox → File → Import Appliance…
  → pilih DC-2.ova → Next
  → centang "Reinitialize the MAC address of all network cards"
  → Import
```

### A.2 Ganti jaringan ke Host-Only (PENTING)
```text
VM DC-2 → Settings → Network → Adapter 1
  Attached to: Host-only Adapter   (host-only yang SAMA dengan Kali)
```
Mengganti default Bridged. Mesin DHCP-enabled → dapat IP otomatis di subnet host-only (mis. `192.168.56.0/24`).

### A.3 Snapshot bersih
```text
VirtualBox → DC-2 → tab Snapshots → Take → nama: "fresh"
```

---

## 🟩 Setup B — VMware (Workstation / Player / Fusion)

### B.1 Import OVA
```text
VMware → File → Open… → pilih DC-2.ova → beri nama → Import
```
Jika import ditolak karena pemeriksaan OVF ketat, paksa via **ovftool**:
```bash
ovftool --lax --allowExtraConfig DC-2.ova DC-2.vmx
```

### B.2 Set jaringan Host-Only (VMnet1)
```text
VM Settings → Network Adapter → Host-only (VMnet1)   — sama dgn Kali
```
Catat subnet VMnet1 dari **Virtual Network Editor**. Lihat [[Lab — Setup Jaringan Lab]].

### B.3 Jika jaringan mati (fix MAC)
Tutup VM, edit `DC-2.vmx`, hapus baris pengunci MAC lalu set generated:
```text
ethernet0.addressType = "generated"
# hapus: ethernet0.address / ethernet0.generatedAddress / ethernet0.checkMACAddress
```

### B.4 Snapshot bersih
```text
VM → Snapshot → Take Snapshot → nama: "fresh"
```

---

## 🎯 Setelah mesin hidup — boot-to-root

Sama untuk kedua hypervisor.

### 1. Temukan IP target (tak ada login!)
```bash
ip a
sudo netdiscover -i eth1 -r 192.168.56.0/24
# atau:
sudo arp-scan --interface=eth1 --localnet
nmap -sn 192.168.56.0/24
```

### 2. Tambah hosts lalu enum & serang
```bash
echo "192.168.56.x   dc-2" | sudo tee -a /etc/hosts   # WAJIB (lihat warning di atas)
nmap -sC -sV -p- dc-2
```
Alur khas DC-2:
1. **WordPress** → enum user dengan `wpscan --enumerate u`.
2. **Password attack** → bikin wordlist target dengan `cewl http://dc-2/ -w kata.txt`, lalu `wpscan --passwords kata.txt` (lihat [[Password Attacks]]).
3. Login web/SSH → kamu kejebak di **`rbash`** (restricted shell) → cari teknik **escape rbash** (mis. `vi`/`BASH_CMDS`/`export PATH`).
4. **Privesc** lewat binari `git` yang bisa di-`sudo` → [[Privilege Escalation]].

Kumpulkan **5 flag**; flag terakhir butuh **root**. Ambil **snapshot bersih** sebelum menyerang.

---

## 🧰 Tools

- **VirtualBox / VMware** — jalankan OVA.
- **unzip** — ekstrak `DC-2.zip`. **ovftool** — import paksa ke VMware.
- **netdiscover / arp-scan / nmap -sn** — temukan IP target.
- **nmap, wpscan, cewl, GTFOBins (git/vi)** — fase serang & privesc.

## 🔗 Kaitan

- Hub VulnHub & langkah generik: [[Lab — VulnHub]].
- Pendahulunya (Drupal, OVA serupa): [[Lab — DC-1 (Setup)]]. Setup OVA lain: [[Lab — Mr-Robot (Setup)]]. Setup arsip VMware: [[Lab — Kioptrix (Setup)]].
- Serangan password & wordlist custom: [[Password Attacks]].
- Setup jaringan & troubleshooting MAC: [[Lab — Setup Jaringan Lab]].
- Hub lab: [[Setup Lab (Virtualisasi)]].
- Alur serang: [[Reconnaissance (Information Gathering)]] → [[Scanning & Enumeration]] → [[Web Application Hacking (OWASP Top 10)]] → [[Privilege Escalation]].

## 🎯 Latihan

- Setup `DC-2.ova` (ingat: **Host-Only** + **entri hosts `dc-2`**) sampai bisa buka `http://dc-2/` dari Kali.
- Selesaikan **boot-to-root**: enum user WordPress → crack password dgn wordlist `cewl` → **escape rbash** → privesc `git`. Tulis write-up di vault.

## 📖 Sumber

- **VulnHub — DC-2** — https://www.vulnhub.com/entry/dc-2,311/
- **Mirror download** — https://download.vulnhub.com/dc/DC-2.zip
- **GTFOBins** (escape rbash & sudo git) — https://gtfobins.github.io
- Daftar "mirip OSCP" (TJnull): seri **DC-1 … DC-9** sering direkomendasikan untuk pemula.
