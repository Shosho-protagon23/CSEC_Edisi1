# 🌐 Lab — EVE-NG (Setup)

> [!summary] Ringkasan
> **EVE-NG (Emulated Virtual Environment – Next Generation)** adalah **emulator** jaringan yang dijalankan sebagai **satu VM Linux** dan diakses lewat **browser** (HTML5) — tak ada software client di laptopmu. Kekuatannya: **multivendor & skala besar** (Cisco, Juniper, Palo Alto, Fortinet, F5, Linux, dll. dalam satu topologi), cocok untuk lab kompleks dan kerja tim. Tersedia **Community Edition (gratis)** dan **Pro/Learning Center** (berbayar). Lebih "berat di server" dibanding [[Lab — GNS3 (Setup)|GNS3]], tapi sangat rapi untuk lab besar.

**Bagian dari:** [[Lab — Jaringan Vulnerable (Networking)]]
**Prasyarat:** [[Lab — Jaringan Vulnerable (Networking)]], [[Setup Lab (Virtualisasi)]], [[Linux Dasar untuk Security]] (akses node lewat SSH/console)

---

> [!danger] Legalitas image
> Sama seperti GNS3: EVE-NG **tidak menyertakan** image vendor. Unggah hanya image yang **kamu miliki haknya**. Komunitas EVE-NG menyediakan panduan format, tapi image-nya tetap tanggung jawab lisensimu. Gunakan alternatif legal (VyOS, FRR, Arista cEOS) bila tak punya lisensi Cisco.

## 🧠 Konsep Inti

- **Berbasis VM tunggal + browser** — kamu menjalankan satu VM EVE-NG (atau di server bare-metal), lalu membuka topologi di browser. Banyak orang bisa akses server yang sama.
- **Console via HTML5 atau native** — akses CLI node lewat tab browser, atau pakai telnet/VNC client (Putty/UltraVNC) dengan integrasi "EVE-NG Client Pack".
- **Format image**: node diletakkan di folder khusus di dalam VM (`/opt/unetlab/addons/`) untuk QEMU/IOL/Dynamips. Ada skrip "fixpermissions" setelah menambah image.
- **Multivendor unggulan** — paling sering dipilih ketika lab butuh **firewall vendor** (Palo Alto, Fortinet, Cisco ASA/FTD) bersama router/switch — relevan untuk lab [[Network Security (Firewall, IDS-IPS)|firewall/IDS]].

| | EVE-NG | [[Lab — GNS3 (Setup)|GNS3]] |
|---|---|---|
| Akses | Browser (server) | Aplikasi desktop |
| Setup | 1 VM/server | GUI + GNS3 VM |
| Skala besar/tim | sangat baik | baik |
| Kemudahan pemula | sedang | sedang-mudah |

## ⚙️ Cara Kerja / Praktik

### 1. Pasang VM EVE-NG
```text
1. Unduh OVA "EVE-NG Community" dari https://www.eve-ng.net → import ke
   VMware/VirtualBox (VMware lebih disarankan untuk nested).
2. Aktifkan nested virtualization (VT-x/AMD-V) untuk VM EVE-NG.
3. Boot → login console (root/eve) → wizard set hostname, IP, DNS.
4. Catat IP VM → buka http://<ip-eve> di browser (login admin/eve).
```

### 2. Tambah image perangkat
```bash
# Dari SSH ke VM EVE-NG, taruh image di folder yang sesuai, mis. QEMU:
#   /opt/unetlab/addons/qemu/<nama-folder-spesifik>/
# Contoh struktur untuk appliance:
#   /opt/unetlab/addons/qemu/vyos-1.4/hda.qcow2
# Lalu WAJIB perbaiki permission:
/opt/unetlab/wrappers/unl_wrapper -a fixpermissions
```
> Penamaan folder image **harus persis** sesuai konvensi EVE-NG agar muncul di menu. Lihat tabel image resmi di dokumentasi.

### 3. Buat lab & topologi (di browser)
```text
- Add new lab → beri nama.
- Tombol "+" → Add node → pilih image (router/switch/firewall) → drop ke kanvas.
- Add network "Cloud0/pnet" untuk jembatan ke jaringan luar (mgmt/internet).
- Klik node → Start → klik node lagi → console terbuka di browser.
```

### 4. Konfigurasi & uji
```cisco
! Sama seperti perangkat asli (contoh node IOS/VyOS-style)
configure terminal
 interface ethernet0/0
  ip address 10.0.0.1 255.255.255.0
  no shutdown
end
show ip interface brief
```

### 5. Sambungkan ke Kali / dunia luar
```text
- Tambah node "Network" tipe "Bridge"/"pnet" yang dipetakan ke interface VM EVE-NG.
- Jalankan Kali sebagai node Linux di dalam lab, ATAU sambungkan via
  cloud bridge ke VM Kali (konsep host-only di [[Lab — Setup Jaringan Lab]]).
```

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **Node tak mau start** → nested virtualization belum aktif di VM EVE-NG, atau RAM server habis.
> - **Image tak muncul di menu** → nama folder salah / lupa `fixpermissions`.
> - **Console tak terbuka di browser** → pasang "EVE-NG Win/Linux Client Pack" untuk telnet/VNC, atau pakai mode HTML5 console.
> - **Lab lambat** → EVE-NG suka RAM & CPU banyak; kurangi jumlah node atau beri VM lebih banyak resource.

## 🧰 Tools

- **EVE-NG Community/Pro** — emulator multivendor berbasis server.
- **EVE-NG Client Pack** — telnet/VNC/RDP terintegrasi.
- **Wireshark** — capture link dari antarmuka EVE-NG.
- Image legal: VyOS, FRR, Arista cEOS; firewall vendor bila berlisensi.

## 🔗 Kaitan

- Hub: [[Lab — Jaringan Vulnerable (Networking)]].
- Alternatif desktop: [[Lab — GNS3 (Setup)]]; resmi Cisco: [[Lab — Cisco CML (Setup)]]; container: [[Lab — Containerlab (Setup)]].
- Cocok untuk lab firewall: [[Network Security (Firewall, IDS-IPS)]].
- Jaringan ke Kali/luar: [[Lab — Setup Jaringan Lab]].
- Latihan: [[Lab — Serangan Jaringan (Network Pentest)]] · [[Lab — Hardening Perangkat Jaringan]].

## 🎯 Latihan

- Import VM EVE-NG, tambahkan image **VyOS** (legal), bangun lab **2 router + 1 switch**, jalankan routing, dan akses console tiap node lewat browser.
- Tambahkan node firewall open-source (mis. **pfSense/OPNsense**) di antara dua segmen, buat rule, dan uji blok/allow — bridging ke [[Network Security (Firewall, IDS-IPS)]].

## 📖 Sumber

- **EVE-NG** — https://www.eve-ng.net
- **EVE-NG Documentation / How-to** — https://www.eve-ng.net/index.php/documentation/
- **EVE-NG Community Cookbook** (PDF resmi).
