# 🔧 Lab — GNS3 (Setup)

> [!summary] Ringkasan
> **GNS3 (Graphical Network Simulator-3)** adalah **emulator** jaringan open-source paling populer: ia menjalankan **image OS jaringan yang asli** (Cisco IOS via Dynamips, IOU/IOL, atau appliance VM seperti CSR1000v/VyOS/Arista) sehingga perilakunya **identik perangkat sungguhan**. Inilah engine utama untuk lab keamanan jaringan karena kamu bisa **menyambungkan Kali** ke topologi dan menyerang/mempertahankannya secara nyata. Lebih berat dari [[Lab — Cisco Packet Tracer (Setup)|Packet Tracer]] dan butuh image sendiri.

**Bagian dari:** [[Lab — Jaringan Vulnerable (Networking)]]
**Prasyarat:** [[Lab — Jaringan Vulnerable (Networking)]] (paham simulasi vs emulasi), [[Setup Lab (Virtualisasi)]], [[Lab — Setup Jaringan Lab]]

---

> [!danger] Legalitas image
> GNS3 **tidak menyertakan** image Cisco IOS — kamu menyediakannya sendiri. Gunakan **hanya image yang kamu miliki haknya** (dari perangkat resmi/kontrak/CML). Alternatif **legal & gratis**: **VyOS, FRRouting, Arista cEOS (free), Nokia SR Linux, Cisco CSR1000v/IOSv (trial via CML/VIRL berlisensi)**. Jangan unduh IOS bajakan.

## 🧠 Konsep Inti

### Arsitektur GNS3: GUI + "GNS3 VM"
GNS3 terbagi dua bagian:
1. **GNS3 GUI** (di host Windows/macOS/Linux) — tempat kamu menggambar topologi.
2. **GNS3 VM** — sebuah VM Linux (jalan di VirtualBox/VMware/Hyper-V) tempat node **sebenarnya dijalankan**.

> [!info] Kenapa perlu GNS3 VM?
> Banyak image (IOU/IOL, appliance Qemu/KVM, container Docker) butuh lingkungan Linux + nested virtualization. GNS3 VM menyediakannya secara konsisten. Di Windows/macOS, **selalu pakai GNS3 VM**. Di Linux host, GNS3 bisa jalan lokal tanpa VM (tetap perlu KVM untuk appliance).

### Cara GNS3 menjalankan perangkat
| Teknologi | Untuk image apa | Catatan |
|---|---|---|
| **Dynamips** | IOS router klasik (.image, mis. 7200/3725) | hitung "Idle-PC" agar CPU tak 100% |
| **IOU/IOL** | IOS-on-Unix (L2/L3, ringan) | butuh lisensi Cisco; butuh GNS3 VM |
| **QEMU/KVM** | appliance VM (CSR1000v, VyOS, ASA, pfSense) | berat tapi paling realistis |
| **Docker** | container (FRR, host Linux, Kali) | ringan; bagus untuk end host |

### Node "Cloud" & NAT — jembatan ke dunia luar
- **NAT node** — beri internet ke topologi (mis. router unduh update).
- **Cloud node** — sambungkan topologi ke **interface host** atau **adapter host-only** → ini cara memasukkan **VM Kali** (di VirtualBox/VMware) ke dalam lab untuk menyerang. Lihat konsep host-only di [[Lab — Setup Jaringan Lab]].

## ⚙️ Cara Kerja / Praktik

### 1. Pasang GNS3 + GNS3 VM
```text
1. Unduh GNS3 dari https://gns3.com (butuh akun gratis) → pasang GUI.
2. Unduh "GNS3 VM" untuk hypervisor-mu (VirtualBox/VMware/Hyper-V) → import.
3. Aktifkan virtualisasi (VT-x/AMD-V) di BIOS; beri GNS3 VM RAM cukup (4–8 GB).
4. Di GUI: Edit → Preferences → Server → centang "Enable GNS3 VM".
```

### 2. Tambahkan image perangkat (contoh: appliance legal)
```text
GUI → File → "Import appliance" (.gns3a) → pilih, mis:
  - VyOS (router open-source, gratis)        ← rekomendasi untuk mulai
  - Cisco CSR1000v / IOSv (jika punya image legal)
  - Arista vEOS / cEOS (gratis dgn akun Arista)
Ikuti wizard: unggah file image yang diminta → appliance siap dipakai.
```
> Untuk **end host** ringan, GNS3 menyediakan **VPCS** (PC virtual mini) built-in — tak butuh image.

### 3. Bangun topologi & konfigurasi
```text
- Seret 2 router + 1 switch + 2 VPCS ke kanvas → hubungkan dengan "link".
- Klik kanan node → Start. Klik dua kali → buka konsol (CLI).
```
```cisco
! Contoh di node IOS/CSR — sama seperti perangkat asli
enable
conf t
 hostname R1
 int g0/0
  ip address 10.0.12.1 255.255.255.0
  no shutdown
 router ospf 1
  network 10.0.12.0 0.0.0.255 area 0
end
write
show ip ospf neighbor
```
```text
# Di VPCS (end host):
ip 192.168.1.10 192.168.1.1 24      # set IP + gateway + prefix
ping 192.168.2.10
```

### 4. Sambungkan Kali (untuk lab serangan)
```text
Opsi A (paling mudah): jalankan Kali sebagai Docker node di dalam GNS3,
  tarik ke kanvas, hubungkan ke switch topologi.
Opsi B: Kali sebagai VM di VirtualBox/VMware →
  tarik node "Cloud" → pilih adapter host-only yang dipakai Kali →
  hubungkan Cloud ke topologi.  (konsep di [[Lab — Setup Jaringan Lab]])
```
Setelah tersambung, Kali ada **di dalam subnet topologi** → siap untuk [[Lab — Serangan Jaringan (Network Pentest)]].

### 5. Snapshot & simpan
```text
- File → Snapshots: ambil snapshot project setelah topologi jadi.
- Project tersimpan sebagai folder .gns3 → bisa di-export/share.
```

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **CPU 100% dengan Dynamips** → set **Idle-PC** (klik kanan router → Idle-PC → pilih nilai). Khas image IOS klasik.
> - **Node QEMU tak mau start** → nested virtualization/KVM belum aktif; pastikan GNS3 VM punya "Enable nested VT-x/AMD-V".
> - **Kali tak lihat perangkat** → salah binding Cloud node / adapter host-only beda; samakan (lihat [[Lab — Setup Jaringan Lab]]).
> - **Image tak muncul** → appliance butuh file versi spesifik; cek checksum yang diminta wizard.
> - **Link tak konek ke port yang benar** → beberapa switch IOSvL2 butuh waktu boot; tunggu hingga `Press RETURN`.

## 🧰 Tools

- **GNS3 GUI + GNS3 VM** — engine emulasi.
- **Dynamips / IOU / QEMU / Docker** — mesin penjalan node.
- **VPCS** — end host ringan built-in.
- **Wireshark** — klik kanan link → "Start capture" untuk sniff frame/paket.
- **Image legal**: VyOS, FRRouting, Arista cEOS/vEOS, Cisco CSR1000v/IOSv (berlisensi).

## 🔗 Kaitan

- Hub: [[Lab — Jaringan Vulnerable (Networking)]].
- Jaringan ke VM luar (Kali): [[Lab — Setup Jaringan Lab]] · [[Setup Lab (Virtualisasi)]].
- Latihan serang: [[Lab — Serangan Jaringan (Network Pentest)]] · pertahanan: [[Lab — Hardening Perangkat Jaringan]].
- Alternatif lain: [[Lab — EVE-NG (Setup)]] (web-based), [[Lab — Cisco CML (Setup)]] (resmi), [[Lab — Containerlab (Setup)]] (container).
- Sniff trafik untuk analisis: [[Network Security (Firewall, IDS-IPS)]] · [[Network Security Lanjutan (NSM-NDR)]].

## 🎯 Latihan

- Pasang GNS3 + GNS3 VM, import **VyOS** (gratis), bangun **2 router + 1 switch + 2 VPCS**, jalankan **OSPF**, buktikan ping lintas-router & cek `show ip route`.
- Tambahkan **Kali sebagai Docker node**, sambungkan ke switch, lalu `nmap -sn` subnet topologi untuk menemukan perangkat — fondasi [[Lab — Serangan Jaringan (Network Pentest)]].
- Klik kanan satu link → **Start capture** → buka di Wireshark, amati hello OSPF & ARP.

## 📖 Sumber

- **GNS3 Documentation** — https://docs.gns3.com
- **GNS3 Marketplace (appliances .gns3a)** — https://gns3.com/marketplace/appliances
- **VyOS** (router open-source legal) — https://vyos.io
- **David Bombal — GNS3 tutorials (YouTube)**.
