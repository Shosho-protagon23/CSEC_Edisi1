# 🔵 Lab — Hardening Perangkat Jaringan

> [!summary] Ringkasan
> Pasangan defensif langsung dari [[Lab — Serangan Jaringan (Network Pentest)]]: tiap serangan L2/L3 yang kamu praktikkan punya **mitigasi konkret** di switch/router. Note ini berisi konfigurasi **hardening** Cisco IOS (dan padanan konsep di NOS lain) untuk dipraktikkan di lab emulasi — port-security, DHCP snooping, Dynamic ARP Inspection, BPDU Guard, VLAN hygiene, routing authentication, manajemen aman (SSH/AAA), dan control-plane protection. Pola belajar terbaik: **serang dulu → keraskan → ulangi serangan → buktikan gagal**.

**Bagian dari:** [[Lab — Jaringan Vulnerable (Networking)]]
**Prasyarat:** [[Lab — Serangan Jaringan (Network Pentest)]], [[Jaringan Komputer]], [[Network Security (Firewall, IDS-IPS)]]

---

## 🧠 Konsep Inti — peta serangan → mitigasi

| Serangan ([[Lab — Serangan Jaringan (Network Pentest)|offensive]]) | Mitigasi | Fitur Cisco |
|---|---|---|
| MAC flooding | batasi MAC per port | **Port-Security** |
| ARP spoofing / MITM | validasi ARP vs binding DHCP | **Dynamic ARP Inspection (DAI)** |
| Rogue DHCP / starvation | percayai DHCP hanya dari port "trusted" | **DHCP Snooping** |
| STP root takeover | tolak BPDU dari port akses | **BPDU Guard / Root Guard** |
| VLAN hopping (DTP) | matikan auto-trunk; native VLAN aman | `switchport nonegotiate`, VLAN hygiene |
| Telnet/SNMP lemah | enkripsi & autentikasi manajemen | **SSH, SNMPv3, AAA** |
| Routing palsu (OSPF/EIGRP) | autentikasi tetangga routing | **OSPF/EIGRP authentication** |
| Brute akses perangkat | kunci & batasi login | **login block-for, ACL VTY** |

> Ini sisi praktik dari [[Hardening & Vulnerability Management]] yang difokuskan ke perangkat jaringan, dan melengkapi [[Network Security Lanjutan (NSM-NDR)]] (deteksi) dengan **pencegahan**.

## ⚙️ Cara Kerja / Praktik (Cisco IOS)

### 1. Port-Security (lawan MAC flooding)
```cisco
interface range fa0/1 - 24
 switchport mode access
 switchport port-security
 switchport port-security maximum 2
 switchport port-security mac-address sticky
 switchport port-security violation restrict     ! atau shutdown
show port-security interface fa0/1
```

### 2. DHCP Snooping (lawan rogue DHCP)
```cisco
ip dhcp snooping
ip dhcp snooping vlan 10
interface gi0/1                 ! port menuju server DHCP yang SAH
 ip dhcp snooping trust         ! hanya port ini boleh menjawab DHCP
! port akses lain = untrusted (default) → DHCP-offer dari sana diblok
show ip dhcp snooping binding
```

### 3. Dynamic ARP Inspection (lawan ARP spoofing)
```cisco
ip arp inspection vlan 10        ! validasi ARP terhadap tabel snooping
interface gi0/1
 ip arp inspection trust         ! uplink dipercaya
show ip arp inspection
```
> DAI **bergantung** pada binding DHCP Snooping → aktifkan snooping dulu.

### 4. STP protection (lawan root takeover)
```cisco
interface range fa0/1 - 24
 spanning-tree portfast           ! port akses langsung forwarding
 spanning-tree bpduguard enable   ! BPDU masuk di port akses → err-disable
! di port menuju switch sah: spanning-tree guard root  (Root Guard)
show spanning-tree summary
```

### 5. VLAN hygiene (lawan VLAN hopping)
```cisco
interface range fa0/1 - 24
 switchport mode access
 switchport nonegotiate           ! matikan DTP (cegah auto-trunk)
! ubah native VLAN trunk ke VLAN tak terpakai, jangan VLAN 1:
interface gi0/1
 switchport trunk native vlan 999
 switchport trunk allowed vlan 10,20   ! batasi VLAN di trunk
```

### 6. Manajemen aman: SSH + AAA + matikan Telnet
```cisco
hostname R1
ip domain-name lab.local
crypto key generate rsa modulus 2048
username admin secret S3cure!Pass         ! password ter-hash
aaa new-model
line vty 0 4
 transport input ssh                      ! TELNET DIMATIKAN
 login local
 exec-timeout 5 0
 access-class 10 in                       ! batasi sumber IP admin
access-list 10 permit 10.0.99.0 0.0.0.255
! anti-brute:
login block-for 120 attempts 3 within 60
service password-encryption
enable secret S3cret!Enable
```

### 7. SNMPv3 (ganti SNMPv1/v2c)
```cisco
snmp-server group LAB v3 priv
snmp-server user adminv3 LAB v3 auth sha AuthPass priv aes 128 PrivPass
no snmp-server community public           ! cabut community lama
no snmp-server community private
```

### 8. Routing authentication (lawan route injection)
```cisco
! OSPF dengan message-digest (MD5) per area/interface
interface gi0/0
 ip ospf authentication message-digest
 ip ospf message-digest-key 1 md5 OspfKey!
router ospf 1
 area 0 authentication message-digest
```

### 9. Control-plane & layanan tak perlu
```cisco
no ip http server
no cdp run                       ! CDP bocorkan info perangkat (matikan di edge)
service tcp-keepalives-in
! (opsional) CoPP untuk batasi trafik ke control-plane
```

## ✅ Verifikasi (serang ulang!)
```text
Setelah hardening, ULANGI tiap serangan dari [[Lab — Serangan Jaringan (Network Pentest)]]:
 - macof  → port err-disable / dibatasi      (port-security ✔)
 - arpspoof → ARP ditolak, korban aman        (DAI ✔)
 - rogue DHCP → offer diblok di untrusted port (snooping ✔)
 - yersinia STP → BPDU Guard mematikan port    (BPDU Guard ✔)
 - telnet → ditolak, hanya SSH                 (transport ssh ✔)
```

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **Klien sah tak dapat DHCP setelah snooping** → port menuju server DHCP belum di-`trust`.
> - **DAI memutus semua ARP** → binding kosong; aktifkan DHCP Snooping lebih dulu (atau buat ARP ACL statis).
> - **Port akses err-disabled** → BPDU Guard / port-security bekerja; pulihkan dengan `shutdown`/`no shutdown` setelah penyebab beres, atau `errdisable recovery`.
> - **OSPF neighbor down setelah auth** → key/mode tidak sama di kedua sisi.

## 🧰 Tools

- **Cisco IOS CLI** (`show port-security`, `show ip dhcp snooping`, `show ip arp inspection`).
- Padanan open-source: **VyOS / FRRouting** (firewall zone, OSPF auth), **pfSense/OPNsense** (segmentasi).
- **Ansible / Netmiko** — terapkan hardening ke banyak device sekaligus ([[Lab — Containerlab (Setup)]]).
- **Benchmark**: **CIS Cisco IOS Benchmark** sebagai checklist.

## 🔗 Kaitan

- **Pasangan ofensif:** [[Lab — Serangan Jaringan (Network Pentest)]] (serang → keraskan → uji ulang).
- Lab tempat praktik: [[Lab — Jaringan Vulnerable (Networking)]].
- Teori defensif lebih luas: [[Hardening & Vulnerability Management]], [[Network Security (Firewall, IDS-IPS)]], [[Defense in Depth & Security Architecture]].
- Deteksi (kalau pencegahan jebol): [[Network Security Lanjutan (NSM-NDR)]], [[Log Analysis & Monitoring]].
- Otomasi penerapan: [[Lab — Containerlab (Setup)]].

## 🎯 Latihan

- Ambil topologi yang sudah kamu serang, lalu terapkan **port-security + DHCP snooping + DAI**; ulangi `macof`, `arpspoof`, dan rogue DHCP — buktikan ketiganya kini **gagal**.
- Ganti Telnet → **SSH + AAA + login block-for**, lalu coba `hydra` brute SSH dan amati akun terkunci.
- Aktifkan **OSPF MD5 auth**, coba inject route palsu, buktikan router menolak tetangga tak terautentikasi.
- (Lanjutan) Tulis playbook **Ansible** yang menerapkan baseline hardening ke semua switch lab sekaligus.

## 📖 Sumber

- **Cisco — Catalyst/IOS Security Configuration Guide** (Port-Security, DHCP Snooping, DAI).
- **CIS Cisco IOS Benchmark** — https://www.cisecurity.org
- **Cisco — "Layer 2 Security Best Practices"** (SAFE).
- **NSA — Network Infrastructure Security Guide**.
