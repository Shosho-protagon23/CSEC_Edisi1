# 🔌 Lab — IoT & Embedded Hacking

> [!summary] Ringkasan
> Pelengkap keluarga [[Lab — Jaringan Vulnerable (Networking)|lab jaringan]] untuk perangkat **IoT & embedded** (kamera IP, router rumah, smart plug, sensor). Karakternya unik: serangan menjangkau **5 permukaan** sekaligus — **hardware** (port UART/JTAG/SPI di PCB), **firmware** (ekstrak & bedah), **radio** (BLE/Zigbee/RF 433 MHz, bukan cuma WiFi), **jaringan/protokol** (MQTT/CoAP/UPnP), dan **web/cloud** (antarmuka admin & API). Note ini = setup lab + serangan per-permukaan + pertahanan, berbingkai **OWASP IoT Top 10**. Latih **hanya pada perangkat milikmu**.

**Bagian dari:** [[Lab — Jaringan Vulnerable (Networking)]] · [[Fondasi (MOC)]]
**Prasyarat:** [[Jaringan Komputer]], [[Linux Dasar untuk Security]], [[Setup Lab (Virtualisasi)]]; berguna: [[Jaringan Nirkabel & 802.11 (WiFi)]], [[Malware Analysis Dasar]] (analisis biner)

---

> [!danger] Etika & risiko fisik
> Membuka & menyolder perangkat **membatalkan garansi** dan bisa merusaknya permanen (atau menyetrum dirimu — hati-hati listrik). Hanya bongkar **perangkat milikmu sendiri**. Menyerang IoT orang lain (kamera, router) **ilegal**. Beberapa firmware dilindungi hak cipta — analisis untuk riset keamanan umumnya sah, tapi distribusinya tidak. Lihat etika di [[00 - START HERE]].

## 🧠 Konsep Inti

### Kenapa IoT rawan
Perangkat IoT sering: pakai **kredensial default**, firmware **jarang di-update**, layanan **tak terenkripsi**, dan dibangun dengan komponen lama yang penuh CVE. Sumber daya terbatas (CPU/RAM kecil) membuat vendor memangkas keamanan.

### Lima permukaan serang (attack surface)
| Permukaan | Apa yang diserang | Contoh teknik |
|---|---|---|
| **Hardware** | port debug di PCB | akses shell via **UART**, dump via **JTAG/SWD**, baca chip **SPI flash** |
| **Firmware** | image OS perangkat | ekstrak filesystem, cari kredensial/kunci hardcoded, CVE |
| **Radio** | komunikasi nirkabel | sniff/replay **BLE, Zigbee, RF 433/868 MHz**, [[Jaringan Nirkabel & 802.11 (WiFi)|WiFi]] |
| **Jaringan** | protokol IoT | **MQTT/CoAP** tanpa auth, UPnP, telnet terbuka |
| **Web/Cloud** | UI admin & API | [[Web Application Hacking (OWASP Top 10)|OWASP web bugs]], API token lemah |

### OWASP IoT Top 10 (kerangka acuan)
Ringkas: (1) password lemah/hardcoded, (2) layanan jaringan tak aman, (3) antarmuka ekosistem tak aman, (4) mekanisme update tak aman, (5) komponen usang, (6) privasi data, (7) transfer/penyimpanan data tak aman, (8) manajemen perangkat lemah, (9) setelan default tak aman, (10) hardening fisik kurang. → tiap poin = checklist saat audit perangkat.

## 🛠️ Setup Lab IoT

### Pendekatan: emulasi dulu, hardware kemudian
Kamu **tidak** harus langsung beli alat solder. Banyak yang bisa dilatih lewat **emulasi firmware**.

```bash
# Lab software (tanpa hardware):
#  - FirmAE / Firmadyne : emulasi firmware router/IP-cam → akses web UI-nya
#  - IoTGoat            : firmware OpenWrt sengaja-rentan (latihan resmi OWASP)
#  - DVAR / DVID        : perangkat/aplikasi IoT rentan untuk belajar
#  - QEMU               : jalankan biner ARM/MIPS firmware
sudo apt install qemu-user-static binwalk
```
> Untuk hardware nyata, alat dasar: **USB-TTL serial adapter** (UART), **multimeter** (cari pinout), **logic analyzer** murah, **SPI flash programmer (CH341A)**, dan opsional **Bus Pirate**. Untuk radio: **HackRF / RTL-SDR** (RF umum), **Ubertooth** (BLE), dongle **Zigbee**.

## ⚔️ Praktik Serangan (per permukaan)

### 1. Firmware: ekstrak & bedah (paling sering jadi titik mulai)
```bash
# Unduh firmware dari situs vendor (sah) atau dump dari chip.
binwalk firmware.bin                      # identifikasi: header, kompresi, filesystem
binwalk -e firmware.bin                   # ekstrak (squashfs/jffs2/cpio)
# Telusuri isi filesystem yang terekstrak:
grep -rIn "password\|passwd\|api_key\|BEGIN RSA" _firmware.bin.extracted/
# Cek kredensial OS:
cat _firmware.bin.extracted/squashfs-root/etc/shadow      # → crack di [[Password Attacks]]
# Analisis biner mencurigakan: lihat teknik di [[Malware Analysis Dasar]]
```

### 2. UART: dapatkan shell lewat 4 pin di PCB
```text
- Cari header 4-pin (GND, VCC, TX, RX). Multimeter → temukan GND & TX.
- Sambungkan USB-TTL: TX↔RX, RX↔TX, GND↔GND (JANGAN sambungkan VCC).
```
```bash
sudo screen /dev/ttyUSB0 115200           # buka serial console (baud umum: 115200/57600)
# atau: minicom -D /dev/ttyUSB0 -b 115200
# Sering langsung dapat root shell / bootloader (U-Boot) → ubah init=/bin/sh
```

### 3. SPI flash dump (kalau UART terkunci)
```bash
# Jepit chip flash (SOIC clip) ke programmer CH341A:
flashrom -p ch341a_spi -r dump.bin        # baca seluruh isi flash → lalu binwalk
```

### 4. Jaringan/protokol IoT
```bash
nmap -sV --script "mqtt-subscribe,upnp-info" <ip-device>
# MQTT tanpa auth → langganan semua topik (lihat data sensor/perintah):
mosquitto_sub -h <ip-broker> -t '#' -v
# CoAP discovery:
coap-client -m get coap://<ip>/.well-known/core
```

### 5. Radio (BLE contoh)
```bash
sudo bluetoothctl                         # scan perangkat BLE
sudo hcitool lescan
# Enumerasi service/karakteristik GATT (sering tanpa auth → kirim perintah):
gatttool -b <MAC-BLE> --characteristics
# Sniff/replay: Ubertooth (BLE), HackRF + Universal Radio Hacker (RF 433MHz)
```

### 6. Web/Cloud UI
```text
- Antarmuka admin perangkat = aplikasi web biasa → uji dengan teknik
  [[Web Application Hacking (OWASP Top 10)]] (default cred, IDOR, command injection).
- Command injection di field "ping/diagnostic" sangat umum di router IoT.
```

## 🛡️ Pertahanan (Hardening IoT)

| Risiko (OWASP IoT) | Mitigasi |
|---|---|
| Kredensial default/hardcoded | wajib ganti password saat setup; tak ada akun backdoor |
| Port debug terbuka | nonaktifkan UART/JTAG di produksi; lock bootloader |
| Layanan tak aman | matikan telnet/UPnP; MQTT pakai TLS + auth |
| Update tak aman | firmware **ter-tanda-tangani** (signed) + transport TLS |
| Firmware bocor rahasia | jangan hardcode kunci; enkripsi data sensitif at-rest |
| Eksposur jaringan | **segmentasi**: taruh IoT di VLAN sendiri ([[Lab — Hardening Perangkat Jaringan]]) |

> Pertahanan jaringan luas: [[Network Security (Firewall, IDS-IPS)]], [[Hardening & Vulnerability Management]]. Deteksi perilaku perangkat aneh (beaconing/exfil) via [[Network Security Lanjutan (NSM-NDR)]].

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **UART cuma tampil karakter sampah** → baud rate salah; coba 115200/57600/9600. Pastikan GND tersambung.
> - **`binwalk -e` tak mengekstrak filesystem** → firmware terenkripsi/dikompres custom; coba entropy analysis (`binwalk -E`) atau cari kunci di bootloader.
> - **TX/RX terbalik** → tak ada output; tukar dua kabel itu.
> - **Emulasi FirmAE gagal boot** → arsitektur tak terdeteksi; cek `binwalk` untuk ARM vs MIPS, jalankan manual di QEMU.
> - **Merusak perangkat (brick)** → pakai perangkat bekas/murah untuk belajar; jangan eksperimen di alat yang kamu butuhkan.

## 🧰 Tools

- **binwalk / firmware-mod-kit** — ekstrak & analisis firmware.
- **FirmAE / Firmadyne / QEMU** — emulasi firmware tanpa hardware.
- **IoTGoat / DVID** — target IoT sengaja-rentan (latihan).
- **screen / minicom** — UART serial console.
- **flashrom + CH341A / Bus Pirate** — dump SPI flash.
- **HackRF, RTL-SDR, Ubertooth, Universal Radio Hacker** — radio/RF.
- **mosquitto-clients, coap-client, bluetoothctl/gatttool** — protokol IoT & BLE.
- **Ghidra / radare2** — reverse engineering biner firmware (lihat [[Malware Analysis Dasar]]).

## 🔗 Kaitan

- Hub lab jaringan: [[Lab — Jaringan Vulnerable (Networking)]] (IoT = perangkat di jaringan).
- Firmware = analisis biner → teknik di [[Malware Analysis Dasar]]; kredensial → [[Password Attacks]].
- UI perangkat = web → [[Web Application Hacking (OWASP Top 10)]].
- Radio WiFi: [[Jaringan Nirkabel & 802.11 (WiFi)]] · [[Lab — WiFi Hacking (Wireless)]] (banyak IoT pakai WiFi).
- **Sisi Blue ↔** [[Network Security (Firewall, IDS-IPS)]], [[Hardening & Vulnerability Management]] (segmentasi VLAN IoT, signed update), deteksi via [[Network Security Lanjutan (NSM-NDR)]].
- Posisi di alur serang: jalur *Initial Access* alternatif → setelah kompromi, [[Post-Exploitation & Pivoting]] (IoT sebagai pijakan ke jaringan internal).

## 🎯 Latihan

- Tanpa hardware: emulasikan **IoTGoat** (OWASP) atau firmware router lama dengan **FirmAE**, lalu temukan minimal satu kredensial hardcoded via `binwalk -e` + `grep`.
- Ambil perangkat IoT bekas murah (smart plug/router), cari header **UART**, dan dapatkan serial console dengan `screen`.
- Jalankan broker **MQTT** lab tanpa auth, lalu `mosquitto_sub -t '#'` untuk membuktikan kamu bisa membaca semua pesan — lalu **aktifkan TLS+auth** dan buktikan kini gagal.
- (Defensif) Rancang **VLAN khusus IoT** di [[Lab — Hardening Perangkat Jaringan]] dan batasi aksesnya ke internet saja.

## 📖 Sumber

- **OWASP IoT Top 10** — https://owasp.org/www-project-internet-of-things/
- **OWASP IoTGoat** — https://github.com/OWASP/IoTGoat
- **Firmware Analysis (binwalk)** — https://github.com/ReFirmLabs/binwalk
- **FirmAE** — https://github.com/pr0v3rbs/FirmAE
- **The IoT Hacker's Handbook** — Aditya Gupta · **Practical IoT Hacking** (Fotios Chantzis dkk).
