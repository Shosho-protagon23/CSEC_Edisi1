# 🌐🧪 Lab — Jaringan Vulnerable (Networking)

> [!summary] Ringkasan
> Kalau [[Lab — VulnHub]] adalah "VM rentan untuk dilatih serang", maka **lab jaringan vulnerable** adalah padanannya untuk **perangkat jaringan**: router, switch, dan firewall (mis. Cisco) yang sengaja dikonfigurasi rentan agar kamu bisa melatih **serangan Layer-2/Layer-3** (ARP spoofing, VLAN hopping, routing attack) sekaligus **mengeraskannya** (hardening). Karena kamu tidak akan beli rak perangkat fisik, lab ini dibangun dengan **simulator/emulator** yang menjalankan OS jaringan asli di dalam komputermu. Catatan ini adalah **hub**: pahami simulasi vs emulasi, pilih platform, lalu ikuti note setup per-tool dan note offensive/defensive.

**Bagian dari:** [[Setup Lab (Virtualisasi)]] · [[Fondasi (MOC)]]
**Prasyarat:** [[Jaringan Komputer]], [[Model OSI & TCP-IP]] (paham IP, subnet, VLAN, routing), [[Setup Lab (Virtualisasi)]]

---

> [!warning] Tetap lab terisolasi
> Sama seperti VM rentan, perangkat & topologi rentan **tidak boleh** menyentuh jaringan rumah/produksi. Emulator menjalankan semuanya di dalam komputermu; saat menyambungkan ke VM luar (Kali), pakai jaringan **host-only/internal** ([[Lab — Setup Jaringan Lab]]). Latih serangan **hanya** di topologi milikmu sendiri.

## 🧠 Konsep Inti

### Simulasi vs Emulasi (beda mendasar, wajib paham dulu)
- **Simulator** — software yang **meniru perilaku** perangkat dengan kode tiruan. Ringan, mudah, tapi **tidak menjalankan OS asli** → fitur terbatas, beberapa serangan/command tidak ada. Contoh: **Cisco Packet Tracer**.
- **Emulator** — software yang **menjalankan image OS jaringan yang asli** (Cisco IOS/IOS-XE/NX-OS, Arista EOS, dll.) di atas mesin virtual/container. Realistis (perilaku = perangkat sungguhan), tapi lebih berat & butuh image. Contoh: **GNS3, EVE-NG, Cisco CML, Containerlab**.

> [!tip] Aturan memilih
> Belajar **konsep CCNA & topologi dasar** → cukup **Packet Tracer** (paling ramah pemula). Latihan **realistis + keamanan jaringan ofensif/defensif** (butuh perilaku OS asli, sambung Kali) → **emulator** (GNS3/EVE-NG/CML/Containerlab).

### Perbandingan platform

| Platform | Tipe | Biaya | Multivendor | Image jalan dari | Cocok untuk |
|---|---|---|---|---|---|
| **Cisco Packet Tracer** | Simulator | Gratis (akun NetAcad) | ❌ Cisco saja | built-in | Pemula, CCNA, konsep |
| **GNS3** | Emulator | Gratis (open source) | ✅ | image kamu sendiri (+GNS3 VM) | Lab realistis, fleksibel |
| **EVE-NG** | Emulator | Community gratis / Pro | ✅ | image kamu (web-based) | Lab besar multivendor |
| **Cisco CML** (Modeling Labs) | Emulator | Berbayar / CML-Free terbatas | ⚠️ utamanya Cisco | image **legal** bundled | Belajar Cisco resmi & legal |
| **Containerlab** | Emulator (container) | Gratis (open source) | ✅ (NOS container) | image container | NetDevOps, otomasi, cepat |

### Komponen sebuah lab jaringan
1. **Engine** — simulator/emulator di atas (pilih satu).
2. **Node perangkat** — router/switch/firewall (dari image OS).
3. **End host** — PC kecil untuk uji (VPCS di GNS3, atau VM Linux).
4. **Node "cloud"/NAT** — jembatan ke internet atau ke VM luar (mis. **Kali** untuk menyerang).
5. **Topologi** — kabel virtual antar node, dengan **VLAN/subnet** yang kamu rancang.

> [!danger] Soal legalitas image Cisco IOS
> Image **Cisco IOS/IOS-XE/NX-OS** dilindungi lisensi — kamu hanya boleh memakainya bila punya hak (kontrak, CML, atau perangkat resmi). **Jangan unduh dari sumber bajakan.** Alternatif **legal & gratis** untuk emulator: **Cisco CML-Free**, **IOSv/CSR1000v via CML/VIRL berlisensi**, atau NOS open-source: **FRRouting, VyOS, Arista cEOS (free), Nokia SR Linux, Cumulus VX**. Detail per note setup.

## 📂 Note dalam keluarga ini

**Setup per-tool (pilih sesuai kebutuhan):**
- 🟢 [[Lab — Cisco Packet Tracer (Setup)]] — simulator, **mulai dari sini** kalau masih pemula.
- 🔧 [[Lab — GNS3 (Setup)]] — emulator utama, paling fleksibel (GNS3 VM, sumber image, cloud node).
- 🌐 [[Lab — EVE-NG (Setup)]] — emulator web-based untuk lab besar multivendor.
- 📘 [[Lab — Cisco CML (Setup)]] — platform resmi Cisco dengan image legal.
- 📦 [[Lab — Containerlab (Setup)]] — lab berbasis container, cepat & cocok otomasi.

**Latihan keamanan (inti tujuanmu):**
- 🔴 [[Lab — Serangan Jaringan (Network Pentest)]] — serangan L2/L3 di topologi vulnerable + sambung Kali.
- 🔵 [[Lab — Hardening Perangkat Jaringan]] — mengeraskan router/switch terhadap serangan itu.
- 📶 [[Lab — WiFi Hacking (Wireless)]] — pelengkap **nirkabel** (butuh adapter fisik): monitor mode, capture/crack WPA2, evil twin, + hardening WPA3.
- 🔌 [[Lab — IoT & Embedded Hacking]] — perangkat **IoT/embedded**: hardware (UART/JTAG/SPI), firmware (binwalk), radio (BLE/Zigbee/RF), protokol (MQTT/CoAP), + OWASP IoT Top 10.
- 🏭 [[Lab — OT-ICS-SCADA Hacking]] — sistem **industri** (PLC/HMI/SCADA): protokol Modbus/S7/DNP3 tanpa auth, model Purdue, simulator OpenPLC/GRFICS, ATT&CK for ICS. ⚠️ keselamatan fisik.

**Otomasi (lanjutan):**
- Bahas di tiap note setup + ringkasan di [[Lab — Containerlab (Setup)]] (Ansible/Netmiko/pyATS).

## 🧰 Tools / Resource

- **Packet Tracer / GNS3 / EVE-NG / CML / Containerlab** — engine lab (lihat tabel).
- **VPCS / Tiny Core / Kali VM** — end host & penyerang di dalam topologi.
- **Wireshark** — sniff link virtual untuk lihat frame/paket ([[Network Security (Firewall, IDS-IPS)]]).
- **Cisco IOS CLI / FRR vtysh / VyOS** — antarmuka konfigurasi perangkat.

## 🔗 Kaitan

- **Dasar yang dipakai:** [[Jaringan Komputer]], [[Model OSI & TCP-IP]] (VLAN, routing, ARP, STP).
- **Beda dari** [[Lab — Setup Jaringan Lab]]: note itu soal **mengisolasi VM** (host-only); note ini soal **membangun perangkat jaringan rentan**. Keduanya dipakai bersama saat menyambungkan Kali ke topologi.
- **Sisi Blue ↔** [[Network Security (Firewall, IDS-IPS)]], [[Network Security Lanjutan (NSM-NDR)]], [[Hardening & Vulnerability Management]].
- **Sisi Red ↔** [[Reconnaissance (Information Gathering)]], [[Scanning & Enumeration]], [[Post-Exploitation & Pivoting]] (pivot/lateral lewat jaringan).

## 🎯 Latihan

- Pilih **satu** engine sesuai mesinmu (Packet Tracer kalau ragu), bangun topologi minimal **2 router + 1 switch + 2 PC**, beri IP, dan buktikan **ping antar-PC lintas router** berhasil.
- Setelah itu, baca [[Lab — Serangan Jaringan (Network Pentest)]] dan [[Lab — Hardening Perangkat Jaringan]] untuk membuat topologi tadi **rentan lalu mengeraskannya**.

## 📖 Sumber

- **Cisco Networking Academy (NetAcad)** — Packet Tracer & kurikulum CCNA: https://www.netacad.com
- **GNS3 Documentation** — https://docs.gns3.com
- **EVE-NG** — https://www.eve-ng.net
- **Cisco Modeling Labs (CML)** — https://developer.cisco.com/modeling-labs/
- **Containerlab** — https://containerlab.dev
