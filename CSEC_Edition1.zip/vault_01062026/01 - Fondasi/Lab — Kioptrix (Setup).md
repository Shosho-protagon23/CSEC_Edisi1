# 🐉 Lab — Kioptrix (Setup)

> [!summary] Ringkasan
> **Kioptrix** adalah seri VM boot-to-root legendaris (5 level, 2010–2014) yang selalu masuk daftar "mirip OSCP" untuk pemula. Berbeda dari [[Lab — Mr-Robot (Setup)|Mr-Robot]] yang berformat OVA, Kioptrix didistribusikan sebagai **arsip `.rar` berisi file VMware asli** (`.vmx` + `.vmdk`) — jadi **paling mulus di VMware**, sementara di VirtualBox kamu perlu import `.vmdk`-nya. Catatan ini = panduan setup untuk **kedua hypervisor** + kuirk khusus tiap level.

**Bagian dari:** [[Lab — VulnHub]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]], [[Lab — Setup Jaringan Lab]], [[Scanning & Enumeration]]

> [!info] Halaman resmi
> Seri: https://www.vulnhub.com/series/kioptrix,8/ · Blog author: http://www.kioptrix.com/blog/?page_id=135

---

## 🧠 Info Seri

Semua level dibuat oleh **Kioptrix**, format **VMware native**, jaringan **DHCP** (IP otomatis), tujuan **boot-to-root** ("dapatkan root dengan cara apa pun").

| Level | File unduh | Ukuran | OS | Vektor umum | Catatan khusus |
|---|---|---|---|---|---|
| **#1** (Level 1) | `Kioptrix_Level_1.rar` | 186 MB | Linux | mod_ssl, Samba/SMB | termudah, mulai dari sini |
| **#2** (Level 1.1) | `Kioptrix_Level_2-update.rar` | 406 MB | Linux | SQL Injection | pakai versi **update** (yg `-original` ada bug web app) |
| **#3** (Level 1.2) | `KVM3.rar` | 442 MB | Linux | web app + LotusCMS | **wajib** edit hosts → `kioptrix3.com` |
| **#5** (2014) | `kiop2014.tar.bz2` + `kiop2014_fix.zip` | 787 MB | **BSD** | web/PHP | rewel: lihat catatan #5 di bawah |

> [!tip] Urutan main
> Kerjakan berurutan **#1 → #2 → #3 → #5**. Tiap level menambah skill baru. **#1** adalah boot-to-root pertama yang ideal.

### Hash verifikasi (cocokkan setelah unduh — WAJIB)
```text
#1  MD5: 6DF1A7DFA555A220054FB98BA87FACD4   SHA1: 98CA3F4C079254E6B272265608E7D22119350A37
#2  MD5: 987FFB98117BDEB6CA0AAC6EA22E755D   SHA1: 7A0EA0F414DFA0E05B7DF504F21B325C6D3CC53B   (update.rar)
#3  MD5: D324FFADD8E3EFC1F96447EEC51901F2   SHA1: 121348AA8DD5F83640145D4F8E042C8DE0A78F3F
#5  MD5: 1F802308F7F9F52A7A0D973FBDA22C0A   SHA1: 116EB311B91B28731855575A9157043666230432   (kiop2014.tar.bz2)
```
```bash
md5sum Kioptrix_Level_1.rar      # Linux
```
```powershell
Get-FileHash Kioptrix_Level_1.rar -Algorithm MD5    # Windows
```

---

## 1️⃣ Unduh & ekstrak

Ambil arsip dari mirror VulnHub (contoh #1):
```bash
wget https://download.vulnhub.com/kioptrix/Kioptrix_Level_1.rar
```
Mirror lain:
```text
#2  https://download.vulnhub.com/kioptrix/Kioptrix_Level_2-update.rar
#3  https://download.vulnhub.com/kioptrix/Kioptrix_Level_1.2.rar  (atau cari "KVM3.rar" di halaman)
#5  https://download.vulnhub.com/kioptrix/kiop2014.tar.bz2
```
Ekstrak arsipnya — di dalamnya ada file VMware (`*.vmx`, `*.vmdk`):
```bash
unrar x Kioptrix_Level_1.rar          # .rar  → butuh paket "unrar"
tar -xjf kiop2014.tar.bz2             # .tar.bz2 (level #5)
```

---

## 🟩 Setup A — VMware (jalur termudah)

Karena file aslinya VMware, kamu cukup **buka `.vmx`**-nya.

```text
VMware → File → Open… → pilih file .vmx hasil ekstrak → Play
```
Saat pertama dinyalakan muncul dialog **"Moved it / Copied it"** → pilih **"I Copied It"** (agar MAC di-generate ulang).

### Jaringan
```text
VM Settings → Network Adapter → Host-only (VMnet1)   — sama dgn Kali
```
Catat subnet VMnet1 dari **Virtual Network Editor**. Mesin DHCP-enabled → dapat IP otomatis.

> [!warning] Khusus #5 (Kioptrix 2014, BSD)
> VM ini rewel:
> - Author bilang **"remove the network card and re-add it"** sebelum power-on, kalau tidak ia gagal dapat IP.
> - Author menyarankan **bridge mode**; di lab pribadi tetap **lebih aman host-only** — kalau host-only tak dapat IP, baru pertimbangkan bridged (lihat peringatan bridged di [[Setup Lab (Virtualisasi)]]).
> - Terkonfirmasi jalan di **VMware Player 6 / Workstation 10 / Fusion 6**. Terapkan `kiop2014_fix.zip` bila perlu.

---

## 🟦 Setup B — VirtualBox (import `.vmdk`)

VirtualBox tak punya `.ova`, jadi kamu buat VM kosong lalu pasang disk `.vmdk` hasil ekstrak.

```text
VirtualBox → New
  Name: Kioptrix-1 · Type: Linux · Version: Other Linux (64-bit) (atau 32-bit utk VM lama)
  Memory: 512–1024 MB
  Hard disk: "Use an existing virtual hard disk file" → pilih file .vmdk Kioptrix
  → Create
```
(Pola sama seperti memasang `.vmdk` di [[Lab — Metasploitable]].)

### Jaringan + fix MAC
```text
VM → Settings → Network → Adapter 1
  Attached to: Host-only Adapter (sama dgn Kali)
  Advanced → klik tombol refresh untuk REGENERATE MAC address
```
> [!warning] VM lama sering tak dapat IP di VirtualBox
> Kioptrix dibuat untuk VMware, beberapa level (terutama **#5 / BSD**) bisa bermasalah jaringan atau boot di VirtualBox. Untuk VirtualBox 4.3+ coba set sebagai **mesin x64** dulu. Jika tetap bandel, jalankan saja di **VMware** (jalur A) — itu lingkungan aslinya.

---

## 🌐 Khusus #3 — edit file hosts (WAJIB)

Web app Kioptrix #3 hanya tampil benar lewat hostname `kioptrix3.com`. Setelah dapat IP target, petakan:

- **Linux (Kali):** `/etc/hosts`
- **Windows:** `C:\Windows\System32\drivers\etc\hosts`

Tambahkan baris (ganti IP sesuai target):
```text
192.168.56.101   kioptrix3.com
```
Tanpa ini, halaman web tampil rusak dan beberapa langkah enum gagal.

---

## 🎯 Setelah mesin hidup — boot-to-root

Langkah ini sama untuk semua hypervisor & level.

### 1. Temukan IP target (tak ada login!)
```bash
ip a
sudo netdiscover -i eth1 -r 192.168.56.0/24
# atau:
sudo arp-scan --interface=eth1 --localnet
nmap -sn 192.168.56.0/24
```

### 2. Enum & serang
```bash
nmap -sC -sV -p- <ip-kioptrix>
```
Lanjut sesuai temuan → [[Web Application Hacking (OWASP Top 10)]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]] → baca file root. Ambil **snapshot bersih** sebelum menyerang.

---

## 🧰 Tools

- **VMware / VirtualBox** — VMware = native, VirtualBox = import `.vmdk`.
- **unrar / tar** — ekstrak arsip `.rar` / `.tar.bz2`.
- **netdiscover / arp-scan / nmap -sn** — temukan IP target.
- **nmap, gobuster, Burp, Metasploit, sqlmap** — fase serang ([[Scanning & Enumeration]] dst).

## 🔗 Kaitan

- Hub VulnHub & langkah generik: [[Lab — VulnHub]].
- Contoh setup OVA (perbandingan): [[Lab — Mr-Robot (Setup)]].
- Memasang `.vmdk` di VirtualBox: [[Lab — Metasploitable]].
- Setup jaringan & troubleshooting MAC: [[Lab — Setup Jaringan Lab]].
- Hub lab: [[Setup Lab (Virtualisasi)]].
- Alur serang: [[Reconnaissance (Information Gathering)]] → [[Scanning & Enumeration]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]].

## 🎯 Latihan

- Setup **Kioptrix #1** sampai bisa `ping` target dari Kali, lalu selesaikan **boot-to-root** (coba dua vektor: mod_ssl & Samba). Tulis write-up di vault.
- Lanjut #2 (SQLi) → #3 (jangan lupa hosts `kioptrix3.com`) → #5.

## 📖 Sumber

- **VulnHub — Kioptrix series** — https://www.vulnhub.com/series/kioptrix,8/
- **Kioptrix #1** — https://www.vulnhub.com/entry/kioptrix-level-1-1,22/
- **Blog author Kioptrix** — http://www.kioptrix.com/blog/?page_id=135
- Daftar "mirip OSCP" (TJnull): cari Kioptrix di urutan latihan terbaik.
