# 🟢 Lab — Metasploitable (2 & 3)

> [!summary] Ringkasan
> **Metasploitable** adalah VM Linux yang **sengaja dibuat penuh kerentanan** oleh Rapid7 (pembuat Metasploit) sebagai target latihan resmi. Ini target **pertama** terbaik untuk pemula: jaringannya bersahabat, banyak port terbuka, dan cocok dipasangkan dengan [[Exploitation & Metasploit]].

**Bagian dari:** [[Setup Lab (Virtualisasi)]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]] (hypervisor & mode jaringan sudah paham), [[Linux Dasar untuk Security]]

---

## 🧠 Konsep Inti

Ada dua versi:
- **Metasploitable 2** — paling mudah & legendaris. Satu file disk **.vmdk** siap pakai. **Rekomendasi untuk mulai.**
- **Metasploitable 3** — lebih realistis (Ubuntu & Windows Server), tapi dibangun via **Vagrant/Packer** (lebih rumit). Lewati dulu sampai kamu nyaman.

> [!warning] Jaringan
> Metasploitable sangat rentan. **Wajib Host-Only / Internal Network.** Jangan pernah Bridged/NAT terbuka ke internet. Lihat tabel jaringan di [[Setup Lab (Virtualisasi)]].

## ⚙️ Cara Kerja / Praktik — Metasploitable 2 (VirtualBox)

### 1. Unduh
- Sumber resmi: SourceForge → cari **"Metasploitable2"** (`metasploitable-linux-2.0.0.zip`).
- Ekstrak ZIP → akan ada folder berisi file **`Metasploitable.vmdk`** (+ file pendukung).

### 2. Buat VM kosong dan pasang disk-nya
Karena yang kamu dapat adalah *disk* (.vmdk), bukan paket .ova, kamu buat VM lalu tunjuk ke disk itu:

```text
VirtualBox → New
  Name: Metasploitable2
  Type: Linux   |   Version: Ubuntu (64-bit)
  Memory: 512–1024 MB
  Hard disk: ▸ "Use an existing virtual hard disk file"
            → pilih Metasploitable.vmdk hasil ekstrak
  Create
```

### 3. Atur jaringan ke Host-Only
```text
VM → Settings → Network → Adapter 1
  Attached to: Host-only Adapter
  (pastikan adapter host-only yang SAMA dengan Kali, mis. vboxnet0)
```

### 4. Nyalakan & login (opsional)
Boot VM. Kredensial default:
```text
login:    msfadmin
password: msfadmin
```
Di dalamnya kamu bisa cek IP:
```bash
ip a        # atau: ifconfig
```

### 5. Temukan target dari Kali (cara realistis — tanpa login)
Dalam latihan nyata kamu **tidak** login ke target; kamu temukan via scan dari Kali:
```bash
# Dari Kali, di subnet host-only (sesuaikan)
sudo netdiscover -i eth1 -r 192.168.56.0/24
nmap -sn 192.168.56.0/24          # daftar IP hidup

# Setelah dapat IP target, scan port
nmap -sV -p- <ip-metasploitable>  # banyak port terbuka: 21,22,23,80,445,3306,...
```

### 6. Snapshot
Ambil snapshot **"fresh"** sebelum menyerang (lihat [[Setup Lab (Virtualisasi)]]).

## 🧰 Tools

- **VirtualBox/VMware** — menjalankan VM.
- **nmap / netdiscover** — menemukan & memetakan target ([[Scanning & Enumeration]]).
- **Metasploit (`msfconsole`)** — eksploitasi ([[Exploitation & Metasploit]]).

## 🔗 Kaitan

- Pakai untuk latihan: [[Scanning & Enumeration]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]].
- Sisi Blue: port & layanan rentan di sini = bahan latihan [[Hardening & Vulnerability Management]] & [[Log Analysis & Monitoring]] (lihat log serangan yang kamu buat sendiri).
- Hub lab: [[Setup Lab (Virtualisasi)]].

## 🎯 Latihan

- `nmap -sV` ke Metasploitable 2, daftar **semua** layanan terbuka, catat versi tiap service.
- Eksploitasi service **vsftpd 2.3.4** (backdoor terkenal) lewat [[Exploitation & Metasploit]] → dapatkan shell pertama.

## 📖 Sumber

- **Rapid7 — Metasploitable docs**: https://docs.rapid7.com/metasploit/metasploitable-2/
- **Metasploitable 3 (GitHub)**: https://github.com/rapid7/metasploitable3
- **TryHackMe — "Metasploit" rooms** (alternatif tanpa setup lokal).
