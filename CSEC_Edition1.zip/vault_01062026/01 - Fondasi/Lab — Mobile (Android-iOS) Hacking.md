# 📱 Lab — Mobile (Android/iOS) Hacking

> [!summary] Ringkasan
> Padanan **mobile** dari [[Web Application Hacking (OWASP Top 10)|web app hacking]]: menguji keamanan aplikasi Android (`.apk`) & iOS (`.ipa`). Tiga sudut serang: **storage** (data sensitif disimpan tak aman di perangkat), **komunikasi** (traffic ke API → intercept dengan proxy), dan **biner** (reverse-engineer kode, tembus root/jailbreak detection & cert pinning pakai **Frida**). Berbingkai **OWASP MASVS/MASTG**. Note ini = setup lab (emulator + Burp + Frida + objection), alur static & dynamic analysis, lalu pertahanan. Uji **hanya aplikasi milikmu / yang diizinkan**.

**Bagian dari:** [[Fondasi (MOC)]]
**Prasyarat:** [[Linux Dasar untuk Security]], [[Setup Lab (Virtualisasi)]], [[Web Application Hacking (OWASP Top 10)]] (banyak bug mobile = bug di API back-end-nya); berguna: [[Malware Analysis Dasar]] (reverse engineering)

---

> [!danger] Etika
> Uji hanya **aplikasi milikmu sendiri**, aplikasi sengaja-rentan, atau dalam **engagement berizin**. Membongkar/memodifikasi aplikasi orang lain bisa melanggar hukum & ToS. Reverse engineering untuk riset keamanan umumnya sah; distribusi ulang aplikasi/IP tidak. Lihat [[00 - START HERE]].

## 🧠 Konsep Inti

### Android vs iOS (perbedaan yang mengubah pendekatan)
| Aspek | Android | iOS |
|---|---|---|
| Paket | **APK/AAB** (ZIP berisi DEX) | **IPA** (ZIP berisi Mach-O) |
| Bahasa | Java/Kotlin → **DEX bytecode** | Objective-C/Swift → biner native |
| Lab | **emulator gratis** (AVD/Genymotion), mudah di-root | butuh **Mac + perangkat ber-jailbreak** (simulator terbatas) |
| Reverse | jadex/apktool/JADX (mudah) | Hopper/Ghidra/class-dump (lebih sulit) |
| Sandbox | per-app UID, permission | sandbox ketat, entitlements |

> iOS jauh lebih menyulitkan untuk pemula (perlu hardware Apple + jailbreak). **Mulai dari Android.**

### Tiga area uji (model MASVS)
1. **Penyimpanan lokal** — data sensitif di `SharedPreferences`, SQLite, file, log, atau keychain/keystore yang lemah.
2. **Komunikasi jaringan** — apakah pakai TLS? Ada **certificate pinning**? Traffic ke API bisa di-intercept?
3. **Ketahanan biner** — root/jailbreak detection, anti-debug, obfuscation, cert pinning — bisa di-**bypass** dengan instrumentasi runtime (Frida).

### OWASP MASVS / MASTG
**MASVS** = standar verifikasi keamanan mobile (checklist requirement). **MASTG** = manual teknik testing + **MAS Checklist**. Inilah kerangka acuan profesional (pengganti "OWASP Mobile Top 10" lama).

## 🛠️ Setup Lab Mobile (fokus Android)

```bash
# 1. SDK + emulator (atau Genymotion). Buat AVD tanpa Google Play → mudah di-root.
sudo apt install adb apktool jadx
# 2. Burp Suite sebagai proxy (intercept HTTPS) — lihat [[Web Application Hacking (OWASP Top 10)]]
# 3. Frida (instrumentasi runtime) + objection (wrapper siap pakai)
pip install frida-tools objection
# 4. Perangkat/emulator terhubung:
adb devices
adb install target.apk
```
> **iOS:** butuh Mac + perangkat jailbreak (checkra1n/palera1n), lalu **Frida**, **objection**, **Cydia/Sileo**. Alur konsep sama; tooling berbeda.

### Lab aplikasi sengaja-rentan (latihan legal)
- **DIVA / InsecureBankv2 / OWASP MASTG crackmes** (Android) · **DVIA-v2** (iOS) · **Pixel-perfect: Android Goat**.

## ⚔️ Praktik

### 1. Static analysis — bongkar APK
```bash
# Decompile ke smali + resource (manifest, string, dll.)
apktool d target.apk -o target_src
# Decompile ke Java (baca logika):
jadx -d out target.apk     # atau buka di jadx-gui
# Cari rahasia hardcoded:
grep -rIn "http://\|api_key\|secret\|password\|BEGIN " target_src/
# Cek AndroidManifest: komponen exported, permission berlebih, debuggable=true
```

### 2. Intercept traffic (dynamic — API testing)
```bash
# Arahkan proxy emulator ke Burp; pasang CA Burp sebagai system cert.
# Jika app pakai certificate pinning → bypass dengan objection/Frida:
objection -g com.target.app explore
#   > android sslpinning disable        (Android)
#   > ios sslpinning disable            (iOS)
# Setelah pinning mati → semua traffic API tampil di Burp →
# uji seperti web: IDOR, auth bypass, dll ([[Web Application Hacking (OWASP Top 10)]]).
```

### 3. Bypass root/jailbreak detection & instrumentasi Frida
```bash
frida-ps -U                                  # daftar proses di perangkat (USB)
objection -g com.target.app explore
#   > android root disable                   (sembunyikan root)
#   > android hooking list classes           (telusuri kelas)
#   > android hooking watch class_method ...  (intip argumen/return)
# Script Frida custom untuk hook fungsi tertentu (mis. paksa return "true"):
frida -U -f com.target.app -l bypass.js
```

### 4. Periksa penyimpanan lokal
```bash
adb shell run-as com.target.app ls -la /data/data/com.target.app/
# Tarik & periksa SharedPreferences/SQLite untuk token/PII:
adb pull /data/data/com.target.app/shared_prefs/
sqlite3 database.db ".tables"
adb logcat | grep -i "token\|password"       # rahasia bocor ke log?
```

## 🛡️ Pertahanan (Mobile App Hardening)

| Risiko (MASVS) | Mitigasi |
|---|---|
| Data sensitif di storage | pakai **Keystore/Keychain**, jangan simpan plaintext; jangan log rahasia |
| Traffic bisa di-intercept | **TLS + certificate pinning**; tolak proxy/user-CA |
| Reverse engineering mudah | **obfuscation** (R8/ProGuard), strip debug, anti-tamper |
| Root/jailbreak | **deteksi** + degrade fungsi (sadar bisa di-bypass → defense-in-depth) |
| Rahasia hardcoded | jangan taruh API key/secret di biner; rotasi via back-end |
| Komponen exported | minimalkan exported activity/provider; validasi input antar-app |

> Bug terbesar mobile sering ada di **API back-end** → kerasankan juga sisi server ([[Web Application Hacking (OWASP Top 10)]], [[Hardening & Vulnerability Management]]). Aplikasi yang ter-tamper bisa jadi **malware** → [[Malware Analysis Dasar]].

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **Burp tak lihat HTTPS** → CA belum jadi *system cert* (Android 7+ tak percaya user-CA untuk app), atau ada **cert pinning** → pakai objection.
> - **`frida-ps -U` kosong** → frida-server tak jalan di perangkat / arsitektur salah (cek `getprop ro.product.cpu.abi`).
> - **App crash saat dibuka (anti-tamper)** → ada root/debug detection; bypass lebih dulu dengan Frida.
> - **`run-as` ditolak** → app tidak `debuggable`; pakai emulator yang di-root atau patch APK.
> - **iOS macet di setup** → simulator tak menjalankan biner ARM real; perlu perangkat jailbreak fisik.

## 🧰 Tools

- **adb / apktool / JADX** — interaksi perangkat & decompile Android.
- **Frida / objection** — instrumentasi runtime, bypass pinning & root detection (Android+iOS).
- **Burp Suite / mitmproxy** — intercept & uji API ([[Web Application Hacking (OWASP Top 10)]]).
- **MobSF (Mobile Security Framework)** — analisis statis+dinamis otomatis (APK/IPA) — bagus untuk mulai.
- **Genymotion / Android Studio AVD** — emulator. **checkra1n/palera1n** — jailbreak iOS.
- **Ghidra / Hopper / class-dump** — reverse biner native (iOS) → [[Malware Analysis Dasar]].

## 🔗 Kaitan

- Padanan & inti bug: [[Web Application Hacking (OWASP Top 10)]] (back-end API aplikasi mobile).
- **Uji API back-end secara mendalam:** [[API Hacking (REST-GraphQL)]] (BOLA/BFLA, GraphQL) — banyak bug mobile sebenarnya bug API.
- Reverse engineering biner: [[Malware Analysis Dasar]] (DEX/Mach-O, Ghidra) & [[Reverse Engineering untuk Offense]].
- Kredensial/token yang ditemukan → [[Password Attacks]].
- **Sisi Blue ↔** [[Hardening & Vulnerability Management]] (hardening app & API), [[Malware Analysis Dasar]] (APK jahat).
- Posisi di alur serang: domain target tersendiri di [[Red Team (MOC)]] (sejajar web & cloud).
- Berbatasan: [[Lab — IoT & Embedded Hacking]] (aplikasi pendamping IoT sering jadi pintu).

## 🎯 Latihan

- Pasang emulator + **DIVA** atau **InsecureBankv2**, lalu temukan minimal satu rahasia via `jadx` + `grep` dan satu data sensitif di `shared_prefs`.
- Intercept traffic aplikasi lab dengan **Burp**; bila ada pinning, matikan dengan **objection** dan uji API-nya seperti web.
- Tulis **script Frida** sederhana untuk mem-bypass root detection (paksa fungsi cek-root me-return `false`).
- Jalankan **MobSF** pada satu APK lab dan baca laporan otomatisnya, lalu verifikasi satu temuannya secara manual.

## 📖 Sumber

- **OWASP MASVS & MASTG** — https://mas.owasp.org
- **Frida** — https://frida.re · **objection** — https://github.com/sensepost/objection
- **MobSF** — https://github.com/MobSF/Mobile-Security-Framework-MobSF
- **DIVA / InsecureBankv2 / DVIA-v2** — aplikasi rentan untuk latihan.
- **HackTricks — Mobile** & **TryHackMe / HTB mobile modules**.
