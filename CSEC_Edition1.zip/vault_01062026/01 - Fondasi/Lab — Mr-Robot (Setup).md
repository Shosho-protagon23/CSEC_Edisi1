# 🤖 Lab — Mr-Robot (Setup)

> [!summary] Ringkasan
> **Mr-Robot: 1** adalah mesin VulnHub klasik untuk pemula (dirilis 28 Jun 2016, author *Leon Johnson*, terinspirasi serial TV *Mr. Robot*). Tingkat **beginner–intermediate**, target boot-to-root dengan **3 key** tersembunyi yang makin sulit ditemukan. Catatan ini = panduan setup lengkap `mrRobot.ova` untuk **dua hypervisor**: **VirtualBox** dan **VMware**.

**Bagian dari:** [[Lab — VulnHub]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]], [[Lab — Setup Jaringan Lab]], [[Scanning & Enumeration]]

> [!info] Halaman resmi
> https://www.vulnhub.com/entry/mr-robot-1,151/

---

## 🧠 Info Mesin

| Atribut | Nilai |
|---|---|
| Nama | Mr-Robot: 1 |
| File | `mrRobot.ova` (~704 MB) |
| Format asli | VirtualBox OVA |
| OS | Linux |
| Jaringan | **DHCP enabled** (IP otomatis) |
| Login awal | ❌ tidak ada (harus cari IP sendiri) |
| Tujuan | boot-to-root, temukan **3 key** (`key-1-of-3.txt` … `key-3-of-3.txt`) |
| Kesulitan | beginner–intermediate |

> [!tip] Kenapa relatif mudah
> Tidak perlu reverse engineering / exploit canggih. Jaringan sudah **DHCP**, jadi tidak ada drama "interface terkunci ke MAC" seperti VM VulnHub lama. Fokusmu murni di enumerasi web → user → privesc.

---

## 1️⃣ Unduh dari situs resmi VulnHub

Buka [halaman resmi](https://www.vulnhub.com/entry/mr-robot-1,151/) → bagian **Download** → ambil `.ova`:

```text
File   : mrRobot.ova
Ukuran : ~704 MB
Mirror : https://download.vulnhub.com/mrrobot/mrRobot.ova
```

Via terminal Kali:
```bash
wget https://download.vulnhub.com/mrrobot/mrRobot.ova
```

## 2️⃣ Verifikasi integritas file (WAJIB)

Cocokkan hash dengan yang tertera di halaman resmi agar file tidak korup / tidak dipalsukan:

```text
MD5  : BC02C42815EAC4E872D753E1FD12DDC8
SHA1 : DC0EB84DA4C62284C688590EE092868CE84A09AB
```

Cek di Kali/Linux:
```bash
md5sum mrRobot.ova
sha1sum mrRobot.ova
```

Cek di PowerShell (Windows):
```powershell
Get-FileHash mrRobot.ova -Algorithm MD5
Get-FileHash mrRobot.ova -Algorithm SHA1
```

Hasil harus **sama persis** (huruf besar/kecil diabaikan). Kalau beda → unduh ulang.

---

## 🟦 Setup A — VirtualBox

Format aslinya memang OVA VirtualBox, jadi ini jalur termudah.

### A.1 Import appliance
```text
VirtualBox → File → Import Appliance…
  → pilih mrRobot.ova → Next
  → centang "Reinitialize the MAC address of all network cards"
  → Import
```
Mencentang **reinitialize MAC** mencegah masalah jaringan klasik VulnHub sejak awal.

### A.2 Set jaringan Host-Only
```text
VM mrRobot → Settings → Network → Adapter 1
  Attached to: Host-only Adapter   (host-only yang SAMA dengan Kali)
```
Karena mesin DHCP-enabled, ia akan dapat IP otomatis di subnet host-only (mis. `192.168.56.0/24`).

> [!tip] Resep aman
> Kali: Adapter 1 = NAT (internet), Adapter 2 = Host-Only. mrRobot: cukup 1 adapter = Host-Only sama. Lihat pola lengkap di [[Setup Lab (Virtualisasi)]].

### A.3 Nyalakan & ambil snapshot bersih
```text
VirtualBox → mrRobot → tab Snapshots → Take → nama: "fresh"
```

---

## 🟩 Setup B — VMware (Workstation / Player / Fusion)

VMware bisa meng-import OVA, tapi sering perlu sedikit penyesuaian.

### B.1 Import OVA
Cara GUI:
```text
VMware → File → Open… → pilih mrRobot.ova → beri nama → Import
```
Jika import gagal karena pemeriksaan OVF ketat (umum di VM lama), pakai **ovftool** dengan relax flag:
```bash
ovftool --lax --allowExtraConfig mrRobot.ova mrRobot.vmx
```
> [!note] OVF spec strict
> OVA buatan VirtualBox kadang ditolak VMware ("did not pass OVF specification conformance"). Tombol **Retry** di dialog biasanya cukup; kalau tidak, `ovftool --lax` di atas memaksanya tetap dikonversi.

### B.2 Set jaringan Host-Only (VMnet1)
```text
VM Settings → Network Adapter
  → pilih "Host-only" (VMnet1)   — host-only yang SAMA dengan Kali
```
Catat subnet VMnet1 dari **Virtual Network Editor** (mis. `192.168.149.0/24`). Detail di [[Lab — Setup Jaringan Lab]].

### B.3 Jika jaringan mati setelah import (fix MAC)
Gejala klasik VM lama: interface "terkunci" ke MAC address asli pembuat → tidak dapat IP di VMware.
**Perbaikan:** tutup VM, edit file `mrRobot.vmx`, **hapus** baris yang mengunci MAC:
```text
ethernet0.address = "..."
ethernet0.addressType = "static"
ethernet0.generatedAddress = "..."
ethernet0.checkMACAddress = "..."
```
Lalu tambahkan / pastikan ada:
```text
ethernet0.addressType = "generated"
```
Nyalakan lagi → VMware generate MAC baru → DHCP jalan. (Lihat juga troubleshooting di [[Lab — Setup Jaringan Lab]].)

### B.4 Snapshot bersih
```text
VM → Snapshot → Take Snapshot → nama: "fresh"
```

---

## 🎯 Setelah mesin hidup — boot-to-root

Langkah ini **sama** untuk VirtualBox maupun VMware.

### 1. Temukan IP target (tak ada login!)
```bash
ip a                                         # cek subnet host-only-mu
sudo netdiscover -i eth1 -r 192.168.56.0/24  # VirtualBox; ganti subnet utk VMware
# atau:
sudo arp-scan --interface=eth1 --localnet
nmap -sn 192.168.56.0/24
```
IP baru (bukan Kali, bukan gateway, bukan host DHCP) = target.

### 2. Enum & serang
```bash
nmap -sC -sV -p- <ip-mr-robot>     # 80/443 terbuka → mulai dari web
```
Lanjut sesuai temuan → [[Web Application Hacking (OWASP Top 10)]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]]. Targetnya kumpulkan ketiga key sampai `key-3-of-3.txt`.

---

## 🧰 Tools

- **VirtualBox / VMware** — jalankan `.ova`.
- **ovftool** — konversi/import paksa OVA ke VMware (`--lax`).
- **netdiscover / arp-scan / nmap -sn** — temukan IP target.
- **nmap, gobuster, Burp, Metasploit** — fase serang ([[Scanning & Enumeration]] dst).

## 🔗 Kaitan

- Hub VulnHub & langkah generik: [[Lab — VulnHub]].
- Setup jaringan lintas-hypervisor & troubleshooting MAC: [[Lab — Setup Jaringan Lab]].
- Hub lab: [[Setup Lab (Virtualisasi)]].
- Alur serang: [[Reconnaissance (Information Gathering)]] → [[Scanning & Enumeration]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]].

## 🎯 Latihan

- Setup `mrRobot.ova` di **salah satu** hypervisor sampai bisa `ping` target dari Kali.
- Selesaikan **boot-to-root**: temukan ketiga key. Tulis langkahmu sebagai write-up di vault ini.

## 📖 Sumber

- **VulnHub — Mr-Robot: 1** — https://www.vulnhub.com/entry/mr-robot-1,151/
- **Mirror download** — https://download.vulnhub.com/mrrobot/mrRobot.ova
- **VMware ovftool** — dokumentasi resmi VMware untuk konversi OVA.
