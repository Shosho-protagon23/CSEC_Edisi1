# 🔵 Lab — Platform Lab Lainnya

> [!summary] Ringkasan
> Selain [[Lab — Metasploitable]], [[Lab — VulnHub]], dan [[Lab — Vulnyx]], ada banyak sumber target lain — sebagian **VM lokal** (kamu host sendiri), sebagian **online** (tanpa setup). Catatan ini merangkum yang paling berguna untuk pemula dan **kapan memilih masing-masing**.

**Bagian dari:** [[Setup Lab (Virtualisasi)]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]]

---

## 🧠 Konsep Inti: lokal vs online

| | **VM Lokal** (VulnHub/Vulnyx/Metasploitable) | **Online** (TryHackMe/HTB/PG) |
|---|---|---|
| Setup | perlu hypervisor + import | tinggal browser/VPN |
| Internet | tidak perlu saat main | perlu koneksi |
| Kontrol | penuh (snapshot, offline) | terbatas, ada batas waktu |
| Biaya | gratis | banyak gratis, sebagian berbayar |
| Cocok untuk | latihan mendalam & offline | mulai cepat, materi terstruktur |

> [!tip] Saran
> **Pemula total:** mulai **online** (TryHackMe) untuk struktur, lalu pindah ke **VM lokal** untuk kebebasan & latihan tanpa batas. Lihat alur di [[Sumber Belajar & Platform Latihan]].

## ⚙️ Platform & Cara Setup-nya

### A. HackMyVM — VM lokal (saudara dekat Vulnyx)
- https://hackmyvm.eu — koleksi VM boot-to-root gratis, alur **identik** [[Lab — VulnHub]].
- **Setup:** unduh `.ova`/arsip → Import Appliance → Host-only → `netdiscover` cari IP. Jika jaringan mati → regenerate MAC.

### B. Proving Grounds (PG Play / PG Practice) — online, by OffSec
- https://www.offsec.com/labs/ — mesin gaya OSCP dari pembuat OSCP. **PG Play** punya tier gratis.
- **Setup:** daftar OffSec → connect **OpenVPN** dari Kali → mesin diberi IP, langsung `nmap`. Tak perlu import VM.
```bash
sudo openvpn ~/Downloads/pg.ovpn   # sambungkan ke lab, lalu serang IP target
```

### C. Web app rentan — untuk [[Web Application Hacking (OWASP Top 10)]]
VM/target web yang dijalankan lokal (paling cepat lewat **Docker** di Kali):
- **DVWA** (Damn Vulnerable Web App):
```bash
docker run -d -p 80:80 vulnerables/web-dvwa
# buka http://localhost  (login admin/password)
```
- **OWASP Juice Shop** (web app modern, OWASP Top 10):
```bash
docker run -d -p 3000:3000 bkimminich/juice-shop
# buka http://localhost:3000
```
- **OWASP Broken Web Apps (BWA)** — satu .ova berisi banyak web rentan sekaligus (import seperti [[Lab — VulnHub]]).

### D. Windows / Active Directory lab — untuk [[Active Directory Attacks]]
- **Metasploitable 3 (Windows)** atau lab AD buatan sendiri pakai **GOAD** → step-by-step lengkap di [[Lab — AD Lab Lokal (GOAD)]] (lanjutan, butuh RAM besar).
- Pemula AD sebaiknya mulai di **TryHackMe / HTB** dulu sebelum membangun AD lokal.

### E. Online terstruktur (tanpa setup) — rekap
- **TryHackMe**, **Hack The Box**, **PortSwigger Web Security Academy**, **LetsDefend** (Blue). Detail & link di [[Sumber Belajar & Platform Latihan]].

## 🧰 Tools

- **VirtualBox/VMware** — VM lokal (HackMyVM, BWA).
- **Docker** (di Kali) — cara tercepat menjalankan DVWA/Juice Shop.
- **OpenVPN** — menyambung ke lab online (PG, HTB, THM).

## 🔗 Kaitan

- Target web → [[Web Application Hacking (OWASP Top 10)]].
- Target AD → [[Active Directory Attacks]].
- Sisi Blue (latih deteksi serangan yang kamu buat) → [[Log Analysis & Monitoring]], [[Hardening & Vulnerability Management]].
- Daftar platform lengkap + komunitas: [[Sumber Belajar & Platform Latihan]].
- Hub lab: [[Setup Lab (Virtualisasi)]].

## 🎯 Latihan

- Jalankan **Juice Shop** via Docker, selesaikan 3 challenge level termudah.
- Connect ke **PG Play** (gratis) dan selesaikan satu mesin "easy".

## 📖 Sumber

- **HackMyVM** — https://hackmyvm.eu
- **OffSec Proving Grounds** — https://www.offsec.com/labs/
- **OWASP Juice Shop** — https://owasp.org/www-project-juice-shop/
- **GOAD (AD lab)** — https://github.com/Orange-Cyberdefense/GOAD
