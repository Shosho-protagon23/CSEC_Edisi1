# 🌐 Lab — Setup Jaringan Lab

> [!summary] Ringkasan
> Bagian **paling sering bikin pemula stuck**: bagaimana agar VM penyerang (Kali) dan mesin rentan **saling lihat**, tapi **terisolasi** dari jaringan rumah & internet. Caranya berbeda per hypervisor. Catatan ini berisi langkah konkret untuk **VirtualBox**, **VMware**, plus **Hyper-V** & **QEMU/KVM**.

**Bagian dari:** [[Setup Lab (Virtualisasi)]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]] (paham konsep mode jaringan), [[Jaringan Komputer]] (paham IP & subnet)

---

## 🧠 Konsep Inti (berlaku di semua hypervisor)

Apa pun hypervisor-nya, kamu hanya butuh memetakan 3 mode yang sama:

| Yang kamu mau | Mode (nama bisa beda) | Internet? | VM saling lihat? |
|---|---|---|---|
| **Isolasi + tetap bisa update Kali** | Host-Only (+ NAT terpisah) | ✅ via NAT | ✅ |
| **Isolasi total** | Internal / LAN Segment / Private | ❌ | ✅ |
| **Jangan dipakai utk VM rentan** ⚠️ | Bridged / External | ✅ (bocor) | ✅ |

> [!danger] Aturan emas
> Mesin rentan **tidak boleh** kena Bridged/External. Pakai **Host-Only** (atau Internal). Detail risikonya di [[Setup Lab (Virtualisasi)]].

**Pola yang direkomendasikan untuk semua hypervisor:**
- **Kali** = 2 adapter → (1) NAT untuk internet, (2) Host-Only untuk menyerang.
- **Mesin rentan** = 1 adapter → Host-Only **yang sama** dengan Kali.

---

## 🟦 VirtualBox

### Subnet & interface default
- Jaringan Host-Only default: **`vboxnet0`**, subnet **`192.168.56.0/24`** (host = `192.168.56.1`).

### 1. (Sekali saja) buat/cek Host-Only Network
```text
File → Tools → Network Manager → tab "Host-only Networks"
  → bila kosong, klik "Create"
  → pastikan ada vboxnet0 dengan IPv4 192.168.56.1/24
  → DHCP Server: boleh ON (VM dapat IP otomatis) atau OFF (set manual)
```

### 2. Set adapter Kali (2 kartu)
```text
VM Kali → Settings → Network
  Adapter 1: Enable → Attached to: NAT            (internet)
  Adapter 2: Enable → Attached to: Host-only Adapter → Name: vboxnet0
```

### 3. Set adapter mesin rentan (1 kartu)
```text
VM target → Settings → Network → Adapter 1
  Attached to: Host-only Adapter → Name: vboxnet0
```

### 4. Verifikasi dari Kali
```bash
ip a                              # cari interface host-only (mis. eth1) → 192.168.56.x
sudo netdiscover -i eth1 -r 192.168.56.0/24
ping <ip-target>
```

> [!tip] Mau isolasi total (tanpa host)?
> Ganti Host-Only → **Internal Network**, beri nama sama (mis. `labnet`) di Kali & target. Bedanya: mesin host (laptopmu) tidak ikut di jaringan ini — paling aman, tapi tak bisa akses VM dari browser host.

---

## 🟩 VMware (Workstation / Player / Fusion)

### Subnet & interface default
- **VMnet1** = Host-Only, **VMnet8** = NAT. Subnet di-generate otomatis (mis. `192.168.x.0/24`) — **catat angkanya** dari Virtual Network Editor.

### 1. (Workstation Pro) atur via Virtual Network Editor
```text
Edit → Virtual Network Editor  (perlu admin)
  → pilih VMnet1 → tipe "Host-only"
  → catat "Subnet IP" (mis. 192.168.149.0)  ← ini subnet lab-mu
  → "Use local DHCP" boleh dicentang agar VM dapat IP otomatis
```
> Player/Fusion tak punya editor lengkap; cukup pilih mode di settings VM (langkah 2). Subnet host-only tetap bisa dilihat di Workstation atau dari `ip a` Kali.

### 2. Set adapter Kali (2 kartu)
```text
VM Kali → Settings → Network Adapter
  Adapter 1: NAT
  Add… → Network Adapter 2: Host-only
```

### 3. Set adapter mesin rentan (1 kartu)
```text
VM target → Settings → Network Adapter → Host-only
```

### 4. Verifikasi dari Kali (subnet sesuai catatanmu)
```bash
ip a
sudo netdiscover -i eth1 -r 192.168.149.0/24   # ganti dgn subnet VMnet1-mu
nmap -sn 192.168.149.0/24
```

> [!tip] Isolasi total di VMware
> Gunakan **"LAN Segment"** (Workstation): buat segment bernama `lab`, set Kali & target ke segment yang sama. Setara Internal Network di VirtualBox.

---

## 🟪 Hyper-V (Windows Pro/Enterprise)

> Hyper-V tak punya "host-only" persis. Padanannya: **Internal switch** (host + VM, tanpa internet — paling mirip host-only) atau **Private switch** (VM-only, isolasi total — setara Internal Network VirtualBox). Untuk internet Kali, tersedia switch **External** (≈ Bridged ⚠️) atau **NAT** Hyper-V.

### Subnet & interface default
- Hyper-V **tidak punya DHCP bawaan** untuk Internal/Private switch → kamu **set IP statis sendiri**. Subnet bebas, mis. **`10.10.10.0/24`** (host = `10.10.10.1`). Di host muncul adapter `vEthernet (LabSwitch)`.

### 1. (Sekali saja) buat virtual switch
```text
Hyper-V Manager → Virtual Switch Manager → New virtual network switch
  → "Internal"  (host bisa lihat VM)  atau  "Private" (VM-only)
  → beri nama: LabSwitch → Apply
```

### 2. Set adapter Kali (2 kartu)
```text
VM Kali → Settings → Network Adapter (atau "Add Hardware → Network Adapter")
  Adapter 1: Virtual switch → "Default Switch" (NAT bawaan Hyper-V → internet)
  Adapter 2: Virtual switch → "LabSwitch"      (Internal → menyerang)
```

### 3. Set adapter mesin rentan (1 kartu)
```text
VM target → Settings → Network Adapter → Virtual switch: LabSwitch
```

### 4. Atur IP statis & verifikasi (karena tanpa DHCP)
```text
Host  : Control Panel → adapter "vEthernet (LabSwitch)" → IPv4 statis 10.10.10.1/24
```
```bash
# Di Kali (interface host-only-nya, mis. eth1)
sudo ip addr add 10.10.10.10/24 dev eth1
sudo ip link set eth1 up
ping 10.10.10.1                     # host hidup?
sudo nmap -sn 10.10.10.0/24         # siapa lagi di subnet?
```
> Di VM target tetapkan IP statis di subnet yang sama (mis. `10.10.10.20/24`).

> [!tip] Mau isolasi total (tanpa host)?
> Pakai **Private switch** (bukan Internal). Host tidak ikut di subnet ini — setara Internal Network VirtualBox / LAN Segment VMware. Internet Kali tetap lewat adapter ke Default Switch.

---

## 🟧 QEMU/KVM (Linux host, mis. via virt-manager)

### Subnet & interface default
- Jaringan NAT default: **`virbr0`**, subnet **`192.168.122.0/24`** (host = `192.168.122.1`). Untuk lab terisolasi kita buat jaringan baru sendiri, mis. **`192.168.100.0/24`**.

### 1. (Sekali saja) buat jaringan terisolasi
```text
virt-manager → Edit → Connection Details → tab "Virtual Networks" → tombol +
  Name: labnet
  Mode: "Isolated" (tanpa internet — setara host-only/internal)
  Subnet: 192.168.100.0/24, DHCP: on → Finish
```

### 2. Set NIC Kali (2 kartu)
```text
VM Kali → Add Hardware → Network
  NIC 1: Network source → "default" (NAT virbr0 → internet)
  NIC 2: Network source → "labnet"  (Isolated → menyerang)
```

### 3. Set NIC mesin rentan (1 kartu)
```text
VM target → Add Hardware / NIC → Network source: "labnet"
```

### 4. Verifikasi dari Kali
```bash
ip a                                          # cari interface labnet (mis. eth1) → 192.168.100.x
sudo arp-scan --interface=eth1 --localnet
nmap -sn 192.168.100.0/24
ping <ip-target>
```

> [!tip] Isolasi vs internet di KVM
> Mode **"Isolated"** = VM-only, tak ada internet (paling aman). Bila mau host ikut bisa akses VM, pakai mode **"NAT"** untuk jaringan lab — tapi untuk VM rentan tetap utamakan Isolated + NIC NAT terpisah hanya di Kali.

---

## 🧯 Troubleshooting umum (semua hypervisor)

> [!warning] Gejala → Penyebab → Solusi
> - **Target tak muncul di `netdiscover`** → mungkin VM korban tak dapat IP. Cek di console VM target (`ip a`). Bila kosong → masalah MAC/DHCP (lihat di bawah).
> - **VM lama (VulnHub/Vulnyx) jaringan mati** → interface terkunci ke **MAC asli**. **VirtualBox:** Settings → Network → Advanced → klik regenerate MAC. **VMware:** edit `.vmx`, hapus baris `ethernet0.address*`. Lihat [[Lab — VulnHub]].
> - **Kali & target beda subnet** → keduanya tidak di adapter host-only yang **sama**. Samakan nama adapter/switch.
> - **Kali tak bisa internet** → pastikan adapter NAT-nya aktif & urutannya benar; `sudo dhclient eth0`.
> - **Interface di Kali bukan eth1** → cek nama asli dgn `ip a` (bisa `eth1`, `enp0s8`, dll.) dan pakai nama itu di `netdiscover -i`.

```bash
# Diagnostik cepat dari Kali
ip a                      # interface & IP apa saja yang kupunya?
ip route                  # gateway & subnet
ping 192.168.56.1         # host-only gateway hidup?
sudo netdiscover -i eth1 -r 192.168.56.0/24   # siapa lagi di subnet ini?
```

## 🧰 Tools

- **Host-Only/NAT Manager** (VirtualBox), **Virtual Network Editor** (VMware), **Virtual Switch Manager** (Hyper-V), **virt-manager** (KVM).
- **netdiscover / arp-scan / nmap -sn** — temukan IP target ([[Scanning & Enumeration]]).

## 🔗 Kaitan

- ⚡ Cara cepat & scriptable lewat terminal: [[Lab — Setup Jaringan via CLI]].
- Konsep mode jaringan & aturan keamanan: [[Setup Lab (Virtualisasi)]].
- Dipakai oleh tiap note platform: [[Lab — Metasploitable]], [[Lab — VulnHub]], [[Lab — Vulnyx]], [[Lab — Platform Lab Lainnya]].
- Dasar IP/subnet: [[Jaringan Komputer]] · [[Model OSI & TCP-IP]].

## 🎯 Latihan

- Buat jaringan host-only, set Kali (NAT + host-only) & satu target (host-only), lalu buktikan `ping` dua arah berhasil **tanpa** target bisa akses internet (uji: dari target, `ping 8.8.8.8` harus **gagal**).

## 📖 Sumber

- **VirtualBox Manual — Virtual Networking**: https://www.virtualbox.org/manual/ch06.html
- **VMware — Network connection types** (dokumentasi Workstation/Fusion).
- **Microsoft — Hyper-V virtual switch types**.
