# ⚡ Lab — Setup Jaringan via CLI

> [!summary] Ringkasan
> Versi **terminal** dari [[Lab — Setup Jaringan Lab]]. Semua yang tadi kamu klik di menu hypervisor (bikin host-only network, pasang adapter ke VM) **bisa dilakukan lewat satu-dua baris perintah**. Ini **opsional**: pemula boleh tetap pakai GUI. CLI berguna saat kamu mau **cepat, bisa diulang persis (reproducible), dan bisa di-script**. Catatan ini menjelaskan *apa itu* CLI, *kenapa* dipakai, lalu memberi perintah padanan untuk tiap hypervisor.

**Bagian dari:** [[Setup Lab (Virtualisasi)]]
**Prasyarat:** [[Lab — Setup Jaringan Lab]] (paham dulu langkah GUI-nya), [[Linux Dasar untuk Security]] (nyaman dengan terminal)

---

## 🧠 Konsep Inti

### Apa itu CLI?
**CLI** = *Command-Line Interface*, yaitu cara mengontrol program dengan **mengetik perintah** di terminal, bukan mengklik tombol. Lawannya adalah **GUI** (*Graphical User Interface*) — menu, jendela, tombol.

Tiap hypervisor punya **alat CLI resminya sendiri** untuk mengelola VM & jaringan:

| Hypervisor | Alat CLI | Berjalan di |
|---|---|---|
| VirtualBox | **`VBoxManage`** | Windows/Linux/macOS (shell biasa) |
| VMware | **`vmrun`** + edit file `.vmx` | Windows/Linux/macOS |
| Hyper-V | **PowerShell** (modul `Hyper-V`) | Windows |
| QEMU/KVM | **`virsh`** (libvirt) | Linux |

> [!info] CLI bukan pengganti, tapi pelengkap
> GUI dan CLI **mengatur hal yang sama** — keduanya hanya antarmuka berbeda ke mesin yang sama. Hasil `VBoxManage hostonlyif create` identik dengan klik "Create" di Network Manager. Pilih mana saja yang nyaman; banyak praktisi pakai GUI untuk eksplorasi awal lalu CLI untuk mengulang.

### Kenapa belajar CLI untuk jaringan lab?

1. **Cepat & tanpa pindah jendela** — satu baris langsung jadi, tak perlu menyusuri 4 menu.
2. **Reproducible (bisa diulang persis)** — perintah yang sama selalu menghasilkan konfigurasi yang sama. Tidak ada "tadi aku centang yang mana ya?".
3. **Bisa di-script & otomatis** — kumpulkan beberapa perintah dalam satu file `.sh`/`.ps1` → bangun ulang seluruh lab dengan **satu klik**. Berguna saat lab-mu rusak dan ingin reset cepat.
4. **Bisa dipakai dari jarak jauh / tanpa layar** — server headless (tanpa desktop) sering hanya punya terminal.
5. **Dokumentasi yang jujur** — perintah di catatanmu = persis apa yang kamu jalankan. Skill yang sama dipakai di otomasi nyata (Ansible, Terraform, Vagrant).

> [!tip] Kapan tetap pakai GUI saja?
> Kalau kamu **baru pertama kali** bikin lab, atau hanya butuh 1 lab yang jarang berubah — GUI lebih ramah. Beralih ke CLI saat kamu sudah paham *konsep* mode jaringannya (dari [[Lab — Setup Jaringan Lab]]) dan mulai merasa klik-klik itu lambat/berulang.

> [!warning] Hal yang perlu diketahui sebelum mengetik
> - **Perlu hak admin/root.** Mengubah jaringan = operasi sistem. Windows: jalankan terminal **"As Administrator"**. Linux: pakai `sudo`.
> - **Nama harus konsisten.** Kali & target harus menempel ke **nama jaringan/switch yang sama** (mis. `vboxnet0`, `LabSwitch`, `labnet`) — sama persis seperti aturan di GUI.
> - **VM harus mati saat mengubah adapter** (untuk sebagian perintah). Matikan dulu bila perintah ditolak.
> - **`<nama-vm>`** di contoh = ganti dengan nama VM-mu sendiri (cek dengan perintah "list" di tiap bagian).

---

## 🛠️ Cara Kerja / Praktik (per hypervisor)

Pola tujuannya sama di semua: **buat 1 jaringan terisolasi → Kali dapat NAT + jaringan itu → target dapat jaringan itu saja**.

### 🟦 VirtualBox — `VBoxManage`

```bash
# Lihat daftar VM (untuk tahu nama persisnya)
VBoxManage list vms

# 1. (Sekali saja) buat host-only network + nyalakan DHCP-nya
VBoxManage hostonlyif create                       # biasanya jadi "vboxnet0"
VBoxManage hostonlyif ipconfig vboxnet0 --ip 192.168.56.1 --netmask 255.255.255.0
VBoxManage dhcpserver add --ifname vboxnet0 \
  --ip 192.168.56.1 --netmask 255.255.255.0 \
  --lowerip 192.168.56.100 --upperip 192.168.56.200 --enable

# 2. Kali: adapter 1 = NAT (internet), adapter 2 = host-only (menyerang)
VBoxManage modifyvm "Kali" --nic1 nat
VBoxManage modifyvm "Kali" --nic2 hostonly --hostonlyadapter2 vboxnet0

# 3. Target: hanya host-only yang sama
VBoxManage modifyvm "Metasploitable" --nic1 hostonly --hostonlyadapter1 vboxnet0
```
> Isolasi total (tanpa host): ganti `hostonly` → `intnet` dan beri nama, mis. `--intnet "labnet"`.

### 🟩 VMware — `vmrun` + edit `.vmx`

VMware mengatur **mode jaringan** lewat baris di file konfigurasi VM (`.vmx`), bukan satu perintah tunggal. `vmrun` dipakai untuk start/stop/snapshot.

```bash
# Di file .vmx VM (mis. Kali.vmx), pastikan baris adapter seperti ini:
#   ethernet0.connectionType = "nat"        ← adapter 1: internet
#   ethernet1.present        = "TRUE"
#   ethernet1.connectionType = "hostonly"   ← adapter 2: menyerang
# Untuk target (mis. Meta.vmx): satu adapter saja →
#   ethernet0.connectionType = "hostonly"

# Lalu kontrol VM via vmrun:
vmrun list                                  # VM yang sedang berjalan
vmrun start "/path/Kali.vmx" nogui
vmrun snapshot "/path/Kali.vmx" "fresh"     # ambil snapshot dari CLI
vmrun stop "/path/Kali.vmx"
```
> Subnet host-only (VMnet1) diatur di Virtual Network Editor; via CLI Linux bisa diintip di `/etc/vmware/networking`. "LAN Segment" (isolasi total) tetap lebih mudah lewat GUI.

### 🟪 Hyper-V — PowerShell (jalankan **as Administrator**)

```powershell
# Lihat VM & switch yang ada
Get-VM
Get-VMSwitch

# 1. (Sekali saja) buat switch internal (host+VM) — atau "Private" utk isolasi total
New-VMSwitch -Name "LabSwitch" -SwitchType Internal

# 2. Beri IP host di switch itu (Hyper-V tanpa DHCP → IP statis)
New-NetIPAddress -IPAddress 10.10.10.1 -PrefixLength 24 `
  -InterfaceAlias "vEthernet (LabSwitch)"

# 3. Kali: adapter 1 = Default Switch (NAT/internet), adapter 2 = LabSwitch
Connect-VMNetworkAdapter -VMName "Kali" -SwitchName "Default Switch"
Add-VMNetworkAdapter   -VMName "Kali" -SwitchName "LabSwitch"

# 4. Target: hanya LabSwitch
Connect-VMNetworkAdapter -VMName "Metasploitable" -SwitchName "LabSwitch"
```
> Isolasi total: ganti `-SwitchType Internal` → `-SwitchType Private` (host tidak ikut). IP di Kali & target tetap di-set statis di subnet `10.10.10.0/24`.

### 🟧 QEMU/KVM — `virsh`

```bash
# Lihat VM & jaringan
virsh list --all
virsh net-list --all

# 1. (Sekali saja) buat jaringan terisolasi dari file XML
cat > labnet.xml <<'EOF'
<network>
  <name>labnet</name>
  <ip address="192.168.100.1" netmask="255.255.255.0">
    <dhcp><range start="192.168.100.100" end="192.168.100.200"/></dhcp>
  </ip>
</network>
EOF
virsh net-define labnet.xml          # tanpa <forward> = Isolated (tanpa internet)
virsh net-start labnet
virsh net-autostart labnet

# 2. Pasang NIC ke VM (default = NAT untuk internet, labnet = menyerang)
virsh attach-interface Kali           network default --model virtio --persistent
virsh attach-interface Kali           network labnet  --model virtio --persistent
virsh attach-interface Metasploitable network labnet  --model virtio --persistent
```
> `default` (virbr0) menyediakan internet via NAT; `labnet` tanpa blok `<forward>` = terisolasi.

---

## ✅ Verifikasi (sama untuk semua hypervisor)

Apa pun cara setup-nya, buktikan dari **Kali** (ganti subnet & interface sesuai labmu):

```bash
ip a                                   # interface & IP host-only mana yang kupunya?
ip route                               # gateway/subnet
ping 192.168.56.1                      # gateway host-only hidup?
sudo nmap -sn 192.168.56.0/24          # siapa lagi di subnet ini? (cari IP target)
ping <ip-target>                       # target merespons?
# Uji isolasi: dari TARGET, `ping 8.8.8.8` HARUS gagal.
```

## 🧰 Tools

- **`VBoxManage`** (VirtualBox), **`vmrun`** (VMware), **modul PowerShell `Hyper-V`**, **`virsh`/libvirt** (KVM) — CLI resmi tiap hypervisor.
- **`ip` / `nmap -sn` / `netdiscover` / `arp-scan`** — verifikasi & temukan IP target ([[Scanning & Enumeration]]).
- Lanjutan otomasi penuh: **Vagrant**, **Ansible** (bangun lab dari satu file konfigurasi).

## 🔗 Kaitan

- Versi GUI langkah-demi-langkah: [[Lab — Setup Jaringan Lab]].
- Konsep mode jaringan & aturan keamanan (host-only vs bridged): [[Setup Lab (Virtualisasi)]].
- Dasar terminal yang dipakai di sini: [[Linux Dasar untuk Security]].
- Dasar IP/subnet: [[Jaringan Komputer]] · [[Model OSI & TCP-IP]].
- Dipakai sebelum: [[Lab — Metasploitable]], [[Lab — VulnHub]], [[Lab — Vulnyx]].

## 🎯 Latihan

1. Bangun lab host-only **lewat CLI saja** (tanpa menyentuh GUI): buat jaringan, set Kali (NAT + host-only) & 1 target, lalu buktikan `ping` dua arah sukses dan target **tidak** bisa `ping 8.8.8.8`.
2. Kumpulkan perintah langkah 1 ke dalam satu file script (`.sh` di Linux / `.ps1` di Hyper-V). Hapus jaringannya, lalu jalankan script untuk **membangun ulang lab dengan satu perintah** — rasakan bedanya dengan klik manual.

## 📖 Sumber

- **VirtualBox Manual — `VBoxManage`**: https://www.virtualbox.org/manual/ch08.html
- **VMware — `vmrun` user guide** (dokumentasi Workstation/Fusion).
- **Microsoft — Hyper-V PowerShell module**: https://learn.microsoft.com/powershell/module/hyper-v/
- **libvirt — `virsh` networking** (`net-define`, `net-start`): https://libvirt.org/
