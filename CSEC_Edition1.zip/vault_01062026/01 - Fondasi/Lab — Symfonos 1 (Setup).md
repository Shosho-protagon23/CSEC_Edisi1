# 🎯 Lab — Symfonos 1 (Setup)

> [!summary] Ringkasan
> **Symfonos: 1** (author *Zayotic*, rilis 29 Jun 2019) adalah mesin **boot-to-root Linux** pemula dari seri **symfonos**, dirancang khusus untuk mengajarkan **cara menarik mendapat low-priv shell**: enum **SMB** → temukan kredensial → **LFI + log poisoning** (SMTP) untuk RCE. Formatnya **VirtualBox OVA** di dalam arsip **`.7z`** (beda dari DC/Mr-Robot yang `.zip`!). Catatan ini = panduan setup untuk **VirtualBox** dan **VMware** + dua peringatan penting (jaringan & hosts).

**Bagian dari:** [[Lab — VulnHub]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]], [[Lab — Setup Jaringan Lab]], [[Scanning & Enumeration]]

> [!info] Halaman resmi
> https://www.vulnhub.com/entry/symfonos-1,322/

---

## 🧠 Info Mesin

| Atribut | Nilai |
|---|---|
| Nama | symfonos: 1 |
| File | `symfonos1.7z` (~739 MB) berisi **OVA** |
| Format asli | VirtualBox OVA, dikompres **`.7z`** ⚠️ |
| OS | Linux |
| Jaringan | **DHCP enabled**; IP otomatis |
| Login awal | ❌ tidak ada (cari IP sendiri) |
| Tujuan | boot-to-root (user → root) |
| Kesulitan | beginner |
| Pintu masuk | **SMB** enum → kredensial → **LFI / log poisoning** (RCE) |

> [!danger] Pakai Host-Only
> Seperti semua mesin lab sengaja-rentan, jalankan symfonos di **Host-Only** — jangan Bridged. Lihat aturan emas di [[Setup Lab (Virtualisasi)]].

> [!warning] Mungkin perlu entri hosts `symfonos.local`
> Author memberi petunjuk kamu mungkin perlu menambah `symfonos.local` ke file hosts agar web jalan penuh:
> ```bash
> echo "192.168.56.x   symfonos.local" | sudo tee -a /etc/hosts
> ```

---

## 1️⃣ Unduh & ekstrak (arsip `.7z`)

Beda dari mesin `.zip`, file ini butuh **7-Zip** untuk ekstrak:
```bash
wget https://download.vulnhub.com/symfonos/symfonos1.7z
# Linux: pasang p7zip lalu ekstrak
sudo apt install p7zip-full
7z x symfonos1.7z         # menghasilkan file .ova
```
```powershell
# Windows: pakai 7-Zip (atau)
& "C:\Program Files\7-Zip\7z.exe" x symfonos1.7z
```

## 2️⃣ Verifikasi integritas file (WAJIB)

```text
MD5  : A26759752F413FCD6BA7BE31B0D7862D
SHA1 : 126D57358E7B9AD713CF269A7F38E66B5D798744
```
Cek hash **arsip `.7z`** sebelum diekstrak:
```bash
md5sum symfonos1.7z        # Linux
sha1sum symfonos1.7z
```
```powershell
Get-FileHash symfonos1.7z -Algorithm MD5     # Windows
Get-FileHash symfonos1.7z -Algorithm SHA1
```
Harus **sama persis**. Kalau beda → unduh ulang.

---

## 🟦 Setup A — VirtualBox

### A.1 Import appliance
```text
VirtualBox → File → Import Appliance…
  → pilih symfonos1.ova → Next
  → centang "Reinitialize the MAC address of all network cards"
  → Import
```

### A.2 Jaringan Host-Only
```text
VM symfonos1 → Settings → Network → Adapter 1
  Attached to: Host-only Adapter   (host-only yang SAMA dengan Kali)
```
DHCP-enabled → dapat IP otomatis di subnet host-only (mis. `192.168.56.0/24`).

### A.3 Snapshot bersih
```text
VirtualBox → symfonos1 → tab Snapshots → Take → nama: "fresh"
```

---

## 🟩 Setup B — VMware (Workstation / Player / Fusion)

### B.1 Import OVA
```text
VMware → File → Open… → pilih symfonos1.ova → beri nama → Import
```
Jika import ditolak karena pemeriksaan OVF ketat, paksa via **ovftool**:
```bash
ovftool --lax --allowExtraConfig symfonos1.ova symfonos1.vmx
```

### B.2 Set jaringan Host-Only (VMnet1)
```text
VM Settings → Network Adapter → Host-only (VMnet1)   — sama dgn Kali
```
Catat subnet VMnet1 dari **Virtual Network Editor**. Lihat [[Lab — Setup Jaringan Lab]].

### B.3 Jika jaringan mati (fix MAC)
Tutup VM, edit `symfonos1.vmx`, hapus baris pengunci MAC lalu set generated:
```text
ethernet0.addressType = "generated"
# hapus: ethernet0.address / ethernet0.generatedAddress / ethernet0.checkMACAddress
```

### B.4 Snapshot bersih
```text
VM → Snapshot → Take Snapshot → nama: "fresh"
```

---

## 🎯 Setelah mesin hidup — boot-to-root

Sama untuk kedua hypervisor.

### 1. Temukan IP target (tak ada login!)
```bash
ip a
sudo netdiscover -i eth1 -r 192.168.56.0/24
# atau:
sudo arp-scan --interface=eth1 --localnet
nmap -sn 192.168.56.0/24
```

### 2. Enum & serang
```bash
nmap -sC -sV -p- <ip-symfonos>     # cek SMB(139/445), SMTP(25), HTTP(80)
```
Alur khas symfonos 1:
1. **Enum SMB** → `enum4linux -a <ip>` / `smbclient -L //<ip>/` → temukan share & **kredensial** di file.
2. Pakai kredensial untuk login layanan (mis. web/WordPress) → enum lanjutan ([[Web Application Hacking (OWASP Top 10)]]).
3. **LFI** ditemukan → **log poisoning** (suntik PHP via header/SMTP log) untuk dapat **RCE** & low-priv shell.
4. **Privesc** → cari binari **SUID** / path hijack → root. Lihat [[Privilege Escalation]].

Ambil **snapshot bersih** sebelum menyerang.

---

## 🧰 Tools

- **VirtualBox / VMware** — jalankan OVA.
- **7-Zip / p7zip** — ekstrak `symfonos1.7z`. **ovftool** — import paksa ke VMware.
- **netdiscover / arp-scan / nmap -sn** — temukan IP target.
- **enum4linux, smbclient, nmap, gobuster, curl** — enum SMB & web, eksploitasi LFI.

## 🔗 Kaitan

- Hub VulnHub & langkah generik: [[Lab — VulnHub]].
- Setup OVA `.zip` serupa: [[Lab — DC-1 (Setup)]], [[Lab — Mr-Robot (Setup)]]. Setup arsip VMware: [[Lab — Kioptrix (Setup)]].
- Enum SMB & layanan jaringan: [[Scanning & Enumeration]]. Kerentanan web (LFI): [[Web Application Hacking (OWASP Top 10)]].
- Setup jaringan & troubleshooting MAC: [[Lab — Setup Jaringan Lab]].
- Hub lab: [[Setup Lab (Virtualisasi)]].
- Alur serang: [[Reconnaissance (Information Gathering)]] → [[Scanning & Enumeration]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]].

## 🎯 Latihan

- Ekstrak `symfonos1.7z` (latih ekstrak **`.7z`**, beda dari `.zip`) & setup **Host-Only** sampai bisa `ping` target.
- Selesaikan **boot-to-root**: enum SMB → kredensial → **LFI + log poisoning** → SUID privesc. Tulis write-up di vault.

## 📖 Sumber

- **VulnHub — symfonos: 1** — https://www.vulnhub.com/entry/symfonos-1,322/
- **Mirror download** — https://download.vulnhub.com/symfonos/symfonos1.7z
- **GTFOBins** (SUID privesc) — https://gtfobins.github.io
- Seri **symfonos 1–5** sering masuk daftar latihan pemula NetSecFocus/TJnull.
