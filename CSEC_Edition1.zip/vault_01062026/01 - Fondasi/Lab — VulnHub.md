# 🟢 Lab — VulnHub

> [!summary] Ringkasan
> **VulnHub** (https://www.vulnhub.com) adalah gudang **ratusan VM rentan gratis** buatan komunitas, banyak bergaya **OSCP** (boot-to-root: dari nol sampai jadi root). Kamu unduh paket VM, import ke hypervisor, lalu serang. Ini latihan boot-to-root paling murah dan tak terbatas.

**Bagian dari:** [[Setup Lab (Virtualisasi)]]
**Prasyarat:** [[Setup Lab (Virtualisasi)]], [[Scanning & Enumeration]]

---

## 🧠 Konsep Inti

- Mayoritas mesin VulnHub didistribusikan sebagai **.ova / .ovf** (paket siap import) — kadang **.vmdk**.
- Tiap mesin punya **halaman deskripsi**: tingkat kesulitan, hypervisor yang disarankan (VirtualBox **atau** VMware — kadang penting!), dan apakah ada *walkthrough*.
- Tujuannya **boot-to-root**: temukan IP → enum → exploit → user shell → [[Privilege Escalation|privesc]] → baca `root.txt`.

> [!tip] Pilih mesin pemula
> Cari yang berlabel **"beginner" / "easy"** di deskripsi. Seri klasik untuk pemula: **Basic Pentesting**, **Mr-Robot**, **Kioptrix**, **DC-1 … DC-9**. Mulai dari salah satu ini.

## ⚙️ Cara Kerja / Praktik

### 1. Unduh mesin
Di halaman mesin VulnHub → bagian **Download** → ambil file `.ova` (atau `.zip` berisi `.ova/.vmdk`). **Cek hash** (MD5/SHA) yang tertera bila ada, agar file tidak korup.

### 2. Import ke VirtualBox
```text
VirtualBox → File → Import Appliance…
  → pilih file .ova → Next → Import
```
Jika hanya dapat **.vmdk**: buat VM baru (Type: Linux) dan "Use an existing virtual hard disk file" → tunjuk ke .vmdk (sama seperti [[Lab — Metasploitable]] langkah 2).

### 3. Set jaringan Host-Only (WAJIB)
```text
VM → Settings → Network → Adapter 1
  Attached to: Host-only Adapter  (adapter yang sama dgn Kali)
```

> [!warning] Masalah jaringan paling umum di VulnHub
> Banyak VM lama "mengunci" nama interface ke **MAC address** asli pembuatnya, sehingga setelah import jaringan **mati / tak dapat IP**.
> **Perbaikan:** di `Settings → Network → Advanced` → klik tombol refresh ikon untuk **regenerate MAC address**. Jika masih mati, masuk recovery/boot mode VM dan edit aturan udev/netplan — atau cari catatan ini di walkthrough mesin tersebut.

### 4. Nyalakan & cari IP (kamu tak punya login!)
VulnHub *intinya* kamu harus menemukan IP sendiri dari Kali:
```bash
# Subnet host-only Kali (mis. 192.168.56.0/24)
ip a
sudo netdiscover -i eth1 -r 192.168.56.0/24
# atau
sudo arp-scan --interface=eth1 --localnet
nmap -sn 192.168.56.0/24
```
IP baru yang muncul (bukan Kali, bukan gateway) = target-mu.

### 5. Mulai serang
```bash
nmap -sC -sV -p- <ip-target>     # enum port & service
# lanjut sesuai temuan → [[Web Application Hacking (OWASP Top 10)]] / [[Exploitation & Metasploit]]
```

### 6. Snapshot di awal
Snapshot kondisi bersih agar bisa ulang dari nol kapan saja.

---

## 🤖 Contoh Lengkap: Mr-Robot

Mesin **Mr-Robot: 1** adalah klasik pemula yang ideal untuk latihan pertama. Panduan setup `mrRobot.ova` step-by-step — **untuk VirtualBox maupun VMware**, lengkap dengan link unduh resmi, hash verifikasi, dan fix jaringan — ada di note khusus:

> [!example] Lihat note terpisah
> 👉 [[Lab — Mr-Robot (Setup)]] — setup penuh dua hypervisor (VirtualBox + VMware) + boot-to-root, dari file **OVA**.
> 👉 [[Lab — Kioptrix (Setup)]] — seri klasik OSCP (5 level), dari arsip **`.rar`/VMware native**; VMware = mulus, VirtualBox = import `.vmdk`.
> 👉 [[Lab — DC-1 (Setup)]] — seri **DC**, OVA dalam `.zip`, pintu masuk **Drupal**; default Bridged → **wajib ubah ke Host-Only**.
> 👉 [[Lab — DC-2 (Setup)]] — lanjutan DC-1: **WordPress** → escape **`rbash`** → privesc **`git`**; butuh entri hosts `dc-2`.
> 👉 [[Lab — Symfonos 1 (Setup)]] — enum **SMB** → **LFI/log poisoning**; arsip **`.7z`** (bukan `.zip`).
> 👉 [[Lab — Brainpan (Setup)]] — satu-satunya jalur **buffer overflow / exploit development** (port 9999).

## 🧰 Tools

- **VirtualBox/VMware** — import & jalankan .ova.
- **netdiscover / arp-scan / nmap -sn** — temukan IP target.
- **nmap, gobuster, Burp, Metasploit** — sesuai fase ([[Scanning & Enumeration]], dst).

## 🔗 Kaitan

- Alur serangan lengkap: [[Reconnaissance (Information Gathering)]] → [[Scanning & Enumeration]] → [[Exploitation & Metasploit]] → [[Privilege Escalation]] → [[Reporting & Sertifikasi (OSCP-dll)]].
- Daftar mesin terkurasi & komunitas: [[Sumber Belajar & Platform Latihan]].
- Hub lab: [[Setup Lab (Virtualisasi)]].

## 🎯 Latihan

- Selesaikan **boot-to-root** satu mesin pemula (mis. **Basic Pentesting 1** atau **DC-1**) sampai baca `root.txt`. Tulis langkahnya sebagai write-up di vault ini.

## 📖 Sumber

- **VulnHub** — https://www.vulnhub.com
- **Daftar mesin "mirip OSCP"** (TJnull/NetSecFocus OSCP-like list) — cari di Google untuk urutan latihan terbaik.
- **Walkthrough**: setiap mesin VulnHub umumnya punya write-up komunitas — baca **setelah** mencoba sendiri.
