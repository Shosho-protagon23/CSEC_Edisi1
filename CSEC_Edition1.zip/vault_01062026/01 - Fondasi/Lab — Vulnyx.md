# 🟡 Lab — Vulnyx

> [!summary] Ringkasan
> **Vulnyx** (https://vulnyx.com) adalah koleksi VM rentan gaya **OSCP / boot-to-root** dari komunitas (banyak dibuat oleh **d4t4s3c** dkk., berbahasa Spanyol & Inggris). Mirip [[Lab — VulnHub]]: unduh paket VM, import, serang. Banyak mesinnya rapi dan jadi favorit untuk latihan privesc Linux.

**Bagian dari:** [[Setup Lab (Virtualisasi)]]
**Prasyarat:** [[Lab — VulnHub]] (alur import & cari-IP-nya identik), [[Scanning & Enumeration]]

---

## 🧠 Konsep Inti

- Format & alurnya **sama persis** dengan VulnHub: VM **.ova** (kadang .7z/.zip) → import → host-only → cari IP → boot-to-root.
- Tiap mesin diberi **rating kesulitan** (Easy → Hard) dan sering ada **hash verifikasi**.
- Banyak mesin Vulnyx menonjolkan latihan **Linux privilege escalation** yang bersih dan logis — bagus untuk mengasah [[Privilege Escalation]].

> [!tip] Pilih mesin pemula
> Filter berdasarkan difficulty **Easy** di situsnya. Karena alurnya identik VulnHub, kalau sudah pernah menyelesaikan satu mesin VulnHub, Vulnyx akan terasa familiar.

## ⚙️ Cara Kerja / Praktik

### 1. Unduh
Di https://vulnyx.com → pilih mesin → **Download** file `.ova` (atau arsip `.7z`/`.zip` → ekstrak dulu). Verifikasi **hash** jika disediakan.

### 2. Import
```text
VirtualBox → File → Import Appliance… → pilih .ova → Import
```
(Jika dapat .vmdk: buat VM kosong & pasang disk, sama seperti [[Lab — Metasploitable]] langkah 2.)

### 3. Jaringan Host-Only
```text
VM → Settings → Network → Adapter 1 → Host-only Adapter
  (samakan dengan adapter host-only Kali)
```
Jika VM tak dapat IP setelah import → **regenerate MAC address** (`Settings → Network → Advanced`), persis seperti troubleshooting di [[Lab — VulnHub]].

### 4. Nyalakan & temukan IP
```bash
ip a
sudo netdiscover -i eth1 -r 192.168.56.0/24
nmap -sn 192.168.56.0/24
```

### 5. Boot-to-root
```bash
nmap -sC -sV -p- <ip-target>
# enum web/service → foothold → [[Privilege Escalation]] → root.txt
```

### 6. Snapshot bersih di awal.

## 🧰 Tools

- **VirtualBox/VMware** + **7-Zip** (untuk ekstrak arsip .7z).
- **netdiscover / nmap** — temukan & enum target.
- **linpeas / pspy** — bantu cari jalur privesc ([[Privilege Escalation]]).

## 🔗 Kaitan

- Latihan utamanya: [[Scanning & Enumeration]] → foothold → [[Privilege Escalation]].
- Setara & saudara: [[Lab — VulnHub]]; lihat juga **HackMyVM** di [[Lab — Platform Lab Lainnya]] (komunitas yang sangat berkaitan).
- Hub lab: [[Setup Lab (Virtualisasi)]].

## 🎯 Latihan

- Selesaikan satu mesin **Easy** Vulnyx hingga `root.txt`, fokuskan catatan pada **bagaimana kamu menemukan jalur privesc** — itu skill paling berharga.

## 📖 Sumber

- **Vulnyx** — https://vulnyx.com
- **Walkthrough komunitas** (YouTube/blog, byk berbahasa Spanyol) — baca setelah mencoba sendiri.
- Daftar mesin OSCP-like (TJnull) sering memasukkan mesin Vulnyx/HackMyVM.
