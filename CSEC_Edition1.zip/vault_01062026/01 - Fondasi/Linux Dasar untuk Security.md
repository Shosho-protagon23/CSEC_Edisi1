# 🐧 Linux Dasar untuk Security

> [!summary] Ringkasan
> Mayoritas server, tools hacking, dan distro security (Kali, Parrot) berbasis Linux. Nyaman di terminal Linux adalah skill non-negotiable, baik untuk red maupun blue team.

**Bagian dari:** [[Fondasi (MOC)]]

---

## 🧠 Konsep Inti

### Struktur Filesystem
Semua di Linux adalah "file" dan tersusun dari root `/`:
- `/etc` — konfigurasi sistem (mis. `/etc/passwd`, `/etc/shadow` berisi info user/password hash).
- `/home` — folder user.
- `/root` — home untuk superuser.
- `/var/log` — **log sistem** (penting untuk [[Log Analysis & Monitoring]]).
- `/tmp` — sementara, sering dipakai attacker untuk menaruh file.
- `/bin`, `/usr/bin` — program/command.

### User & Permission
- `root` = superuser (kuasa penuh). Setara "Administrator" di Windows.
- Permission file: `rwx` untuk **user / group / others**, contoh `-rwxr-xr--`.
- **SUID bit** — file yang berjalan sebagai pemiliknya; salah konfigurasi → jalan untuk [[Privilege Escalation]].

## ⚙️ Command Wajib Hafal

```bash
pwd                      # di mana saya sekarang?
ls -la                   # list file + hidden + permission
cd /etc                  # pindah folder
cat /etc/passwd          # baca isi file
grep "root" /etc/passwd  # cari teks di file
find / -perm -4000 2>/dev/null   # cari file SUID (berguna untuk privesc)
chmod +x script.sh       # beri izin eksekusi
sudo command             # jalankan sebagai root
ps aux                   # lihat proses berjalan
netstat -tulpn           # port terbuka
man nmap                 # baca manual sebuah command
```

### Pipe & redirect (sangat kuat)
```bash
cat access.log | grep "404" | wc -l    # hitung jumlah error 404
command > out.txt                       # simpan output ke file
command 2>/dev/null                     # buang pesan error
```

## 🧰 Tools / Lingkungan

- **Kali Linux** — distro berisi ratusan tool security siap pakai. Pasang di [[Setup Lab (Virtualisasi)]].
- **Bash scripting** — otomasi tugas berulang.
- **tmux** — kelola banyak terminal.

## 🔗 Kaitan

- Pasang Linux di lab: [[Setup Lab (Virtualisasi)]].
- Sisi Red: setelah dapat akses, eksplorasi & naikkan hak di [[Privilege Escalation]] & [[Post-Exploitation & Pivoting]].
- Sisi Blue: baca log Linux di [[Log Analysis & Monitoring]]; perketat konfigurasi di [[Hardening & Vulnerability Management]].

## 🎯 Latihan

- **TryHackMe — "Linux Fundamentals 1, 2, 3"** (seri terbaik untuk pemula total).
- **OverTheWire — "Bandit"** (https://overthewire.org/wargames/bandit/) — belajar terminal lewat game, gratis & legendaris.

## 📖 Sumber

- **Linux Journey** — https://linuxjourney.com (interaktif, dari nol).
- **The Linux Command Line** (buku gratis) — https://linuxcommand.org/tlcl.php
