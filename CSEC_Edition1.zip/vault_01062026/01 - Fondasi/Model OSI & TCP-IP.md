# 📶 Model OSI & TCP/IP

> [!summary] Ringkasan
> Model OSI membagi komunikasi jaringan jadi 7 lapisan. Ini "peta" yang dipakai profesional security untuk menjelaskan *di lapisan mana* sebuah serangan terjadi (mis. DDoS di Layer 7 vs Layer 3).

**Bagian dari:** [[Fondasi (MOC)]]
**Prasyarat:** [[Jaringan Komputer]]

---

## 🧠 Konsep Inti — 7 Lapisan OSI

Ingat dari bawah ke atas dengan jembatan keledai: **"Please Do Not Throw Sausage Pizza Away"**.

| # | Lapisan | Tugas | Contoh | Contoh serangan |
|---|---|---|---|---|
| 7 | **Application** | Antarmuka ke aplikasi | HTTP, DNS, FTP | SQL Injection, XSS ([[Web Application Hacking (OWASP Top 10)]]) |
| 6 | **Presentation** | Format & enkripsi data | TLS/SSL, JPEG | SSL stripping |
| 5 | **Session** | Mengelola sesi koneksi | NetBIOS | Session hijacking |
| 4 | **Transport** | Pengiriman andal/segmentasi | TCP, UDP | SYN flood |
| 3 | **Network** | Routing antar jaringan | IP, ICMP | IP spoofing, DDoS volumetrik |
| 2 | **Data Link** | Komunikasi antar perangkat lokal | MAC, switch | ARP spoofing, MAC flooding |
| 1 | **Physical** | Sinyal fisik | Kabel, WiFi | Wiretapping, jamming |

## ⚙️ TCP/IP Model (yang dipakai di dunia nyata)

OSI itu model teori. Yang benar-benar dipakai adalah model **TCP/IP** (4 lapisan), gabungan dari OSI:

| TCP/IP | ≈ OSI |
|---|---|
| Application | 7+6+5 |
| Transport | 4 |
| Internet | 3 |
| Network Access / Link | 2+1 |

### Encapsulation
Saat data turun dari Layer 7 ke 1, tiap lapisan menambah "amplop" (header). Data → Segment (L4) → Packet (L3) → Frame (L2) → Bits (L1). Saat diterima, dibuka terbalik (decapsulation). Memahami ini membantu membaca [[Jaringan Komputer|paket di Wireshark]].

## 🔗 Kaitan

- Tiap teknik serangan biasanya "milik" lapisan tertentu — gunakan tabel di atas sebagai peta saat belajar [[Red Team (MOC)]].
- Pertahanan berlapis mengikuti logika lapisan ini: [[Defense in Depth & Security Architecture]].

## 🎯 Latihan

- **TryHackMe — "OSI Model"** dan **"Packets & Frames"**.
- Buka **Wireshark**, tangkap trafik, lalu identifikasi lapisan tiap header (Ethernet → IP → TCP → HTTP).

## 📖 Sumber

- **Cloudflare — What is the OSI Model** — https://www.cloudflare.com/learning/ddos/glossary/open-systems-interconnection-model-osi/
- **Professor Messer — Network+**, bagian OSI Model.
