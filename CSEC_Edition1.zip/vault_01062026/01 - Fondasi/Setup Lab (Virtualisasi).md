# 🧪 Setup Lab (Virtualisasi)

> [!summary] Ringkasan
> Sebelum latihan apa pun, kamu butuh **lab terisolasi**: mesin virtual (VM) di komputermu sendiri tempat kamu boleh "merusak" tanpa risiko hukum atau merusak sistem nyata. Catatan ini adalah **hub setup lab** — mulai dari sini, lalu ikuti note step-by-step per platform (Metasploitable, VulnHub, Vulnyx, dll.).

**Bagian dari:** [[Fondasi (MOC)]]

---

> [!warning] Kenapa lab sendiri?
> Berlatih hacking di sistem milik orang lain tanpa izin = **ilegal**. Lab pribadi memberi kamu target legal sebanyak yang kamu mau. Lihat catatan etika di [[00 - START HERE]].

## 🧠 Konsep Inti

**Virtualisasi** = menjalankan "komputer di dalam komputer". Komponen lab minimal:

1. **Hypervisor** — software yang menjalankan VM (VirtualBox / VMware).
2. **VM penyerang** — biasanya **Kali** atau **Parrot** Linux (sudah berisi tools).
3. **VM korban (target)** — mesin sengaja-rentan untuk diserang.
4. **Jaringan terisolasi** — agar serangan tidak bocor ke jaringan rumah/internet.
5. **Snapshot** — tombol "undo" untuk mengembalikan VM ke kondisi bersih.

> [!tip] Format image VM (penting dipahami sejak awal)
> - **.ova / .ovf** — paket VM siap di-*import*. Paling umum di VulnHub/Vulnyx. (`File → Import Appliance` di VirtualBox).
> - **.vmdk / .vdi** — file *hard disk* virtual. Kamu buat VM kosong lalu pasang disk ini.
> - **.iso** — installer OS (mis. Kali). Kamu buat VM baru lalu boot dari ISO untuk instalasi.

## ⚙️ Langkah Setup (urutan global)

### 1. Pasang hypervisor
- **VirtualBox** (gratis, lintas-OS) — https://www.virtualbox.org → cocok untuk pemula & mayoritas VM VulnHub/Vulnyx (format OVA).
- **VMware Workstation Player** (gratis untuk personal) — performa sering lebih halus, beberapa VM lama lebih stabil di sini.
- Aktifkan **virtualisasi (VT-x/AMD-V)** di BIOS/UEFI jika VM gagal jalan 64-bit.

### 2. Buat VM penyerang (Kali)
Unduh image **Kali Linux** (https://www.kali.org/get-kali/). Pilihan termudah: **"Virtual Machines"** → unduh paket pre-built untuk VirtualBox/VMware, tinggal import. Pelajari dasar OS-nya di [[Linux Dasar untuk Security]].

### 3. Atur JARINGAN — langkah paling sering bikin pemula stuck
Tujuannya: VM penyerang & VM korban **saling lihat**, tapi **terisolasi dari internet/jaringan rumah**.

| Mode | Isolasi | VM saling lihat? | Akses internet | Kapan dipakai |
|---|---|---|---|---|
| **Host-Only** | tinggi | ✅ | ❌ | Default aman utk semua VM rentan |
| **Internal Network** | paling tinggi | ✅ | ❌ | Isolasi total (bahkan host tak ikut) |
| **NAT Network** | sedang | ✅ | ✅ | Bila perlu internet (mis. update Kali) |
| **Bridged** | rendah ⚠️ | ✅ | ✅ | **HINDARI** untuk VM rentan |

> [!danger] Aturan emas
> **JANGAN pernah pasang VM sengaja-rentan ke mode Bridged.** Bridged menaruhnya langsung di jaringan rumahmu — siapa pun di WiFi bisa menyerangnya, dan malware di dalamnya bisa keluar. Pakai **Host-Only** untuk Kali + target.

**Resep yang direkomendasikan:** set **Kali** punya 2 adapter → Adapter 1 = *NAT* (untuk update internet), Adapter 2 = *Host-Only*. Set **VM korban** hanya 1 adapter = *Host-Only* yang sama. Hasilnya Kali bisa internet **dan** menyerang target, target tetap terisolasi.

### 4. Cari IP target & uji konektivitas
VM rentan biasanya tak kasih tahu IP-nya (kamu sering tak punya login). Dari Kali:

```bash
# 1. Lihat IP & subnet Kali di adapter host-only (mis. 192.168.56.10/24)
ip a

# 2. Temukan semua host hidup di subnet itu
sudo netdiscover -i eth1 -r 192.168.56.0/24
# atau:
nmap -sn 192.168.56.0/24          # ping-sweep, daftar IP aktif

# 3. Pastikan target merespons
ping <ip-target>
```

### 5. Ambil SNAPSHOT
Sebelum mulai menyerang, ambil snapshot **VM korban** (kondisi bersih) **dan** Kali (instalasi bersih). Kalau VM rusak/kotor, restore satu klik.

```text
VirtualBox: pilih VM → tab "Snapshots" → "Take" (beri nama: "fresh-install")
```

## 📂 Note Setup Per-Platform (step-by-step)

Tiap platform punya kuirk sendiri. Ikuti note khusus ini:

- 🌐 [[Lab — Setup Jaringan Lab]] — **cara menyetel jaringan** ke mesin rentan (VirtualBox, VMware, Hyper-V, KVM). Baca ini bila VM tak saling `ping`.
- ⚡ [[Lab — Setup Jaringan via CLI]] — padanan terminal dari note di atas (opsional, untuk setup cepat & scriptable).
- 🟢 [[Lab — Metasploitable]] — target Linux klasik (Metasploitable 2 & 3). **Mulai dari sini.**
- 🟢 [[Lab — VulnHub]] — ratusan VM .ova gratis bergaya OSCP.
  - 🤖 [[Lab — Mr-Robot (Setup)]] — contoh setup lengkap satu mesin OVA (VirtualBox + VMware).
  - 🐉 [[Lab — Kioptrix (Setup)]] — seri klasik OSCP dari arsip .rar/VMware (VirtualBox via .vmdk).
  - 🎯 [[Lab — DC-1 (Setup)]] — seri DC, OVA dalam .zip, pintu masuk Drupal (default Bridged → ubah Host-Only).
  - 🎯 [[Lab — DC-2 (Setup)]] — lanjutan DC-1: WordPress → escape rbash → privesc git (butuh entri hosts `dc-2`).
  - 🔱 [[Lab — Symfonos 1 (Setup)]] — enum SMB → LFI/log poisoning; arsip .7z (latih ekstrak format lain).
  - 💥 [[Lab — Brainpan (Setup)]] — satu-satunya jalur buffer overflow / exploit development (port 9999).
- 🟡 [[Lab — Vulnyx]] — VM gaya OSCP dari komunitas Spanyol.
- 🏰 [[Lab — AD Lab Lokal (GOAD)]] — lab Active Directory rentan (lanjutan, RAM besar).
- 🌐 [[Lab — Jaringan Vulnerable (Networking)]] — lab **perangkat jaringan** (router/switch Cisco) rentan via GNS3/EVE-NG/CML/Packet Tracer/Containerlab + serangan & hardening L2/L3.
- 🔵 [[Lab — Platform Lab Lainnya]] — HackMyVM, Proving Grounds, DVWA, Juice Shop, OWASP BWA, dll.

## 🧰 Tools / Resource

- **VirtualBox / VMware** — hypervisor.
- **Kali Linux / Parrot OS** — VM penyerang.
- **netdiscover / nmap -sn / arp-scan** — temukan IP target di lab (lihat [[Scanning & Enumeration]]).
- **Snapshot** — fitur wajib pakai sebelum tiap latihan.
- Alternatif tanpa setup: lab berbasis browser di [[Sumber Belajar & Platform Latihan]] (TryHackMe, HTB).

## 🔗 Kaitan

- Tempat menjalankan semua latihan di [[Red Team (MOC)]] & [[Blue Team (MOC)]].
- Langkah berikutnya setelah target hidup: [[Reconnaissance (Information Gathering)]] → [[Scanning & Enumeration]].
- Platform online sebagai alternatif: [[Sumber Belajar & Platform Latihan]].

## 🎯 Latihan

- Bangun lab inti: **1 Kali + 1 [[Lab — Metasploitable|Metasploitable 2]]**, mode Host-Only, lalu `netdiscover` → `ping` sukses. Itu pencapaian pertamamu.
- Ambil snapshot keduanya, lalu coba restore untuk membuktikan kamu bisa "reset" lab.

## 📖 Sumber

- **TryHackMe — "Setting Up Your Lab"** & "Intro to Offensive Security".
- **VirtualBox Manual** — https://www.virtualbox.org/manual/
- **NetworkChuck / HackerSploit (YouTube)** — tutorial visual membangun home lab.
