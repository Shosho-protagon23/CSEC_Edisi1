# 🪟 Windows & Active Directory Dasar

> [!summary] Ringkasan
> Sebagian besar perusahaan dunia berjalan di atas Windows yang dikelola lewat **Active Directory (AD)**. Karena itu Windows + AD adalah target #1 di dunia korporat, dan medan utama red & blue team enterprise.

**Bagian dari:** [[Fondasi (MOC)]]

---

## 🧠 Konsep Inti

### Windows untuk security
- **User & grup**: `Administrator` = superuser. Grup penting: `Administrators`, `Users`.
- **Registry**: database konfigurasi Windows (`regedit`). Sering jadi tempat persistence malware.
- **Proses & layanan**: `services.msc`, Task Manager.
- **Hash password**: Windows menyimpan **NTLM hash**, bukan password mentah → relevan untuk [[Password Attacks]] (teknik *Pass-the-Hash*).
- **Event Log**: jejak aktivitas → inti deteksi di [[Log Analysis & Monitoring]]. Event ID penting: `4624` (login sukses), `4625` (login gagal), `4688` (proses dibuat).

### Active Directory (AD)
Sistem terpusat untuk mengelola ribuan komputer & user dalam satu organisasi.
- **Domain Controller (DC)** — server "otak" yang memegang database AD. Menguasai DC = menguasai seluruh jaringan.
- **Domain** — kumpulan objek (user, komputer, grup) yang dikelola bersama.
- **Kerberos** — protokol autentikasi AD (berbasis "tiket"). Banyak serangan menyasar ini → [[Active Directory Attacks]].
- **GPO (Group Policy)** — aturan yang dipaksakan ke semua komputer (juga alat [[Hardening & Vulnerability Management|hardening]]).

## ⚙️ Praktik

```powershell
whoami /priv            # lihat hak akun saat ini
net user                # daftar user lokal
net localgroup administrators
systeminfo              # info OS (berguna untuk privesc)
Get-ADUser -Filter *    # daftar user domain (modul AD PowerShell)
```

## 🧰 Tools

- **PowerShell** — bahasa scripting & administrasi Windows (juga senjata attacker).
- **Sysinternals Suite** (Procmon, Procexp, Autoruns) — investigasi mendalam, dipakai di [[Digital Forensics (DFIR)]].
- **BloodHound** — memetakan jalur serangan di AD → [[Active Directory Attacks]].

## 🔗 Kaitan

- Sisi Red: menyerang domain di [[Active Directory Attacks]]; mencuri kredensial di [[Password Attacks]].
- Sisi Blue: memantau Event Log di [[Log Analysis & Monitoring]]; memperketat AD di [[Hardening & Vulnerability Management]].

## 🎯 Latihan

- **TryHackMe — "Windows Fundamentals 1, 2, 3"**.
- **TryHackMe — "Active Directory Basics"**.

## 📖 Sumber

- **Microsoft Learn — Active Directory Domain Services** — https://learn.microsoft.com/windows-server/identity/ad-ds/active-directory-domain-services
- **TryHackMe — Windows & AD path** (gratis sebagian).
