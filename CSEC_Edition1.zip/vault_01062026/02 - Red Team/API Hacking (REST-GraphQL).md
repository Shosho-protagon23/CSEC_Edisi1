# 🔌 API Hacking (REST & GraphQL)

> [!summary] Ringkasan
> Aplikasi modern (mobile, SPA, microservice) berbicara lewat **API** — bukan halaman HTML, tapi endpoint JSON. Banyak bug paling parah ada di sini karena developer mengira API "tersembunyi". Note ini membahas **OWASP API Security Top 10**, dengan fokus **BOLA/IDOR** & **BFLA** (kelemahan otorisasi paling umum), **mass assignment**, dan dunia **GraphQL** (introspection, batching). Pelengkap [[Web Application Hacking (OWASP Top 10)]] dari sisi API.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Web Application Hacking (OWASP Top 10)]], [[Jaringan Komputer]]

> [!note] Kapan ini relevan
> Saat target adalah app mobile ([[Lab — Mobile (Android-iOS) Hacking]]) atau SPA — backend-nya hampir selalu REST/GraphQL. Bug otorisasi API adalah temuan bug bounty paling sering & paling berharga.

---

## 🧠 Konsep Inti — OWASP API Security Top 10 (2023)

| Kode | Nama | Inti |
|---|---|---|
| **API1** | **BOLA** (Broken Object Level Authorization) | ganti ID objek (`/users/123`→`/users/124`) akses data orang lain — IDOR-nya API, #1 tersering |
| **API2** | Broken Authentication | token/JWT lemah, no rate-limit di login |
| **API3** | Broken Object Property Level Auth | over-exposure field + **mass assignment** |
| **API4** | Unrestricted Resource Consumption | tanpa rate-limit → DoS/biaya |
| **API5** | **BFLA** (Broken Function Level Authorization) | user biasa panggil fungsi admin (`POST /admin/...`) |
| **API6** | Unrestricted Access to Sensitive Business Flows | abuse alur bisnis (beli tiket borongan) |
| **API7** | SSRF | endpoint ambil URL → lihat [[Web Exploitation Lanjutan]] |
| **API8** | Security Misconfiguration | CORS longgar, verbose error |
| **API9** | Improper Inventory Management | endpoint lama/`v1`/staging tak terurus (*shadow API*) |
| **API10** | Unsafe Consumption of APIs | percaya buta API pihak ketiga |

### Mass assignment (API3)
Server mem-*bind* otomatis seluruh JSON body ke objek. Kirim field ekstra yang tak ada di form:
```json
{ "username": "budi", "email": "a@b.c", "role": "admin", "isVerified": true }
```
Jika backend tidak allowlist field → naik jadi admin.

### GraphQL — beda main
Satu endpoint (`/graphql`), klien minta data persis yang diinginkan.
- **Introspection** — query `__schema` membongkar SELURUH skema (semua tipe, query, mutation) → peta serangan lengkap.
- **Batching** — kirim banyak query dalam satu request → bypass rate-limit / brute force (mis. tebak OTP ribuan kali sekaligus).
- **Nested/deep query** — query bersarang dalam → DoS.
- BOLA/BFLA tetap berlaku: cek tiap *mutation* apakah otorisasinya benar.

## ⚙️ Praktik

```bash
# --- Temukan & petakan endpoint ---
ffuf -u https://target/api/v1/FUZZ -w api-wordlist.txt        # brute endpoint
# baca dokumentasi mesin: /swagger.json, /openapi.json, /api-docs

# --- BOLA: iterasi ID (lewat Burp Intruder / script) ---
curl -H "Authorization: Bearer $TOKEN" https://target/api/v1/orders/1001
curl -H "Authorization: Bearer $TOKEN" https://target/api/v1/orders/1002   # punya orang lain?

# --- BFLA: panggil fungsi admin sebagai user biasa ---
curl -X DELETE -H "Authorization: Bearer $USERTOKEN" https://target/api/v1/users/5
```

```graphql
# --- GraphQL introspection (bongkar skema) ---
{ __schema { types { name fields { name } } } }
```
```bash
# Bongkar skema otomatis & bangun peta:
python3 -m graphw00f -d -t https://target/graphql     # fingerprint engine
clairvoyance https://target/graphql -o schema.json    # rekonstruksi skema walau introspection mati
```

> [!tip] Burp tetap pusat kerja
> Import koleksi **Postman/OpenAPI** ke Burp, pakai **Autorize** (deteksi BOLA/BFLA otomatis dgn 2 sesi user), **InQL** untuk GraphQL, dan **Param Miner** untuk field tersembunyi (mass assignment).

## 🧰 Tools

- **Burp Suite** + **Autorize** (uji otorisasi 2-user), **InQL** (GraphQL), **Param Miner**.
- **Postman / Insomnia** — eksplorasi & replay request API.
- **ffuf / kiterunner** — brute endpoint & rute API.
- **graphw00f / clairvoyance / GraphQL Voyager** — fingerprint & peta GraphQL.
- **jwt_tool** — uji token (lihat [[Web Exploitation Lanjutan]]).

## 🔗 Kaitan

- Dasar web & alat Burp: [[Web Application Hacking (OWASP Top 10)]]; teknik server-side: [[Web Exploitation Lanjutan]] (SSRF/JWT dipakai ulang di API).
- Backend mobile = API: [[Lab — Mobile (Android-iOS) Hacking]] (intercept → uji API sama).
- API cloud (IAM/metadata) → [[Cloud Security (AWS-Azure-GCP)]] · [[Container & Kubernetes Offense]] (API server K8s).
- **Sisi Blue ↔** [[Log Analysis & Monitoring]] (pola enumerasi ID, lonjakan 4xx/403), WAF & API gateway di [[Network Security (Firewall, IDS-IPS)]], desain aman [[Threat Modeling]].

## 🎯 Latihan

- **PortSwigger Web Security Academy — API Testing & GraphQL** (lab gratis). https://portswigger.net/web-security/api-testing
- **OWASP crAPI** & **VAmPI** — API sengaja rentan.
- **DVGA (Damn Vulnerable GraphQL App)** — latih introspection/batching.

## 📖 Sumber

- **OWASP API Security Top 10 (2023)** — https://owasp.org/API-Security/
- **OWASP crAPI** — https://github.com/OWASP/crAPI
- **PortSwigger — API & GraphQL** — https://portswigger.net/web-security
- **Hacking APIs** (Corey Ball) — buku rujukan.
