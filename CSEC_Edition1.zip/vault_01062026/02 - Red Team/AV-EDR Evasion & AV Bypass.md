# 🥷 AV/EDR Evasion & AV Bypass

> [!summary] Ringkasan
> Sisi **ofensif** dari [[Endpoint Security & EDR]]: bagaimana payload bertahan hidup di mesin yang dijaga antivirus/EDR. Tiga lapis yang harus dilewati: **static** (signature file di disk → obfuscation/packing), **AMSI/script** (Windows memindai script di memori → AMSI bypass), dan **behavioral/telemetry** (EDR memantau API & menyuntik hook → unhooking, syscall langsung, in-memory execution). Tujuan akhir: eksekusi kode tanpa memicu deteksi. Berpasangan ketat dengan Blue — pahami **apa yang dilihat EDR** untuk tahu cara menghindarinya.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Exploitation & Metasploit]], [[Post-Exploitation & Pivoting]], [[Endpoint Security & EDR]] (paham cara EDR mendeteksi)

---

> [!danger] Konteks penggunaan
> Teknik evasion bersifat **dual-use**. Pakai hanya dalam **engagement berizin / lab pribadi / riset**. Tujuannya menguji efektivitas kontrol endpoint, bukan menyebarkan malware. Lihat [[00 - START HERE]].

## 🧠 Konsep Inti

### Tiga lapis deteksi yang harus dilewati
| Lapis | Cara deteksi (Blue) | Cara lewati (Red) |
|---|---|---|
| **Static** | signature hash/byte di disk | obfuscation, packing, enkripsi, polymorphism |
| **AMSI / script** | scan konten script di memori sebelum eksekusi | **AMSI bypass** (patch amsi.dll), obfuscation PowerShell |
| **Behavioral** | hook userland API, telemetri ETW, rantai proses | **unhooking**, **direct/indirect syscalls**, in-memory |

### Titik-titik kunci di Windows
- **AMSI** (Antimalware Scan Interface) — Windows kirim isi script/`.NET` ke AV sebelum jalan. Bypass = patch `AmsiScanBuffer` agar selalu kembalikan "bersih".
- **ETW** (Event Tracing for Windows) — sumber telemetri EDR; **ETW patching** membutakan sebagian sensor.
- **Userland hooks** — EDR menyuntik DLL ke proses & meng-hook API (mis. `NtAllocateVirtualMemory`). **Unhooking** mengembalikan `ntdll` bersih dari disk; **direct syscalls** (Hell's Gate/Halos Gate/SysWhispers) melewati hook sepenuhnya.

### Teknik eksekusi yang minim jejak
- **Fileless / in-memory** — jangan sentuh disk; muat shellcode langsung ke memori.
- **Process injection** — CreateRemoteThread klasik → lebih siluman: **APC injection, process hollowing, module stomping, thread hijacking, early-bird**.
- **Reflective DLL loading** — muat DLL tanpa `LoadLibrary`/tanpa file.
- **LOLBins** — pakai biner sah Windows (rundll32, regsvr32, mshta) agar "membaur".

> Setiap teknik di atas punya jejak yang **diburu** di [[Threat Hunting]] & [[Endpoint Security & EDR]] — itulah sisi pertahanannya.

## ⚙️ Praktik

```text
# Konsep AMSI bypass (PowerShell) — patch in-memory amsiInitFailed / AmsiScanBuffer.
#   Banyak one-liner publik cepat ter-signature → andalkan obfuscation + varian sendiri.

# Tools yang lazim dipakai:
#  - Obfuscation .NET    : ConfuserEx
#  - Obfuscation PS      : Invoke-Obfuscation, Chameleon
#  - Shellcode loader    : donut (EXE/DLL→shellcode), sRDI
#  - Encoder/crypter     : custom XOR/AES stub (hindari yg sudah ter-signature)
#  - Direct syscalls     : SysWhispers2/3, Hell's Gate
#  - Test deteksi lokal  : ThreatCheck / DefenderCheck (cari byte yg men-trigger)
```

```bash
# Alur khas membuat loader yang lolos:
# 1) generate shellcode (msfvenom / Cobalt Strike / Sliver)
# 2) enkripsi shellcode (AES) → embed di loader
# 3) loader: alokasi RW → tulis → ubah RX → eksekusi (atau via syscall langsung)
# 4) unhook ntdll bila EDR menghook; AMSI/ETW patch bila perlu script
# 5) uji di lab ber-EDR (Defender/dll) dgn ThreatCheck → iterasi byte yg ke-flag
```

## 🧰 Tools

- **donut / sRDI** — konversi EXE/DLL ke shellcode posisi-independen.
- **SysWhispers2/3, Hell's Gate** — direct/indirect syscalls (lewati userland hook).
- **Invoke-Obfuscation / ConfuserEx / Chameleon** — obfuscation.
- **ThreatCheck / DefenderCheck** — cari byte yang memicu signature.
- **ScareCrow / Freeze / Nimcrypt2** — framework loader anti-EDR.
- **PE-sieve / Moneta** — (Blue/verify) deteksi injeksi → uji apakah loadermu kelihatan.

## 🔗 Kaitan

- **Pasangan Blue (WAJIB baca):** [[Endpoint Security & EDR]] — apa yang dilihat EDR; [[Threat Hunting]] & [[Log Analysis & Monitoring]] — jejak yang diburu.
- Sumber shellcode/akses: [[Exploitation & Metasploit]], dikirim oleh [[Payload Development & Initial Access]].
- Dipakai oleh implant: [[C2 Frameworks (Command & Control)]].
- Bagian dari operasi tersembunyi: [[Red Team Infrastructure & OPSEC]].
- Konsep proses/memori Windows: [[Windows & Active Directory Dasar]], [[Buffer Overflow (Stack-Based)]] (shellcode).

## 🎯 Latihan

- Di lab ber-Windows Defender: buat **loader sederhana** (alokasi→decrypt→execute shellcode), jalankan **ThreatCheck** untuk menemukan byte yang ke-flag, lalu obfuscate hingga lolos static.
- Praktikkan **AMSI bypass** untuk menjalankan script yang tadinya diblok; lalu amati di sisi Blue ([[Endpoint Security & EDR]]) apa yang masih tertangkap secara behavioral.
- Bandingkan deteksi loader **dengan vs tanpa** direct syscalls (SysWhispers).

## 📖 Sumber

- **MITRE ATT&CK — Defense Evasion (TA0005)**.
- **Maldev Academy** & **Sektor7 — Malware Development** (kursus pembuatan loader).
- **ired.team (Red Team Notes)** — https://www.ired.team
- **VX-Underground** — referensi teknik (riset).
