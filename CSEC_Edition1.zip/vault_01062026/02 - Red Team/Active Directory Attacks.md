# 🏢 Active Directory Attacks

> [!summary] Ringkasan
> Active Directory mengelola hampir semua jaringan korporat Windows. Karena terpusat, satu kesalahan konfigurasi bisa membuat penyerang menguasai **seluruh domain**. Ini medan utama red team enterprise & pentest profesional.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Windows & Active Directory Dasar]], [[Password Attacks]], [[Post-Exploitation & Pivoting]]

---

## 🧠 Konsep Inti — serangan AD klasik

### Berbasis Kerberos
- **Kerberoasting** — minta tiket layanan (TGS) lalu crack offline untuk dapat password akun service.
- **AS-REP Roasting** — menyasar akun yang tak butuh pre-auth Kerberos.
- **Golden / Silver Ticket** — memalsukan tiket Kerberos setelah menguasai akun `krbtgt` → akses domain "abadi".

### Berbasis kredensial
- **Pass-the-Hash / Pass-the-Ticket** — autentikasi pakai hash/tiket tanpa tahu password (lihat [[Password Attacks]]).
- **DCSync** — meniru Domain Controller untuk meminta semua hash password domain.

### Berbasis jalur
- **BloodHound** memetakan "jalur terpendek menuju Domain Admin" dari relasi user, grup, dan sesi.

## ⚙️ Praktik (konsep — selalu di lab!)

```bash
# Enumerasi & jalur serangan
bloodhound-python -d corp.local -u user -p pass -c all
# Kerberoasting (Impacket)
GetUserSPNs.py corp.local/user:pass -request
# Crack tiket
hashcat -m 13100 tickets.txt rockyou.txt
# DCSync (Mimikatz)
lsadump::dcsync /user:Administrator
```

## 🧰 Tools

- **BloodHound / SharpHound** — visualisasi jalur serangan AD.
- **Impacket** (kumpulan script Python: secretsdump, GetUserSPNs, psexec).
- **Mimikatz** — pencurian kredensial & manipulasi tiket.
- **CrackMapExec / NetExec** — "pisau Swiss" untuk jaringan Windows/AD.

## 🔗 Kaitan

- **Lanjut ke jalur eskalasi modern:** [[Active Directory Attacks Lanjutan]] (ACL/ACE abuse, delegation/RBCD, AD CS ESC1–ESC8, coercion+relay, Shadow Credentials, trust attacks).
- Memetakan ke taktik *Credential Access, Lateral Movement, Privilege Escalation* di [[Cyber Kill Chain & MITRE ATT&CK]].
- **Sisi Blue ↔** [[Hardening & Vulnerability Management]] (mengeraskan AD, tiered admin, LAPS) & [[Threat Hunting]] (mendeteksi Kerberoasting/DCSync di [[Log Analysis & Monitoring|log AD]]).

## 🎯 Latihan

- **TryHackMe — "Attacktive Directory"**, path **"Compromising Active Directory"**.
- **Hack The Box — Pro Labs "Dante" / "Zephyr"** (berbayar) atau mesin AD gratis.
- **Lab lokal sendiri:** bangun [[Lab — AD Lab Lokal (GOAD)]] untuk latihan offline tanpa batas.

## 📖 Sumber

- **The Hacker Recipes — Active Directory** — https://www.thehacker.recipes/ad/
- **HackTricks — Active Directory Methodology** — https://book.hacktricks.xyz
- **BloodHound docs** — https://bloodhound.readthedocs.io
