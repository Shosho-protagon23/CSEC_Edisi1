# 🚗 Automotive (CAN Bus) Hacking

> [!summary] Ringkasan
> Mobil modern adalah jaringan komputer beroda: puluhan **ECU** (Electronic Control Unit) saling bicara lewat **CAN bus** — protokol yang dirancang tahun 1980-an **tanpa autentikasi & tanpa enkripsi**. Note ini membahas cara membaca lalu lintas CAN lewat port **OBD-II**, mengidentifikasi pesan (arbitration ID), dan **replay/fuzzing** untuk memicu fungsi kendaraan — semua dilatih di **simulator** (ICSim), bukan kendaraan jalan.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Jaringan Komputer]], [[Linux Dasar untuk Security]]

---

> [!danger] Bahaya nyawa — hanya simulator / bench
> Mengirim pesan CAN ke kendaraan yang **sedang berjalan** bisa mematikan rem/setir → **fatal**. Latih **hanya** di simulator (**ICSim**), *test bench* ECU lepas, atau kendaraan milik sendiri dalam kondisi diam & terangkat, di lingkungan terkontrol. Riset otomotif diatur ketat (mis. regulasi UN R155).

## 🧠 Konsep Inti

### Kenapa CAN bus rapuh
CAN dirancang untuk **keandalan & real-time**, bukan keamanan:
- **Broadcast** — setiap pesan terdengar oleh semua ECU di bus.
- **Tanpa autentikasi** — ECU mana pun (atau alat penyerang) bisa kirim pesan; tak ada cara membuktikan asal.
- **Tanpa enkripsi** — isi pesan terlihat jelas.
- **Prioritas by arbitration ID** — ID lebih rendah menang bus → bisa dipakai untuk *bus flooding* (DoS).

### Anatomi frame CAN
```text
[Arbitration ID] [DLC: panjang data] [Data 0..8 byte]
   contoh:  244#01F4         ID=0x244, data=01 F4
```
- **Arbitration ID** = "topik" pesan (mis. ID tertentu = sudut setir, lain = RPM).
- Tugas penyerang: **memetakan ID → fungsi** dengan mengamati perubahan saat menekan tombol/pedal.

### Permukaan & jalur masuk
- **OBD-II** (port diagnostik wajib, di bawah setir) — akses CAN paling mudah via adapter.
- **Infotainment / telematics / TPMS / key fob (RF)** — jalur nirkabel.
- **UDS (ISO 14229)** — protokol diagnostik di atas CAN; *security access* (seed-key) sering lemah → flash firmware ECU.

### Teknik inti
- **Sniffing** — rekam semua frame saat melakukan aksi (buka pintu, nyalakan lampu).
- **Replay** — kirim ulang frame yang direkam → ulangi aksi.
- **Fuzzing** — kirim ID/data acak untuk menemukan fungsi tersembunyi (berisiko).

## ⚙️ Praktik

```bash
# --- Siapkan simulator (aman) ---
# ICSim (Instrument Cluster Simulator) oleh OpenGarages
./setup_vcan.sh                    # buat antarmuka virtual CAN: vcan0
./icsim vcan0                      # dashboard simulasi
./controls vcan0                   # remote (gas/rem/pintu) → bangkitkan trafik

# --- can-utils: baca, kirim, replay ---
candump vcan0                      # lihat semua frame realtime
candump -l vcan0                   # log ke file candump-*.log
cansend vcan0 244#0000000011       # kirim 1 frame manual
canplayer -I candump-xxxx.log      # REPLAY trafik yang direkam

# --- Cari ID yang berubah saat aksi ---
cansniffer vcan0                   # sorot byte yang berubah → korelasikan dgn tombol

# --- Fuzzing sederhana ---
cangen vcan0 -g 10 -I i -D r       # generate frame acak (HATI-HATI: simulator saja)
```

## 🧰 Tools

- **can-utils** (candump, cansend, canplayer, cansniffer, cangen) — paket Linux standar CAN.
- **ICSim** (OpenGarages) — simulator dashboard untuk latihan aman.
- **SocketCAN / vcan** — dukungan CAN di kernel Linux + antarmuka virtual.
- **CANalyzat0r / Caring Caribou** — framework analisis & serangan CAN (incl. UDS scan).
- **Hardware:** adapter **OBD-II→USB (CANtact, CANable, Macchina M2)**, **Arduino + CAN shield**.

## 🔗 Kaitan

- Domain perangkat fisik sejajar: [[Lab — IoT & Embedded Hacking]] (UART/firmware ECU), [[Lab — OT-ICS-SCADA Hacking]] (sama-sama protokol kontrol tanpa auth — pola "replay via bus" mirip Modbus).
- Bedah firmware ECU: [[Reverse Engineering untuk Offense]] · [[Malware Analysis Dasar]].
- Key fob/TPMS = serangan RF: bersinggungan dgn radio di [[Lab — IoT & Embedded Hacking]].
- **Sisi Blue ↔** [[Network Security Lanjutan (NSM-NDR)]] (IDS CAN/anomali bus), [[Defense in Depth & Security Architecture]] (segmentasi domain CAN, gateway), [[Hardening & Vulnerability Management]] (CAN authentication/SecOC, secure boot ECU).

## 🎯 Latihan

- Pasang **ICSim** di Kali/Ubuntu, petakan minimal 3 ID (setir, RPM, pintu) lewat `cansniffer`, lalu **replay** untuk mereproduksi aksi.
- **OpenGarages — Car Hacking Village** material; **CTF otomotif** (mis. di DEF CON CHV).

## 📖 Sumber

- **The Car Hacker's Handbook** (Craig Smith) — gratis, rujukan utama. https://opengarages.org/handbook/
- **can-utils** — https://github.com/linux-can/can-utils
- **ICSim** — https://github.com/zombieCraig/ICSim
- **MITRE / Auto-ISAC**; regulasi **UN R155 / ISO 21434** (konteks pertahanan).
