# ☁️ Cloud Security (AWS / Azure / GCP)

> [!summary] Ringkasan
> Komputasi awan mengubah model keamanan: tak ada lagi "perimeter" jelas, dan kesalahan paling umum bukan exploit memori tapi **misconfiguration** (bucket publik, IAM terlalu longgar, kredensial bocor). Note ini memetakan **attack surface cloud** lintas tiga penyedia besar (**AWS, Azure, GCP**) — enumerasi, jalur eskalasi IAM, abuse metadata/serverless — sekaligus **Shared Responsibility Model** dan pertahanannya. Ini "environment" target baru, sejajar dengan [[Active Directory Attacks|AD]] tapi untuk infrastruktur cloud. Pintu masuk sering dari [[Web Exploitation Lanjutan|SSRF → metadata]].

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Jaringan Komputer]], [[Kriptografi Dasar]], [[Web Application Hacking (OWASP Top 10)]]

> [!note] Penempatan
> Note ditaruh di Red Team karena fokus **offensive (cloud pentesting)**, tapi punya section pertahanan & banyak cross-link [[Hardening & Vulnerability Management|Blue]] — cloud security memang lintas Red/Blue.

---

## 🧠 Konsep Inti

### Shared Responsibility Model
Penyedia mengamankan **"security OF the cloud"** (hardware, hypervisor, layanan terkelola); **pelanggan** mengamankan **"security IN the cloud"** (konfigurasi, IAM, data, OS di VM). **Mayoritas insiden = kesalahan di sisi pelanggan** — itulah yang diuji pentester.

### IAM adalah "Active Directory"-nya cloud
Inti keamanan cloud = **Identity & Access Management**. Konsep lintas-penyedia:
| Konsep | AWS | Azure | GCP |
|---|---|---|---|
| Identitas | IAM User / Role | Entra ID (AAD) User / Service Principal | Service Account |
| Izin | IAM Policy (JSON) | RBAC Role | IAM Role/Binding |
| Eskalasi khas | `iam:PassRole`, `sts:AssumeRole`, policy lemah | Managed Identity, Owner/Contributor abuse | `iam.serviceAccounts.actAs`, token impersonation |
| Identitas mesin | Instance Profile (EC2) | Managed Identity (VM) | Attached Service Account (GCE) |

### Kesalahan konfigurasi tersering
- **Storage publik** — S3 bucket / Azure Blob / GCS terbuka ke internet (kebocoran data klasik).
- **IAM terlalu permisif** — wildcard `"Action": "*"`, role yang bisa eskalasi ke admin.
- **Kredensial bocor** — access key di repo Git, di env var, di metadata.
- **Security group / NSG longgar** — port admin (22/3389) terbuka ke `0.0.0.0/0`.
- **Logging mati** — CloudTrail/Activity Log tidak aktif → serangan tak terlihat.

### Metadata service (jalur eskalasi paling penting)
Tiap VM bisa query endpoint metadata internal untuk mengambil **kredensial sementara** identitas mesin:
- **AWS** — `http://169.254.169.254/latest/meta-data/iam/security-credentials/` (IMDSv1 rawan; **IMDSv2** butuh token).
- **Azure** — `http://169.254.169.254/metadata/identity/oauth2/token` (header `Metadata: true`).
- **GCP** — `http://metadata.google.internal/computeMetadata/v1/` (header `Metadata-Flavor: Google`).
Lewat **[[Web Exploitation Lanjutan|SSRF]]**, penyerang dari luar bisa memaksa server query ini → curi token → akses API cloud.

### Serverless & kontainer
- **Lambda / Functions** — variabel lingkungan sering simpan secret; event-injection.
- **Container/K8s** — lihat sebagai sub-domain tersendiri (RBAC, service account token di `/var/run/secrets`, escape container).

---

## ⚙️ Cara Kerja / Praktik (selalu dengan izin / akun sendiri!)

### 1. Enumerasi identitas & izin (setelah dapat kredensial)
```bash
# AWS — siapa saya & apa izin saya?
aws sts get-caller-identity
aws iam list-attached-user-policies --user-name <user>
# Azure
az ad signed-in-user show ; az role assignment list --assignee <id>
# GCP
gcloud auth list ; gcloud projects get-iam-policy <project>
```

### 2. Cari misconfiguration & jalur eskalasi (otomasi)
```bash
# pemetaan keseluruhan postur (mirip BloodHound utk cloud):
prowler aws                      # benchmark CIS AWS
scoutsuite aws|azure|gcp         # audit multi-cloud
pacu                             # framework eksploitasi AWS (mirip Metasploit)
# privesc path:
# AWS: pmapper / cloudsplaining ; Azure: AzureHound ; GCP: hayat
```

### 3. Abuse metadata via SSRF
```bash
# dari aplikasi rentan SSRF (lihat Web Exploitation Lanjutan):
curl "http://target/fetch?url=http://169.254.169.254/latest/meta-data/iam/security-credentials/ROLE"
# → AccessKeyId/SecretAccessKey/Token → konfigurasi aws cli → akses akun
```

### 4. Cari kredensial bocor & storage publik
```bash
trufflehog git https://github.com/org/repo     # secret di repo
# enumerasi bucket publik:
aws s3 ls s3://nama-bucket --no-sign-request
```

> [!warning] Etika & ruang lingkup cloud
> Menyerang akun cloud tanpa izin = ilegal **dan** sering melanggar ToS penyedia. Latih hanya di **akun sendiri** (free tier) atau platform yang dirancang untuk itu (CloudGoat, flaws.cloud). Lihat etika di [[Red Team (MOC)]].

---

## 🛡️ Sisi pertahanan

- **IAM least privilege** — hindari wildcard, audit policy, gunakan **permission boundary**; rotasi & hindari long-lived keys (pakai role/federation).
- **Storage** — block public access by default; enkripsi at-rest; cek dengan Prowler/ScoutSuite.
- **Metadata** — wajibkan **IMDSv2** (AWS); batasi akses metadata dari workload.
- **Logging & deteksi** — aktifkan **CloudTrail / Azure Activity Log / GCP Audit Logs**; alihkan ke SIEM ([[SOC & SIEM]], [[Log Analysis & Monitoring]]); deteksi anomali via **GuardDuty / Defender for Cloud / Security Command Center**.
- **Postur** — CSPM (Cloud Security Posture Management), benchmark **CIS**, IaC scanning (checkov/tfsec) → masuk [[Hardening & Vulnerability Management]].
- **Desain** — terapkan [[Threat Modeling]] untuk arsitektur cloud sejak awal.

## 🧰 Tools

- **Pacu** — framework eksploitasi AWS (offensive).
- **ScoutSuite** — audit multi-cloud (AWS/Azure/GCP). **Prowler** — benchmark CIS AWS.
- **CloudGoat** (Rhino Security) — lab AWS sengaja-rentan untuk latihan.
- **pmapper / cloudsplaining** — analisis privesc IAM AWS. **AzureHound / ROADtools** — Azure/Entra.
- **trufflehog / gitleaks** — buru kredensial bocor.
- **aws/az/gcloud CLI** — enumerasi & interaksi API.

## 🔗 Kaitan

- **Pintu masuk umum:** [[Web Exploitation Lanjutan]] (SSRF → metadata → kredensial IAM).
- **Beban kerja cloud-native:** [[Container & Kubernetes Offense]] (escape container → ambil alih node/cluster → metadata → IAM).
- IAM cloud = analogi [[Active Directory Attacks|AD]] untuk cloud (identitas, eskalasi, jalur).
- Kredensial bocor → [[Password Attacks]]; setelah akses → gerak lateral [[Post-Exploitation & Pivoting]] (pivot antar layanan/akun).
- Memetakan ke [[Cyber Kill Chain & MITRE ATT&CK]] (ada **ATT&CK for Cloud** matrix).
- **Sisi Blue ↔** [[Cloud Detection & Response]] (pasangan defensif langsung: deteksi tiap teknik di sini), [[Hardening & Vulnerability Management]] (CSPM/CIS/IAM hardening), [[SOC & SIEM]] & [[Log Analysis & Monitoring]] (CloudTrail→SIEM), [[Threat Hunting]] (anomali API), [[Incident Response]] (IR cloud), desain aman [[Threat Modeling]].

## 🎯 Latihan

- **flaws.cloud / flaws2.cloud** — tantangan web gratis berbasis misconfig AWS (mulai dari sini).
- **CloudGoat** (https://github.com/RhinoSecurityLabs/cloudgoat) — skenario privesc AWS di akunmu sendiri.
- **PwnedLabs / TryHackMe "Cloud" path / HTB cloud tracks**.
- Latih rantai: SSRF → metadata → kunci IAM → enumerasi izin → temukan jalur privesc → admin. Tulis write-up.

## 📖 Sumber

- **HackTricks Cloud** — https://cloud.hacktricks.xyz
- **AWS / Azure / GCP Well-Architected — Security Pillar** (dokumentasi resmi pertahanan).
- **MITRE ATT&CK for Cloud** — https://attack.mitre.org/matrices/enterprise/cloud/
- **CIS Benchmarks** (AWS/Azure/GCP) — baseline hardening.
- **Rhino Security Labs blog** — riset AWS privesc & Pacu.
