# ⛓️ Cyber Kill Chain & MITRE ATT&CK

> [!summary] Ringkasan
> Dua kerangka yang memetakan **tahapan sebuah serangan**. Kill Chain memberi gambaran besar (7 fase), ATT&CK memberi detail teknik konkret. Dipakai red team untuk merencanakan, blue team untuk mendeteksi — jadi ini "bahasa bersama" cyber security.

**Bagian dari:** [[Red Team (MOC)]] · juga dipakai [[Blue Team (MOC)]]
**Prasyarat:** [[Konsep Dasar Keamanan (CIA Triad)]]

---

## 🧠 Konsep Inti

### 1. Lockheed Martin Cyber Kill Chain (7 fase)
Model klasik alur serangan:
1. **Reconnaissance** — kumpulkan info → [[Reconnaissance (Information Gathering)]].
2. **Weaponization** — siapkan senjata (mis. malware + exploit).
3. **Delivery** — kirim ke target (email phishing, USB, web) → [[Social Engineering]].
4. **Exploitation** — picu celah → [[Exploitation & Metasploit]].
5. **Installation** — pasang backdoor/persistence.
6. **Command & Control (C2)** — kendalikan korban dari jauh.
7. **Actions on Objectives** — capai tujuan (curi data, enkripsi, dll).

> Ide pertahanan: putus **satu** mata rantai saja, serangan gagal. Itu dasar [[Defense in Depth & Security Architecture]].

### 2. MITRE ATT&CK
"Ensiklopedia" taktik & teknik penyerang **nyata**, berbasis observasi dunia nyata. Strukturnya:
- **Tactics** = *tujuan* penyerang (kolom), mis. *Initial Access, Privilege Escalation, Exfiltration*.
- **Techniques** = *cara* mencapainya, diberi ID `Txxxx` (mis. `T1566` = Phishing).
- **Sub-techniques** = variasi lebih spesifik.

Contoh pemetaan: [[Privilege Escalation]] di Windows lewat layanan rentan = teknik dalam taktik *Privilege Escalation*.

### 3. Bonus: MITRE D3FEND
Pasangan defensif dari ATT&CK — daftar tindakan pertahanan. Dipakai [[Blue Team (MOC)]].

## ⚙️ Cara Pakai (praktis)

- **Red team**: rencanakan operasi tahap demi tahap, lapor temuan dengan ID ATT&CK agar mudah dipahami → [[Reporting & Sertifikasi (OSCP-dll)]].
- **Blue team**: petakan deteksi yang sudah/belum kamu punya ke matriks ATT&CK (disebut *coverage mapping*) → [[Threat Hunting]], [[SOC & SIEM]].

## 🔗 Kaitan

- Memberi struktur ke seluruh [[Red Team (MOC)]].
- Dipakai untuk berburu ancaman di [[Threat Hunting]] & memetakan deteksi di [[SOC & SIEM]].
- Sumber info musuh: [[Threat Intelligence]].

## 🎯 Latihan

- Buka **MITRE ATT&CK Navigator**, pilih satu grup APT, lihat teknik yang mereka pakai.
- **TryHackMe — "MITRE"** dan **"Cyber Kill Chain"** rooms.

## 📖 Sumber

- **MITRE ATT&CK** — https://attack.mitre.org (situs resmi, wajib bookmark).
- **Lockheed Martin Cyber Kill Chain** — https://www.lockheedmartin.com/en-us/capabilities/cyber/cyber-kill-chain.html
