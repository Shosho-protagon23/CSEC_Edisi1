# 🐧⬆️ Linux Privilege Escalation Lanjutan

> [!summary] Ringkasan
> Lanjutan dari [[Privilege Escalation]] khusus **Linux**, mendalami vektor yang sering muncul di box "medium/hard" & lingkungan nyata: **kernel exploit** (DirtyCow/DirtyPipe/PwnKit), **Linux capabilities**, **SUID + GTFOBins** mendalam, **sudo misconfig & CVE**, abuse **cron/PATH/wildcard**, **NFS `no_root_squash`**, serta pelarian **namespace/cgroup**. Tujuan tetap: dari user biasa → **root**.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Privilege Escalation]], [[Linux Dasar untuk Security]]

> [!note] Kapan ini relevan
> Setelah nyaman dengan `linpeas`/`sudo -l`/SUID dasar. Di sini kita tahu **kenapa** tiap vektor bekerja dan cara mengeksploitasinya manual saat tool otomatis buntu.

---

## 🧠 Konsep Inti — vektor lanjutan

### 1. Linux Capabilities
Root "dipecah" jadi capability granular. Binary dengan capability tertentu = root parsial.
- **`cap_setuid`** → set UID ke 0 (root) dari dalam program.
- **`cap_dac_read_search`** → baca file apa pun (mis. `/etc/shadow`).
- **`cap_sys_admin` / `cap_sys_ptrace`** → near-root.
Cari: `getcap -r / 2>/dev/null`. Eksploitasi referensi: **GTFOBins** (kolom *Capabilities*).

### 2. SUID + GTFOBins (mendalam)
SUID = jalankan sebagai pemilik (sering root). Banyak binary "sah" punya mode shell/baca-file → escape. Selain biner umum, perhatikan **biner kustom SUID** (RE-kan dengan [[Reverse Engineering untuk Offense]]) dan SUID yang memanggil program lain via **PATH relatif** (lihat #5).

### 3. sudo — misconfig & CVE
- `sudo -l` → entri `NOPASSWD` ke biner yang bisa di-escape (GTFOBins).
- `LD_PRELOAD` / `LD_LIBRARY_PATH` di `env_keep` → load library jahat.
- **CVE-2021-3156 (Baron Samedit)** — heap overflow `sudoedit`, root tanpa syarat di versi rentan.
- **CVE-2019-14287** — `sudo -u#-1` jalankan sebagai root.
- **CVE-2023-22809** (sudoedit `-e` arg injection).

### 4. Kernel exploit
Versi kernel lama & rentan → root langsung. (Berisiko crash — hati-hati di prod.)
- **DirtyCow (CVE-2016-5195)**, **DirtyPipe (CVE-2022-0847)** — tulis ke file read-only.
- **PwnKit (CVE-2021-4034)** — polkit `pkexec`, sangat luas terdampak.
- **Looney Tunables (CVE-2023-4911)** — glibc `GLIBC_TUNABLES`.
Identifikasi: `uname -r`, `cat /etc/os-release`, lalu cocokkan exploit.

### 5. Cron, PATH & wildcard
- **Cron job root** memanggil skрипт **world-writable** → tulis ulang isinya.
- Skrip cron pakai **PATH relatif** → taruh biner palsu di direktori ber-prioritas.
- **Wildcard injection** — `tar`/`rsync`/`chown *` di direktori yang bisa kita isi file `--checkpoint-action=...` (tar) → eksekusi perintah.

### 6. NFS `no_root_squash`
Share NFS dengan opsi ini → file yang kita buat sebagai root di klien tetap root di server. Mount, taruh biner SUID root, jalankan.

### 7. Pelarian container/namespace
Jika di dalam container → lihat [[Container & Kubernetes Offense]] (mount host, docker.sock, privileged).

## ⚙️ Praktik

```bash
# --- Enumerasi terarah ---
./linpeas.sh -a                      # menyeluruh
pspy64                               # intip proses/cron yg jalan TANPA root (kunci cron-abuse)
getcap -r / 2>/dev/null              # capabilities
find / -perm -4000 -type f 2>/dev/null   # SUID
sudo -l ; uname -a ; cat /etc/exports    # sudo, kernel, NFS

# --- Capability cap_setuid (contoh: python berkemampuan) ---
/usr/bin/python3 -c 'import os; os.setuid(0); os.system("/bin/bash")'

# --- Wildcard injection lewat tar (cron root menjalankan `tar czf bkp *`) ---
echo 'cp /bin/bash /tmp/r; chmod +s /tmp/r' > shell.sh
touch -- '--checkpoint=1'
touch -- '--checkpoint-action=exec=sh shell.sh'

# --- NFS no_root_squash ---
mount -o rw 10.10.10.1:/share /mnt
cp /bin/bash /mnt/bash && chmod +s /mnt/bash    # dari root di mesin penyerang
# lalu di target:  /share/bash -p
```

> [!tip] Alur disiplin
> 1) jalankan `linpeas` **dan** `pspy` (cron sering tak terlihat statis) → 2) prioritaskan jalur **tanpa kernel exploit** (lebih stabil) → 3) kernel exploit = pilihan terakhir, catat versi persis dulu.

## 🧰 Tools

- **LinPEAS** — enumerasi privesc paling lengkap (PEASS-ng).
- **pspy** — monitor proses & cron tanpa root (krusial).
- **GTFOBins** — referensi escape SUID/sudo/capability — https://gtfobins.github.io
- **linux-exploit-suggester (LES)** — cocokkan kernel ke exploit.
- **Linux Smart Enumeration (lse.sh)** — alternatif ringkas.

## 🔗 Kaitan

- Dasar: [[Privilege Escalation]]; lanjut setelah root → [[Post-Exploitation & Pivoting]] · [[Pivoting & Tunneling Lanjutan]].
- Di dalam container: [[Container & Kubernetes Offense]]; biner SUID kustom: [[Reverse Engineering untuk Offense]].
- Padanan Windows: [[Windows Privilege Escalation Lanjutan]].
- **Sisi Blue ↔** [[Hardening & Vulnerability Management]] (patch kernel, hapus SUID berlebih, `nosuid`/`noexec` mount, least-priv sudo), [[Threat Hunting]] & [[Endpoint Security & EDR]] (deteksi pkexec/dirtypipe).

## 🎯 Latihan

- **TryHackMe — "Linux PrivEsc" (Tib3rius)**, **"Linux PrivEsc Arena"**, **"Common Linux Privesc"**.
- **pwnkit / dirtypipe** di VM lab dengan kernel sengaja lama.
- **HTB** box Linux medium yang memakai capability/cron/NFS.

## 📖 Sumber

- **GTFOBins** — https://gtfobins.github.io
- **HackTricks — Linux Privilege Escalation** — https://book.hacktricks.xyz/linux-hardening/privilege-escalation
- **PayloadsAllTheThings — Linux PrivEsc** — https://github.com/swisskyrepo/PayloadsAllTheThings
- **Exploit-DB** untuk CVE kernel/sudo.
