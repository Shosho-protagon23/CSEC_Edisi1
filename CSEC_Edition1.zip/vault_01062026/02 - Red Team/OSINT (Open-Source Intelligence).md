# 🕵️ OSINT (Open-Source Intelligence)

> [!summary] Ringkasan
> **OSINT** adalah seni mengumpulkan & menganalisis informasi dari **sumber yang terbuka untuk umum** (web, media sosial, dokumen publik, data DNS, foto) — tanpa membobol apa pun. Karena tidak menyentuh target secara langsung, OSINT umumnya **legal & tak terdeteksi**. Dipakai red team untuk recon, blue team untuk mengukur jejak organisasinya, dan purple team untuk menutup celah keduanya.

**Bagian dari:** [[Red Team (MOC)]] · pendalaman dari [[Reconnaissance (Information Gathering)]]
**Lihat juga sisi defensif:** [[Threat Intelligence]]

---

## 🧠 Konsep Inti

### OSINT = bagian dari Passive Recon
OSINT adalah inti dari **passive reconnaissance**: kita mengumpulkan info dari pihak ketiga (Google, DNS publik, media sosial), bukan dari target langsung. Bandingkan dengan active recon di [[Scanning & Enumeration]] yang mengetuk pintu target dan bisa terekam log.

### Siklus OSINT (5 langkah)
1. **Planning** — tentukan tujuan & batasan (apa yang dicari, sampai mana boleh).
2. **Collection** — kumpulkan data mentah dari banyak sumber.
3. **Processing** — bersihkan & rapikan (hapus duplikat, normalisasi).
4. **Analysis** — ubah data jadi informasi yang berguna (pola, hubungan).
5. **Reporting** — sajikan temuan → masuk ke [[Reporting & Sertifikasi (OSCP-dll)]].

### Kategori target OSINT
- **Domain & infrastruktur** — subdomain, IP, MX/NS record, sertifikat TLS, teknologi web.
- **People (manusia)** — nama karyawan, jabatan, email, nomor HP → bahan [[Password Attacks|phishing & password spraying]]. Pendalaman mencari individu spesifik: [[OSINT Investigasi Individu (People OSINT)]].
- **Social media** — LinkedIn (struktur organisasi), Twitter/X, Instagram, GitHub.
- **Dokumen & metadata** — PDF/DOCX bocor berisi username, path internal, versi software (lihat tool *exiftool*, *FOCA*).
- **Geolocation** — lokasi dari foto (EXIF), latar belakang gambar, Google Street View.
- **Breach data** — kredensial bocor dari kebocoran lama.

### OPSEC saat ber-OSINT
> [!warning] Jaga jejakmu sendiri
> Walau "pasif", sebagian aktivitas bisa bocor ke target (mis. kunjungan ke website mereka, koneksi LinkedIn). Gunakan **akun sock-puppet** (akun palsu terpisah), VPN, dan browser bersih saat melakukan investigasi serius.

## ⚙️ Praktik

```bash
# --- Domain & DNS ---
whois example.com
dig example.com ANY
dig +short txt example.com                 # SPF/DMARC sering bocorkan vendor
nslookup -type=mx example.com

# --- Subdomain & sertifikat ---
theHarvester -d example.com -b all          # email, subdomain, host
sublist3r -d example.com
amass enum -passive -d example.com          # subdomain dari banyak sumber
#   crt.sh (browser): https://crt.sh/?q=example.com   <- sertifikat TLS

# --- Metadata file ---
exiftool foto.jpg                           # lihat GPS, perangkat, software

# --- Google Dorking (di browser) ---
#   site:example.com filetype:pdf
#   site:example.com intitle:"index of"
#   "@example.com" site:linkedin.com
#   site:github.com "example.com" password
```

## 🧰 Tools

| Tool | Untuk apa |
|---|---|
| **theHarvester** | Email, subdomain, host dari sumber publik |
| **Maltego** | Visualisasi hubungan antar-entitas (graph OSINT) |
| **Shodan** (https://shodan.io) | "Google" perangkat & layanan terhubung internet |
| **Censys** | Mirip Shodan; scan sertifikat & host |
| **Amass / Sublist3r** | Enumerasi subdomain |
| **Google Dorks** | Query pencarian canggih untuk info bocor |
| **Have I Been Pwned** (https://haveibeenpwned.com) | Cek email di data breach |
| **exiftool** | Baca metadata foto/dokumen (GPS, author) |
| **Sherlock** | Cari username di ratusan situs sekaligus |
| **SpiderFoot** | Otomasi OSINT all-in-one (domain→people→breach) |
| **Recon-ng** | Framework recon modular (mirip Metasploit utk OSINT) |
| **Wappalyzer** | Deteksi teknologi sebuah website |

## 🔵 OSINT untuk Blue Team (defensif)

Blue team membalik sudut pandang: **"apa yang penyerang lihat tentang kita?"** lalu menguranginya.

- **Footprint reduction** — audit data publik organisasi (subdomain lama, repo GitHub bocor, dokumen ber-metadata) lalu hapus/sembunyikan. Ini bagian dari [[Hardening & Vulnerability Management]].
- **Defensive monitoring** — pantau breach (Have I Been Pwned domain monitoring), typosquatting domain, dan kebocoran kredensial → makanan untuk [[SOC & SIEM]].
- **CTI feeding** — teknik & sumber OSINT yang sama dipakai untuk membangun [[Threat Intelligence]] tentang penyerang (profil APT, IOC publik).

## 🟣 OSINT untuk Purple Team (kolaborasi)

- **Red** menjalankan OSINT terhadap organisasi (subdomain, email, repo bocor) dan melaporkan apa yang ditemukan.
- **Blue** memverifikasi: apakah aset/data itu memang seharusnya publik? Apakah ada deteksi saat domain/akun mereka di-scrape?
- **Loop perbaikan**: data sensitif yang terekspos → ditutup; kemampuan deteksi recon → ditingkatkan. Persis pola di [[Purple Team]].
- Petakan teknik OSINT ke taktik **Reconnaissance** di [[Cyber Kill Chain & MITRE ATT&CK]] (mis. `T1595` Active Scanning, `T1593` Search Open Websites/Domains) untuk mengukur *coverage*.

## 🔗 Kaitan

- Pendalaman langsung dari [[Reconnaissance (Information Gathering)]] (fase 1 pentest).
- **Fokus mencari individu spesifik:** [[OSINT Investigasi Individu (People OSINT)]] (pivot username/email/HP/foto).
- Hasil OSINT (email, nama) → bahan [[Password Attacks]] & [[Social Engineering]].
- Hasil OSINT (subdomain, IP) → input untuk [[Scanning & Enumeration]].
- Sisi Blue: [[Threat Intelligence]] (CTI dibangun dengan teknik OSINT) & [[Hardening & Vulnerability Management]] (kurangi footprint).
- Pertemuan Red↔Blue: [[Purple Team]].

## 🎯 Latihan

- **TryHackMe — "OSINT"**, **"Google Dorking"**, **"Sakura Room"** (OSINT terapan).
- **OSINT Dojo / TraceLabs CTF** — latihan OSINT terstruktur.
- Lakukan OSINT pada **domain & dirimu sendiri** — lihat seberapa banyak yang terekspos, lalu praktikkan footprint reduction.

## 📖 Sumber

- **OSINT Framework** — https://osintframework.com (peta tool OSINT).
- **OSINT Techniques (Michael Bazzell)** — referensi klasik OSINT.
- **TryHackMe — "Red Team Recon"** & **OSINT path**.
- **MITRE ATT&CK — Reconnaissance tactic** — https://attack.mitre.org/tactics/TA0043/
