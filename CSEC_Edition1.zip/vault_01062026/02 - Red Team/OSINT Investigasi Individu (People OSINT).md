# 🧑‍💻🔎 OSINT Investigasi Individu (People OSINT)

> [!summary] Ringkasan
> Pendalaman dari [[OSINT (Open-Source Intelligence)]] yang berfokus pada **mencari & memprofilkan seseorang secara spesifik** — disebut **People OSINT** / *person of interest investigation*. Metodologinya: mulai dari satu **pivot point** (nama, username, email, foto, atau nomor HP) lalu memperluas ke identitas lain yang saling terhubung sampai terbentuk profil. Dipakai sah untuk: **social engineering pentest** (profil target phishing), **investigasi orang hilang** (TraceLabs), **due diligence/fraud**, **verifikasi identitas**, dan **threat intelligence** (profil aktor ancaman).

**Bagian dari:** [[Red Team (MOC)]] · pendalaman dari [[OSINT (Open-Source Intelligence)]]
**Mengarah ke:** [[Social Engineering]], [[Password Attacks]]

> [!danger] Etika & hukum — BACA DULU
> People OSINT berbatasan tipis dengan **stalking, doxxing, dan pelanggaran privasi**. Pisahkan tegas:
> - ✅ **Sah:** target dalam scope engagement berizin tertulis, investigasi orang hilang (TraceLabs), riset keamanan diri sendiri, CTI aktor ancaman.
> - ❌ **Tidak sah:** memprofil orang pribadi tanpa izin, mempublikasikan data pribadi (doxxing), pelecehan, mengintai.
>
> Pertimbangkan **GDPR/UU PDP** (data pribadi), batasi pada **kebutuhan engagement**, dan **jangan simpan** data lebih dari perlu. Selalu pakai **OPSEC sock-puppet** (lihat [[OSINT (Open-Source Intelligence)]]).

---

## 🧠 Konsep Inti

### Pivot point → ekspansi
Investigasi individu dimulai dari **satu titik yang diketahui**, lalu memutar (*pivot*) ke identitas terkait:
```
            ┌─→ username  ─→ akun di situs lain (Sherlock/Maigret)
   NAMA ────┼─→ email     ─→ breach data, akun terdaftar, Gravatar
            ├─→ nomor HP   ─→ operator, akun WhatsApp/Telegram, registrasi
            ├─→ foto/wajah ─→ reverse image, geolocation latar
            └─→ lokasi     ─→ tempat kerja, kebiasaan, jejak fisik
```
Tiap temuan baru jadi **pivot point berikutnya** — investigasi adalah graph yang tumbuh (kelola dengan **Maltego**).

### Lima vektor utama
| Vektor | Yang dicari | Contoh tools |
|---|---|---|
| **Username** | jejak akun lintas platform (orang sering pakai handle sama) | **Sherlock, Maigret, WhatsMyName** |
| **Email** | breach, akun terdaftar, Gravatar, validitas | **Holehe, HaveIBeenPwned, hunter.io** |
| **Nomor HP** | operator, nama terdaftar, akun messenger | **PhoneInfoga, truecaller (hati-hati)** |
| **Nama asli** | media sosial, dokumen publik, catatan profesional | LinkedIn, Google dorks, public records |
| **Foto/wajah** | akun lain, lokasi, konteks | **reverse image search**, PimEyes |

### Sumber kaya untuk profil orang
- **Media sosial** — LinkedIn (karier, rekan kerja → struktur organisasi), Instagram/X/Facebook, TikTok.
- **Kode & teknis** — GitHub (email di commit `git log`, proyek, jam aktif → zona waktu), Stack Overflow.
- **Breach data** — email/username di kebocoran → password lama (pola), situs terdaftar.
- **Public records** — pendaftaran bisnis, court records, izin profesional (bervariasi per yurisdiksi).
- **Konten yang diunggah** — foto (EXIF/latar untuk geolocation), dokumen ber-metadata.

### Membangun profil terstruktur
Kumpulkan ke kerangka konsisten: identitas (nama/alias/DOB), kontak (email/HP), online (akun/handle), pekerjaan, lokasi/pola, relasi (keluarga/rekan), dan **tingkat keyakinan** tiap temuan (confirmed vs probable — hindari kesimpulan salah).

---

## ⚙️ Cara Kerja / Praktik

> Selalu dalam scope sah. Contoh memakai data uji / diri sendiri.

### 1. Pivot dari username
```bash
sherlock johndoe                      # cari "johndoe" di ratusan situs
maigret johndoe                       # alternatif, lebih banyak situs + laporan HTML
# manual: cek pola handle di Google → "johndoe" site:reddit.com
```

### 2. Pivot dari email
```bash
holehe target@example.com             # situs mana yang punya akun email ini
# HaveIBeenPwned (browser) → breach mana yang memuat email
# Gravatar: https://gravatar.com/<md5(email)> → foto & profil terkait
python3 -c "import hashlib;print(hashlib.md5(b'target@example.com').hexdigest())"
```

### 3. Pivot dari nomor HP
```bash
phoneinfoga scan -n "+628123456789"   # operator, region, footprint, dork links
```

### 4. Pivot dari foto / wajah
```text
# Reverse image search (browser):
#   Google Lens · Yandex Images (kuat utk wajah) · TinEye · Bing Visual
# Geolocation latar: bandingkan landmark, plang, bahasa, vegetasi
#   → bantu dengan Google Maps/Earth, GeoGuessr-style reasoning
```

### 5. Pivot dari GitHub (teknis)
```bash
# email penyumbang sering bocor di history commit:
git clone https://github.com/user/repo && cd repo
git log --pretty="%an <%ae>" | sort -u    # nama & email kontributor
# jam commit → perkiraan zona waktu/kebiasaan
```

### 6. Kelola sebagai graph
Masukkan tiap entitas (nama, email, akun, foto) ke **Maltego** atau **SpiderFoot**; jalankan transform untuk otomatis menautkan & memperluas. Catat **sumber + tanggal + keyakinan** tiap node.

> [!tip] Verifikasi silang, jangan asal tarik kesimpulan
> Nama/username yang sama **belum tentu orang yang sama**. Konfirmasi minimal **dua sumber independen** sebelum menandai temuan "confirmed". Salah-identifikasi orang bisa berbahaya & merusak kredibilitas laporan.

---

## 🛡️ Sisi defensif (lindungi diri / personil organisasi)

Membalik perspektif — kurangi *attack surface* individu (penting untuk eksekutif/personil sensitif):
- **Audit jejak diri** — jalankan Sherlock/Holehe pada diri sendiri; lihat apa yang terekspos.
- **Kurangi reuse handle/email** antar layanan (mempersulit pivot).
- **Privasi media sosial** — batasi info publik, scrub EXIF foto sebelum unggah, hapus akun lama.
- **Breach hygiene** — pantau HIBP, ganti password yang bocor, pakai email alias.
- **VIP/executive protection** — program khusus mengurangi footprint pejabat (target *whaling*). Bagian [[Hardening & Vulnerability Management]] & kesadaran di [[Social Engineering]].

## 🧰 Tools

- **Sherlock / Maigret / WhatsMyName** — pencarian username lintas situs.
- **Holehe** — email → akun terdaftar. **hunter.io** — email perusahaan.
- **PhoneInfoga** — investigasi nomor HP.
- **Maltego / SpiderFoot** — graph & otomasi (lihat [[OSINT (Open-Source Intelligence)]]).
- **Reverse image:** Yandex, Google Lens, TinEye, PimEyes (wajah — etika!).
- **exiftool** — metadata/EXIF foto. **HaveIBeenPwned** — breach.
- **OSINT Industries / IntelTechniques tools** — agregator lookup.

## 🔗 Kaitan

- Dasar & metodologi umum: [[OSINT (Open-Source Intelligence)]] (siklus 5 langkah, OPSEC sock-puppet).
- **Output langsung:** profil → [[Social Engineering]] (pretext/spear-phishing yang meyakinkan) & [[Password Attacks]] (wordlist personal, password spraying dari pola).
- Memetakan ke taktik *Reconnaissance* (`T1589` Gather Victim Identity Info) di [[Cyber Kill Chain & MITRE ATT&CK]].
- **Sisi Blue ↔** [[Threat Intelligence]] (profil aktor ancaman pakai teknik sama), footprint reduction di [[Hardening & Vulnerability Management]]; loop perbaikan [[Purple Team]].

## 🎯 Latihan

- **TraceLabs Search Party CTF** — OSINT mencari **orang hilang** (etis, terstruktur, real impact).
- **TryHackMe — "OSINT" / "Sakura Room"** — investigasi individu dari pivot point.
- Investigasi **dirimu sendiri**: mulai dari satu username/email, lihat seberapa jauh profil bisa dibangun → lalu lakukan footprint reduction.

## 📖 Sumber

- **OSINT Techniques (Michael Bazzell)** & **IntelTechniques.com** — rujukan utama people OSINT + workbook.
- **TraceLabs OSINT VM & Search Party** — https://www.tracelabs.org
- **OSINT Framework — "Username/Email/People"** — https://osintframework.com
- **Bellingcat's Online Investigation Toolkit** — teknik investigasi (geolocation, verifikasi).
