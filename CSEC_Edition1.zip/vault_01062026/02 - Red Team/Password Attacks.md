# 🔓 Password Attacks

> [!summary] Ringkasan
> Kredensial (username + password) adalah kunci paling diincar. Catatan ini membahas cara memperoleh & memecahkan password — dari brute-force online sampai cracking hash offline.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Kriptografi Dasar]] (paham hashing)

---

## 🧠 Konsep Inti

### Online vs Offline
- **Online attack** — coba login berulang ke layanan langsung (lambat, berisik, kena lockout). Mis. brute-force SSH/RDP.
- **Offline attack** — sudah punya **hash** password (dari database bocor / dump memori), pecahkan di mesin sendiri tanpa terdeteksi (cepat, senyap).

### Jenis serangan
- **Brute-force** — coba semua kombinasi (lambat untuk password panjang).
- **Dictionary attack** — coba dari daftar kata umum (wordlist).
- **Password spraying** — satu password umum dicoba ke banyak akun (hindari lockout).
- **Credential stuffing** — pakai kombinasi user/pass dari breach lain.
- **Pass-the-Hash** — di Windows, hash NTLM bisa dipakai langsung tanpa tahu password aslinya → [[Active Directory Attacks]].

## ⚙️ Praktik

```bash
# Online: brute-force SSH
hydra -l admin -P rockyou.txt ssh://10.10.10.5

# Offline: crack hash
hashid '$1$...'                                 # identifikasi jenis hash
john --wordlist=rockyou.txt hashes.txt          # John the Ripper
hashcat -m 0 -a 0 hashes.txt rockyou.txt        # hashcat (m 0 = MD5)
```

`rockyou.txt` = wordlist legendaris (sudah ada di Kali di `/usr/share/wordlists/`).

## 🧰 Tools

- **Hydra** — brute-force layanan online (SSH, FTP, HTTP, RDP).
- **John the Ripper** — cracking hash offline serbaguna.
- **hashcat** — cracking hash super cepat (pakai GPU).
- **CeWL** — buat wordlist khusus dari website target.
- **Mimikatz** — mencuri kredensial dari memori Windows → [[Active Directory Attacks]].

## 🔗 Kaitan

- Dasarnya: [[Kriptografi Dasar]] (hashing, salt).
- Sumber hash sering dari [[Web Application Hacking (OWASP Top 10)]] (SQLi dump) atau [[Post-Exploitation & Pivoting]]; juga **WPA2 handshake/PMKID** dari [[Lab — WiFi Hacking (Wireless)]] (crack offline mode hashcat 22000).
- **Sisi Blue ↔** [[Hardening & Vulnerability Management]] (kebijakan password kuat, MFA) & [[Log Analysis & Monitoring]] (deteksi banyak login gagal — Event ID 4625).

## 🎯 Latihan

- **TryHackMe — "Hydra"**, **"John the Ripper: The Basics"**, **"Crack the Hash"**.

## 📖 Sumber

- **Hashcat wiki** — https://hashcat.net/wiki/
- **OWASP — Password Storage Cheat Sheet** — https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
