# ⬆️ Privilege Escalation

> [!summary] Ringkasan
> Setelah dapat akses awal (biasanya sebagai user biasa), tujuannya naik ke **root (Linux)** atau **Administrator/SYSTEM (Windows)** — akses penuh. Tanpa ini, akses kita terbatas; dengan ini, kita menguasai mesin.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Exploitation & Metasploit]], [[Linux Dasar untuk Security]], [[Windows & Active Directory Dasar]]

---

## 🧠 Konsep Inti

Dua arah:
- **Vertical** — dari user rendah → user lebih tinggi (admin).
- **Horizontal** — pindah ke akun lain selevel (untuk akses berbeda).

Prinsip yang dilanggar: **Least Privilege** (lihat [[Konsep Dasar Keamanan (CIA Triad)]]). Privesc ada karena konfigurasi terlalu longgar.

### Vektor umum — Linux
- **SUID binaries** salah konfigurasi.
- **sudo** misconfig (`sudo -l` menunjukkan apa yang bisa dijalankan tanpa password).
- **Cron jobs** yang bisa ditulis ulang.
- **Kernel exploit** (versi kernel lama & rentan).
- Kredensial/file sensitif yang ter-expose.

### Vektor umum — Windows
- **Service** dengan izin lemah / *unquoted service path*.
- **Token impersonation** (Potato attacks).
- **AlwaysInstallElevated** misconfig.
- Kredensial tersimpan di registry/file.

## ⚙️ Praktik

```bash
# --- Linux: enumerasi otomatis ---
./linpeas.sh
sudo -l                              # apa yang bisa dijalankan sebagai root?
find / -perm -4000 2>/dev/null       # cari SUID
# referensi eksploitasi SUID/sudo: https://gtfobins.github.io
```
```powershell
# --- Windows: enumerasi otomatis ---
.\winPEAS.exe
whoami /priv                         # cek privilege spesial
# referensi: https://lolbas-project.github.io
```

## 🧰 Tools

- **LinPEAS / WinPEAS** — script enumerasi privesc otomatis (PEASS-ng).
- **GTFOBins** (Linux) & **LOLBAS** (Windows) — daftar binary sah yang bisa disalahgunakan.
- **PowerUp.ps1** — audit privesc Windows.

## 🔗 Kaitan

- Pendalaman per-OS: [[Linux Privilege Escalation Lanjutan]] (kernel exploit, capabilities, GTFOBins mendalam) & [[Windows Privilege Escalation Lanjutan]] (token/Potato, service misconfig, UAC bypass).
- Lanjut ke [[Post-Exploitation & Pivoting]] setelah jadi admin.
- Di lingkungan korporat, sering menyatu dengan [[Active Directory Attacks]].
- **Sisi Blue ↔** [[Hardening & Vulnerability Management]] — menutup vektor ini (patch, least privilege, audit config) adalah pertahanan langsungnya.

## 🎯 Latihan

- **TryHackMe — "Linux PrivEsc"** & **"Windows PrivEsc"** (oleh Tib3rius — standar emas pemula).
- **Hack The Box** mesin "easy/medium".

## 📖 Sumber

- **GTFOBins** — https://gtfobins.github.io
- **LOLBAS** — https://lolbas-project.github.io
- **PayloadsAllTheThings — PrivEsc** — https://github.com/swisskyrepo/PayloadsAllTheThings
