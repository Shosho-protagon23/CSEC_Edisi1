# 🪪 RFID-NFC & Physical Red Teaming

> [!summary] Ringkasan
> Tidak semua serangan lewat jaringan — **physical red teaming** menguji apakah penyerang bisa **masuk secara fisik** ke gedung lalu menanam akses ke jaringan internal. Inti teknisnya adalah **cloning kartu akses RFID/NFC** (badge pintu), ditambah taktik fisik: *tailgating*, *lock bypass*, dan menanam *drop device*. Note ini pasangan teknis dari [[Social Engineering]] (sisi manusia).

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Social Engineering]], [[Reconnaissance (Information Gathering)]]

---

> [!danger] Etika & hukum — sangat ketat
> Masuk gedung tanpa izin = **pelanggaran pidana** (trespassing/pembobolan), terlepas dari niat. Physical red team **WAJIB** punya **Rules of Engagement** tertulis, surat izin, dan **"get-out-of-jail letter"** yang ditandatangani klien & dibawa fisik. Latih cloning **hanya pada kartu milik sendiri**. Lihat RoE di [[Reporting & Sertifikasi (OSCP-dll)]].

## 🧠 Konsep Inti

### RFID vs NFC — dua frekuensi
| Tipe | Frekuensi | Contoh | Keamanan |
|---|---|---|---|
| **LF (Low Frequency)** | 125 kHz | HID Prox, EM4100, T5577 | hampir **tanpa enkripsi** → clone trivial |
| **HF (High Frequency)** | 13.56 MHz | MIFARE Classic, DESFire, NFC ponsel | bervariasi; **MIFARE Classic** (Crypto-1) sudah pecah, **DESFire EV2/EV3** kuat |

Kunci diagnosis: identifikasi dulu **tipe kartu** sebelum berasumsi bisa di-clone.

### Rantai serangan badge
```text
recon (foto badge karyawan, merk reader di pintu) → tentukan frekuensi/tipe →
baca kartu korban (jarak dekat / long-range reader) → clone ke kartu kosong (T5577 / Magic UID) →
masuk pintu → tanam drop device → akses jaringan internal
```

### Serangan MIFARE Classic
Cipher **Crypto-1** lemah → serangan **nested / darkside / hardnested** memulihkan kunci sektor, lalu dump & tulis ulang ke kartu **"Magic" (UID changeable)**.

### Taktik fisik pendamping
- **Tailgating / piggybacking** — ikut masuk di belakang karyawan (rekayasa sosial fisik).
- **Lock bypass** — *lockpicking*, *shimming*, **under-door tool**, *latch slip* (kartu).
- **Drop device** — tanam perangkat kecil (LAN Turtle, Raspberry Pi, **Plunder Bug**) yang "menelepon pulang" ke C2 → lihat [[C2 Frameworks (Command & Control)]].
- **REID long-range** — reader berdaya tinggi membaca badge dari dalam tas/saku (mis. proyek **Tastic RFID Thief**).

## ⚙️ Praktik

```bash
# --- Proxmark3 (alat utama RFID/NFC) ---
hw version
lf search                         # deteksi & identifikasi kartu LF 125kHz
lf hid read                       # baca HID Prox
lf t55xx write -b 1 -d <data>     # tulis ke kartu kosong T5577 (clone LF)

hf search                         # deteksi kartu HF 13.56MHz
hf mf autopwn                     # serang MIFARE Classic (recover key + dump)
hf mf cload -f dump.bin           # tulis dump ke kartu Magic (clone HF)
```

```text
# --- Flipper Zero (portabel, ramah pemula) ---
#  - menu 125kHz RFID → Read → Save → Emulate  (clone LF tanpa kartu fisik kedua)
#  - menu NFC → Read → emulasi MIFARE
#  - juga: Sub-GHz (remote gerbang), iButton, BadUSB
```

> [!warning] Batasan teknis
> Kartu modern aman (**DESFire EV2/EV3, SEOS, iCLASS SE**) tidak bisa di-clone hanya dengan membaca — pakai kripto kuat + mutual auth. Temuan "kartu bisa di-clone" biasanya pada sistem **legacy LF Prox / MIFARE Classic** yang masih sangat umum.

## 🧰 Tools

- **Proxmark3 (RDV4)** — alat standar industri baca/tulis/serang RFID & NFC.
- **Flipper Zero** — multitool portabel (RFID/NFC/Sub-GHz/BadUSB), bagus untuk demo.
- **Chameleon Mini/Tiny** — emulasi kartu.
- **mfoc / mfcuk / libnfc** (PC + reader ACR122U) — serang MIFARE Classic.
- **Lockpick set, under-door tool, shim** — bypass mekanis (untuk pelatihan sah).

## 🔗 Kaitan

- Sisi manusia & pretext masuk gedung: [[Social Engineering]] (tailgating, impersonation).
- Recon fisik (denah, jam shift, merk reader): [[Reconnaissance (Information Gathering)]] · [[OSINT (Open-Source Intelligence)]].
- Drop device menelepon pulang: [[C2 Frameworks (Command & Control)]] · [[Red Team Infrastructure & OPSEC]].
- Domain perangkat fisik terkait: [[Lab — IoT & Embedded Hacking]] (radio/hardware), [[Lab — Mobile (Android-iOS) Hacking]] (NFC ponsel).
- **Sisi Blue ↔** [[Defense in Depth & Security Architecture]] (kontrol fisik = lapisan terluar), [[Hardening & Vulnerability Management]] (ganti badge kuat, anti-tailgating/mantrap), [[Incident Response]] (intrusi fisik).

## 🎯 Latihan

- Beli **Proxmark3** atau **Flipper Zero**, clone **kartu LF milik sendiri** (T5577), pelajari identifikasi tipe.
- **Lockpicking** legal: latih dengan gembok latihan transparan / progressive lock set.
- Pelajari **physical pentest report** publik (mis. dari TrustedSec/Coalfire) untuk memahami metodologi & RoE.

## 📖 Sumber

- **Proxmark3 wiki / Iceman fork** — https://github.com/RfidResearchGroup/proxmark3
- **Flipper Zero docs** — https://docs.flipper.net
- **TOOOL (The Open Organisation Of Lockpickers)** — etika & teknik lockpicking.
- **Physical Red Team Operations** (Jeremiah Talamantes) — buku metodologi.
- **MITRE ATT&CK — Initial Access: Hardware Additions / Physical**.
