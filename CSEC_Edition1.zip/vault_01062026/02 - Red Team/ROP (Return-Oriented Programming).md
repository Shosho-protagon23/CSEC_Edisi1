# ⛓️ ROP (Return-Oriented Programming)

> [!summary] Ringkasan
> **ROP** adalah teknik eksploitasi lanjutan untuk **melewati proteksi DEP/NX** (stack tak boleh dieksekusi). Karena kita tak bisa lagi menjalankan shellcode di stack, kita **tidak membawa kode baru** — kita merangkai potongan-potongan kode yang **sudah ada** di program/library (disebut **gadget**), masing-masing diakhiri `ret`, menjadi sebuah **ROP chain** yang melakukan apa yang kita mau (biasanya: mematikan DEP lalu loncat ke shellcode, atau langsung memanggil fungsi sistem). Note ini lanjutan dari [[Buffer Overflow (Stack-Based)]].

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Buffer Overflow (Stack-Based)]], [[Exploitation & Metasploit]]

> [!note] Kapan ini relevan
> ROP adalah jawaban atas pertanyaan "kalau stack tidak bisa dieksekusi (DEP/NX aktif), bagaimana BOF masih bisa jalan?". Ini **tingkat lanjut** — pastikan [[Buffer Overflow (Stack-Based)|BOF dasar]] sudah benar-benar paham dulu (kontrol EIP, offset, bad chars).

---

## 🧠 Konsep Inti

### Masalah: DEP/NX mematikan shellcode di stack
Di [[Buffer Overflow (Stack-Based)|BOF klasik]], kita menaruh shellcode di stack lalu `JMP ESP` ke sana. **DEP (Data Execution Prevention) / NX (No-eXecute)** menandai stack sebagai **non-executable** — begitu CPU mencoba mengeksekusi byte di stack, program crash. Shellcode-di-stack mati.

### Ide ROP: pinjam kode yang sudah ada
Kode program & library (`.text`) **memang executable** — DEP tak melarangnya. Jadi alih-alih membawa kode sendiri, kita gunakan kembali instruksi yang sudah ada di sana.

- **Gadget** = urutan pendek instruksi yang **diakhiri `ret`**. Contoh: `pop eax ; ret` atau `mov [edx], eax ; ret`.
- Kenapa harus diakhiri `ret`? Karena `ret` mengambil alamat **berikutnya dari stack** lalu loncat ke sana. Dengan menumpuk banyak alamat gadget di stack, tiap `ret` "memanggil" gadget berikutnya — **stack menjadi program kita**.

### ROP chain = daftar alamat di stack
```
Setelah kita kuasai return address (dari overflow), stack diisi:

[ alamat gadget 1 ]  → jalankan gadget 1, ret ambil entri berikut ↓
[ nilai/argumen   ]  (mis. di-pop oleh gadget 1)
[ alamat gadget 2 ]  → jalankan gadget 2, ret ...
[ alamat gadget 3 ]
[ ...             ]
```
EIP pertama kita arahkan ke gadget 1; sisanya mengalir sendiri lewat rantai `ret`.

### Tujuan umum sebuah ROP chain
Jarang seluruh exploit ditulis sebagai ROP (melelahkan). Pola tersering: **ROP chain pendek untuk menonaktifkan DEP**, lalu loncat ke shellcode biasa. Caranya memanggil fungsi Windows seperti:
- **`VirtualProtect()`** — ubah region memori (tempat shellcode) jadi **executable (RWX)**.
- **`VirtualAlloc()`** — alokasikan memori baru yang executable.
- atau **`WriteProcessMemory`**, dll.

Setelah DEP "dilucuti" untuk region itu, shellcode standar (`msfvenom`) jalan normal.

> [!info] ROP vs ret2libc
> **ret2libc** adalah bentuk paling sederhana dari ide ini: alih-alih merangkai banyak gadget, return address diarahkan langsung ke fungsi library (mis. `system("/bin/sh")` di Linux). ROP adalah generalisasinya — merangkai banyak gadget untuk komputasi sembarang (bahkan **Turing-complete**).

---

## ⚙️ Cara Kerja / Praktik

ROP dipakai **setelah** kamu sudah punya kontrol EIP dari overflow (lihat [[Buffer Overflow (Stack-Based)]] langkah 1–4). Langkah lanjutan:

### 1. Pastikan target memang pakai DEP
Kalau shellcode-di-stack tiba-tiba gagal padahal EIP & alamat benar → curigai DEP. Itu sinyal beralih ke ROP.

### 2. Temukan gadget di modul tanpa ASLR
Cari gadget di DLL/EXE yang **base address-nya tetap** (non-ASLR), agar alamat gadget bisa di-hardcode.
```text
# Immunity Debugger + mona.py — cari modul aman dulu:
!mona modules                       # pilih modul tanpa ASLR/Rebase
# generate ROP chain otomatis untuk bypass DEP:
!mona rop -m "namamodul.dll" -cpb "\x00\x0a\x0d"
```
`mona rop` menghasilkan file `rop_chains.txt` berisi chain siap pakai (Python/Ruby) untuk `VirtualProtect` / `VirtualAlloc` — termasuk gadget yang ditemukan.

### 3. Cari gadget manual (alternatif / Linux)
```bash
# ROPgadget — daftar semua gadget di sebuah binari
ROPgadget --binary ./vuln | grep ": pop"
# Ropper — pencari gadget + chain builder
ropper --file ./vuln --search "pop rdi"
```

### 4. Susun chain (contoh kerangka VirtualProtect, mona format)
```python
# rop_chain dari mona biasanya berbentuk fungsi create_rop_chain()
# strukturnya kira-kira:
rop  = pack("<I", 0x...)   # pop eax ; ret      → siapkan argumen
rop += pack("<I", 0x...)   # ptr ke VirtualProtect (IAT)
rop += pack("<I", 0x...)   # gadget berikutnya ...
# ... isi 5 argumen VirtualProtect: lpAddress, dwSize, flNewProtect=0x40 (RWX), lpflOldProtect
```
Payload akhir:
```python
#        [ junk ke EIP ] [ ROP chain (lucuti DEP) ] [ NOP ] [ shellcode ]
payload = b"A"*offset   + rop_chain                + b"\x90"*16 + shellcode
```

### 5. Eksekusi
Listener `nc -lvnp 4444` → kirim payload → ROP chain mengubah region jadi executable → eksekusi jatuh ke NOP sled → shellcode → **shell**.

> [!tip] Pakai mona dulu, paham manual kemudian
> `!mona rop` akan membuatkan chain otomatis 90% kasus — gunakan untuk berhasil dulu. Lalu **bedah** `rop_chains.txt` gadget-per-gadget agar paham kenapa ia bekerja. Itu cara belajar ROP yang efisien.

---

## 🛡️ Sisi pertahanan & batas ROP

ROP melewati DEP, tapi proteksi lain mempersulitnya:

| Proteksi | Efek terhadap ROP |
|---|---|
| **ASLR** | Alamat gadget jadi acak → butuh **info leak** dulu untuk bocorkan base modul (mis. lewat [[Format String Exploitation]]) |
| **CFG / CET (shadow stack)** | Memvalidasi target `ret`/`call` → memutus rantai gadget; mitigasi modern terkuat |
| **Stack canary** | Tetap harus dilewati untuk sampai ke return address |

Karena itu exploit nyata modern sering = **info leak (bocorkan alamat) → ROP → shellcode**, dirangkai bertahap.

## 🧰 Tools

- **mona.py** (`!mona rop`, `!mona jmp`) — generator ROP chain di Immunity Debugger (Windows).
- **ROPgadget** — daftar gadget dari binari (Linux/CLI).
- **Ropper** — pencari gadget + pembangun chain semi-otomatis.
- **pwntools** (Python) — `ROP()` object untuk menyusun chain secara terprogram (CTF/Linux).
- **GDB + GEF/pwndbg** — debug & inspeksi chain saat berjalan.

## 🔗 Kaitan

- Lanjutan langsung dari [[Buffer Overflow (Stack-Based)]] — ROP = jawaban saat tabel proteksi di sana menampilkan **DEP/NX**.
- Konsep payload & shellcode: [[Exploitation & Metasploit]].
- Setelah dapat shell → [[Privilege Escalation]] → [[Post-Exploitation & Pivoting]].
- **Sisi Blue ↔** mitigasi (DEP/ASLR/CET/CFG) ada di ranah [[Hardening & Vulnerability Management]]; eksploitasi memori terdeteksi oleh [[Endpoint Security & EDR]].
- Latihan mesin: [[Lab — Brainpan (Setup)]] (BOF dasar dulu; ROP biasanya di target ber-DEP).

## 🎯 Latihan

- Di lab, aktifkan **DEP** pada aplikasi rentan lalu ulangi exploit BOF-mu — amati ia gagal — lalu perbaiki dengan **`!mona rop`**.
- Bedah `rop_chains.txt` hasil mona: tandai tiap gadget (`pop`, `mov`, ptr `VirtualProtect`) & jelaskan fungsinya dengan kata-katamu sendiri.
- **CTF ROP dasar** (mis. ROP Emporium — https://ropemporium.com) — 8 tantangan bertingkat dari `ret2win` sampai chain penuh.

## 📖 Sumber

- **ROP Emporium** (latihan bertahap, multi-arsitektur) — https://ropemporium.com
- **Corelan — Exploit writing tutorial part 10: ROP** — https://www.corelan.be/index.php/2010/06/16/exploit-writing-tutorial-part-10-chaining-dep-with-rop-the-rubikstm-cube/
- **"Return-Oriented Programming: Systems, Languages, and Applications"** (Roemer dkk.) — makalah akademik dasar.
- **pwntools docs — ROP** — https://docs.pwntools.com/en/stable/rop/rop.html
