# 🔍 Reconnaissance (Information Gathering)

> [!summary] Ringkasan
> Tahap pertama serangan: mengumpulkan informasi sebanyak mungkin tentang target sebelum menyentuhnya. Semakin banyak info, semakin besar peluang menemukan jalan masuk. "Recon" yang baik adalah 80% dari pekerjaan.

**Bagian dari:** [[Red Team (MOC)]]
**Tahap berikutnya:** [[Scanning & Enumeration]]

---

## 🧠 Konsep Inti

### Passive vs Active Recon
- **Passive** — tanpa menyentuh target langsung; pakai sumber publik (tidak terdeteksi target). Disebut juga **OSINT** (Open-Source Intelligence) → pendalaman di [[OSINT (Open-Source Intelligence)]].
- **Active** — berinteraksi langsung dengan sistem target (bisa terdeteksi & terekam log → lihat sisi blue di [[Log Analysis & Monitoring]]).

### Apa yang dicari?
- Domain & subdomain, alamat IP, teknologi yang dipakai.
- Email & nama karyawan (untuk phishing/social engineering).
- Bocoran kredensial di data breach lama.
- File metadata, repo kode publik yang tak sengaja bocor.

## ⚙️ Praktik

```bash
whois example.com                 # info pemilik domain
nslookup example.com              # / dig example.com — info DNS
dig example.com ANY
theHarvester -d example.com -b all   # kumpulkan email/subdomain
sublist3r -d example.com          # cari subdomain
# Google Dorking (di browser):
#   site:example.com filetype:pdf
#   intitle:"index of" site:example.com
```

## 🧰 Tools

- **theHarvester** — email, subdomain, host dari sumber publik.
- **Maltego** — visualisasi hubungan OSINT.
- **Shodan** (https://shodan.io) — "Google untuk perangkat terhubung internet".
- **Google Dorks** — query pencarian canggih untuk menemukan info bocor.
- **Have I Been Pwned** (https://haveibeenpwned.com) — cek email di data breach.
- **Wappalyzer** — deteksi teknologi sebuah website.

## 🔗 Kaitan

- Fase 1 di [[Cyber Kill Chain & MITRE ATT&CK]] (taktik *Reconnaissance*).
- Hasil recon dipakai di [[Scanning & Enumeration]].
- Sisi Blue: organisasi mengurangi jejak ini lewat [[Threat Intelligence]] & [[Hardening & Vulnerability Management]].

## 🎯 Latihan

- **TryHackMe — "Passive Reconnaissance"** & **"OSINT"** rooms.
- Lakukan OSINT pada domain milikmu sendiri — lihat seberapa banyak yang terekspos. Teknik lengkapnya: [[OSINT (Open-Source Intelligence)]].

## 📖 Sumber

- **OSINT Framework** — https://osintframework.com (peta tool OSINT).
- **TryHackMe — "Red Team Recon"**.
