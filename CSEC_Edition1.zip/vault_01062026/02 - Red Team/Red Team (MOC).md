# 🔴 Red Team (MOC)

> [!summary] Ringkasan
> Jalur **offensive**: berpikir & bertindak seperti penyerang untuk menemukan celah sebelum penjahat melakukannya. Output-nya adalah laporan yang membantu organisasi memperbaiki pertahanan.

⬅️ Kembali ke [[00 - START HERE]] · Sisi lawan: [[Blue Team (MOC)]]

> [!warning] Etika
> Semua di sini hanya untuk pengujian yang **diizinkan**. Latih di [[Setup Lab (Virtualisasi)]] atau platform legal. Tanpa izin = melanggar hukum.

---

## 🎯 Prasyarat

Selesaikan dulu [[Fondasi (MOC)]] — terutama [[Jaringan Komputer]], [[Linux Dasar untuk Security]], dan [[Windows & Active Directory Dasar]].

## 🗺️ Urutan Belajar (mengikuti alur serangan nyata)

Alur ini mengikuti tahapan penyerang. Peta resminya ada di:

0. [[Cyber Kill Chain & MITRE ATT&CK]] — kerangka tahapan serangan.

Lalu, sesuai urutan sebuah pentest:

1. [[Reconnaissance (Information Gathering)]] — kumpulkan info target. Pendalaman pasif: [[OSINT (Open-Source Intelligence)]].
2. [[Scanning & Enumeration]] — petakan port, layanan, & celah.
3. [[Vulnerability Assessment]] — identifikasi & nilai kerentanan.
4. [[Web Application Hacking (OWASP Top 10)]] — serang aplikasi web (target tersering). Lanjutan server-side modern: [[Web Exploitation Lanjutan]] (SSRF, deserialization, SSTI, XXE, JWT).
4b. [[Web Application Hacking (OWASP Top 10)]] juga punya sisi **client-side**: [[Client-Side Attacks]] (XSS lanjutan/DOM, CSRF, CORS, postMessage, clickjacking) dan sisi **API**: [[API Hacking (REST-GraphQL)]] (BOLA/BFLA, GraphQL).
5. [[Exploitation & Metasploit]] — manfaatkan celah untuk dapat akses awal. Pendalaman level memori: [[Buffer Overflow (Stack-Based)]] → [[ROP (Return-Oriented Programming)]] (bypass DEP/NX) → [[Format String Exploitation]] (read/write primitive & info leak) → [[Heap Exploitation]] (allocator/`malloc`, paling dalam). Keterampilan dasar di baliknya: [[Reverse Engineering untuk Offense]].
6. [[Password Attacks]] — pecahkan & curi kredensial.
7. [[Privilege Escalation]] — naikkan hak dari user biasa ke admin/root. Pendalaman per-OS: [[Linux Privilege Escalation Lanjutan]] (kernel exploit, capabilities, GTFOBins) & [[Windows Privilege Escalation Lanjutan]] (Potato/token, service misconfig, UAC bypass).
8. [[Post-Exploitation & Pivoting]] — pertahankan akses & melompat ke mesin lain. Pendalaman jembatan jaringan: [[Pivoting & Tunneling Lanjutan]] (SOCKS, chisel, ligolo-ng, double pivot).
9. [[Active Directory Attacks]] — kuasai jaringan korporat Windows. Jalur eskalasi modern: [[Active Directory Attacks Lanjutan]] (ACL abuse, delegation/RBCD, AD CS, coercion+relay).
10. [[Reporting & Sertifikasi (OSCP-dll)]] — tulis laporan & jenjang karier.

> Teknik lintas-fase: [[Social Engineering]] — menyerang manusia (phishing dll), sering jadi jalan *Initial Access* yang memanfaatkan hasil recon/OSINT.
>
> Environment target khusus: [[Cloud Security (AWS-Azure-GCP)]] — pentesting infrastruktur awan (IAM, metadata, misconfig), sejajar dengan AD tapi untuk cloud.
>
> Jalur *Initial Access* nirkabel: [[Lab — WiFi Hacking (Wireless)]] — masuk lewat WiFi (capture/crack WPA2, evil twin) lalu lanjut ke Scanning & Post-Exploitation.
>
> Target embedded: [[Lab — IoT & Embedded Hacking]] — serang perangkat IoT (firmware, UART/JTAG, radio BLE/RF, protokol MQTT) → sering jadi pijakan ke jaringan internal.
>
> Domain industri: [[Lab — OT-ICS-SCADA Hacking]] — serang PLC/SCADA (Modbus/S7 tanpa auth) di simulator; gunakan **MITRE ATT&CK for ICS** (matriks terpisah). ⚠️ prioritas keselamatan fisik.
>
> Domain aplikasi mobile: [[Lab — Mobile (Android-iOS) Hacking]] — uji APK/IPA (storage, intercept API, Frida bypass pinning/root) berbingkai OWASP MASVS; sejajar dengan web & cloud.
>
> Domain cloud-native: [[Container & Kubernetes Offense]] — container escape & ambil alih cluster K8s → pijakan ke kredensial cloud (pendalaman [[Cloud Security (AWS-Azure-GCP)]]).
>
> Domain perangkat fisik & akses: [[RFID-NFC & Physical Red Teaming]] (clone badge, masuk gedung, drop device) & [[Automotive (CAN Bus) Hacking]] (ECU/CAN bus tanpa auth, simulator).

## 🛠️ Tradecraft & Operasi Lanjutan (Evasion)

Saat target punya pertahanan (EDR/SOC), red team modern memakai *tradecraft* agar tidak ketahuan:

- [[Payload Development & Initial Access]] — bikin & antar payload (maldoc/LNK/HTML smuggling, MOTW bypass).
- [[AV-EDR Evasion & AV Bypass]] — lolos antivirus/EDR (AMSI/ETW patch, unhooking, syscalls, injection).
- [[C2 Frameworks (Command & Control)]] — kendali jarak jauh tersembunyi (beacon/sleep/jitter, Sliver/CS/Mythic/Havoc).
- [[Red Team Infrastructure & OPSEC]] — bangun redirector/team server & jaga OPSEC operator.

## 🔗 Hubungan dengan Blue Team

Setiap teknik serangan punya pasangan pertahanan. Saat belajar, lihat juga sisi "cara menangkapnya":

| Red (serang) | ↔ | Blue (tangkis/deteksi) |
|---|---|---|
| [[Scanning & Enumeration]] | ↔ | [[Network Security (Firewall, IDS-IPS)]] |
| [[Web Application Hacking (OWASP Top 10)]] | ↔ | [[Log Analysis & Monitoring]] |
| [[Exploitation & Metasploit]] | ↔ | [[Endpoint Security & EDR]] |
| [[Privilege Escalation]] | ↔ | [[Hardening & Vulnerability Management]] |
| [[Post-Exploitation & Pivoting]] | ↔ | [[Incident Response]] / [[Threat Hunting]] |

Pertemuan keduanya: [[Purple Team]].

## 📖 Sumber utama jalur ini

- **TryHackMe — "Jr Penetration Tester" & "Offensive Pentesting" paths**.
- **Hack The Box Academy** — https://academy.hackthebox.com
- **PortSwigger Web Security Academy** (gratis) — https://portswigger.net/web-security
