# 🏗️ Red Team Infrastructure & OPSEC

> [!summary] Ringkasan
> Operasi red team yang serius butuh **infrastruktur** yang tahan-banting & **OPSEC** (operational security) agar tidak mudah dilacak/diblokir oleh Blue. Note ini membahas **redirector** (menyembunyikan server C2 asli), **domain fronting/CDN & domain categorization**, pemisahan infrastruktur per-fungsi (phishing vs C2 vs payload), serta disiplin OPSEC (artefak, atribusi, waktu operasi). Ini lapisan yang membuat [[C2 Frameworks (Command & Control)|C2]] & [[Payload Development & Initial Access|delivery]] tetap hidup saat sebagian terbongkar.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[C2 Frameworks (Command & Control)]], [[Jaringan Komputer]]

---

> [!danger] Berizin & dalam scope
> Infrastruktur menyerang hanya untuk engagement berizin. Domain & server yang dipakai harus jelas milik tim/klien dan dibersihkan setelah operasi. Lihat [[Reporting & Sertifikasi (OSCP-dll)]] untuk dokumentasi & rules of engagement.

## 🧠 Konsep Inti

### Kenapa butuh infrastruktur berlapis
Jika agent korban langsung konek ke server C2-mu, sekali IP itu terdeteksi → seluruh operasi mati & terungkap. Solusi: **lapisan perantara** yang bisa "dibuang" tanpa mengorbankan server inti.

```text
[Korban] → [Redirector (murah, sekali pakai)] → [Team Server C2 (tersembunyi)]
              ↑ inilah yang dilihat & diblokir Blue
```

### Komponen
| Komponen | Fungsi |
|---|---|
| **Redirector** | proxy (socat/Apache mod_rewrite/nginx) meneruskan trafik beacon ke C2; menyaring non-beacon |
| **Team server** | server C2 inti, hanya bicara ke redirector |
| **Payload/staging host** | menyajikan payload (terpisah dari C2) |
| **Phishing infra** | domain & mail server untuk delivery (terpisah lagi) |
| **DNS** | domain dengan reputasi/kategori bersih |

> **Pemisahan fungsi**: phishing, payload, dan C2 di **infrastruktur berbeda** → satu terbakar, lainnya selamat.

### Teknik penyamaran trafik
- **Domain fronting / CDN** — trafik tampak menuju domain besar tepercaya (cloud/CDN), padahal diteruskan ke C2 (makin dibatasi provider, tapi konsep penting).
- **Domain categorization & aging** — beli/pakai domain yang sudah dikategorikan "bisnis/finance" agar lolos proxy filter.
- **Redirector rules** — hanya teruskan request yang cocok **Malleable profile** ([[C2 Frameworks (Command & Control)]]); selain itu redirect ke situs sah (decoy).
- **TLS sah** (Let's Encrypt) + **JA3/JARM** yang tidak default (hindari fingerprint Cobalt Strike default → [[Network Security Lanjutan (NSM-NDR)]]).

### OPSEC (disiplin operator)
- **Atribusi** — jangan bocorkan identitas/lokasi (jangan akses C2 dari IP pribadi; pakai VPS/VPN khusus).
- **Artefak** — minimalkan jejak di host (in-memory, bersihkan, hindari nama tool default).
- **Tooling hygiene** — ganti default (port, pipe name, sleep, watermark) yang ter-signature.
- **Timing** — beraksi pada jam kerja korban agar membaur dengan trafik normal.

## ⚙️ Praktik

```bash
# Redirector sederhana dengan socat (TCP) atau Nginx/Apache (HTTP filtering)
socat TCP4-LISTEN:443,fork TCP4:<team-server-ip>:443
# Nginx: hanya teruskan URI/UA yg cocok profile, sisanya ke decoy:
#   location / { if ($http_user_agent != "<profile-UA>") { return 302 https://situs-sah; } proxy_pass https://c2; }

# Otomasi build infra (lazim di red team):
#  - Terraform + Ansible : deploy VPS, redirector, C2 secara reproducible
#  - RedELK              : monitoring & alarm sisi operator (lihat apa yg Blue lihat)
```

```text
# Cek sebelum operasi:
# - JARM/JA3 server C2 != default framework
# - domain terkategori bersih (cek di proxy/URL filter)
# - redirector membuang scanner/sandbox (filter UA, ASN cloud security)
```

## 🧰 Tools

- **socat / Nginx / Apache mod_rewrite** — redirector.
- **Terraform + Ansible** — infrastructure-as-code untuk deploy cepat.
- **RedELK** — SIEM sisi red team (deteksi blue investigating).
- **Cobalt Strike Malleable C2 / mTLS** — penyamaran trafik.
- **Domain tools** — cek kategorisasi & reputasi domain.

## 🔗 Kaitan

- Menyokong: [[C2 Frameworks (Command & Control)]] (team server + listener), [[Payload Development & Initial Access]] (staging host).
- Penyamaran melawan: [[Network Security Lanjutan (NSM-NDR)]] (JA3/JARM, beaconing), [[Threat Hunting]].
- Disiplin pelaporan & RoE: [[Reporting & Sertifikasi (OSCP-dll)]].
- Dipakai saat emulasi aktor: [[Purple Team Lanjutan (Adversary Emulation)]].
- Dasar jaringan/DNS/TLS: [[Jaringan Komputer]], [[Kriptografi Dasar]].

## 🎯 Latihan

- Deploy **1 redirector + 1 team server** ([[C2 Frameworks (Command & Control)|Sliver]]) di lab; arahkan implant ke redirector, buktikan IP team server tak pernah terlihat korban.
- Konfigurasi redirector agar **scanner/UA tak dikenal** dialihkan ke situs decoy.
- Periksa **JARM** server C2-mu; ubah konfigurasi agar berbeda dari default.

## 📖 Sumber

- **Red Team Infrastructure Wiki** — https://github.com/bluscreenofjeff/Red-Team-Infrastructure-Wiki
- **RedELK** — https://github.com/outflanknl/RedELK
- **SpecterOps / MDSec** — blog desain infrastruktur C2.
- **MITRE ATT&CK — Resource Development (TA0042)**.
