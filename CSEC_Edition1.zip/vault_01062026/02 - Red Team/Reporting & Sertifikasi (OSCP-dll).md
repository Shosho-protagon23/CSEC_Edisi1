# 📝 Reporting & Sertifikasi (OSCP dll)

> [!summary] Ringkasan
> Skill teknis tidak ada nilainya tanpa **laporan yang baik** — itulah produk akhir seorang pentester. Catatan ini juga memetakan jenjang sertifikasi offensive sebagai panduan karier.

**Bagian dari:** [[Red Team (MOC)]]

---

## 🧠 Bagian 1 — Reporting

Laporan pentest yang baik berisi:
1. **Executive Summary** — untuk manajemen non-teknis: seberapa parah, dampak bisnis.
2. **Temuan (Findings)** — tiap kerentanan: deskripsi, **bukti (screenshot/command)**, skor risiko ([[Vulnerability Assessment|CVSS]]), langkah reproduksi.
3. **Rekomendasi Perbaikan** — cara menambal (menyambung ke sisi blue: [[Hardening & Vulnerability Management]]).

> [!tip] Catat sejak awal
> Dokumentasikan **setiap** command & screenshot selama mengerjakan, bukan di akhir. Tool seperti **CherryTree**, **Obsidian** (ini!), atau **Sysreptor** membantu.

## 🧠 Bagian 2 — Jenjang Sertifikasi Offensive

| Level | Sertifikasi | Catatan |
|---|---|---|
| Pemula | **eJPT** (INE) | ramah pemula, praktis, murah |
| Pemula–menengah | **CompTIA PenTest+/Security+** | teori, diakui industri/HR |
| Menengah (favorit) | **OSCP** (OffSec) | ujian praktik 24 jam, sangat dihormati, "try harder" |
| Lanjut | **CRTP / CRTE** (AlteredSecurity) | fokus [[Active Directory Attacks]] |
| Lanjut | **OSEP, OSWE, CPTS (HTB)** | spesialisasi (evasion, web, dll) |

Jalur realistis pemula: **eJPT / Security+ → CPTS atau OSCP**.

## 🔗 Kaitan

- Temuan dilaporkan memakai bahasa [[Cyber Kill Chain & MITRE ATT&CK]].
- Rekomendasi langsung memberi makan proses [[Hardening & Vulnerability Management]] (sisi blue) — di sinilah red & blue bertemu jadi [[Purple Team]].
- Platform latihan untuk persiapan: [[Sumber Belajar & Platform Latihan]].

## 🎯 Latihan

- Setiap kali selesai mesin di [[Setup Lab (Virtualisasi)]] atau HTB, **tulis laporan mini** seakan untuk klien. Ini membedakan hobiis dari profesional.

## 📖 Sumber

- **OffSec OSCP** — https://www.offsec.com/courses/pen-200/
- **TCM Security — PNPT** (alternatif OSCP yang ramah pemula) — https://certifications.tcm-sec.com
- **Contoh laporan pentest** — https://github.com/juliocesarfort/public-pentesting-reports
