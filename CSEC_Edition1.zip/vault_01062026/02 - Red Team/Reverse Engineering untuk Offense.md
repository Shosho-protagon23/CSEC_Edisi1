# 🔬 Reverse Engineering untuk Offense

> [!summary] Ringkasan
> **Reverse engineering (RE)** adalah membongkar program biner (tanpa source code) untuk memahami cara kerjanya. Bagi offense, RE adalah keterampilan dasar di balik **exploit development**, **vulnerability research**, *crackme/keygen*, dan menganalisis target tertutup (firmware, app mobile). Note ini mengenalkan alur RE **statis vs dinamis**, alat inti (Ghidra/IDA/radare2), dan **patching biner**. Ini fondasi yang menyatukan rantai [[Buffer Overflow (Stack-Based)]] → [[Heap Exploitation]].

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Linux Dasar untuk Security]], [[Exploitation & Metasploit]]

> [!note] Kapan ini relevan
> Saat kamu butuh memahami sesuatu yang **tidak ada source-nya**: cari bug untuk exploit, pahami proteksi lisensi, atau bedah malware/firmware. RE itu sabar & iteratif — keterampilan jangka panjang.

---

## 🧠 Konsep Inti

### Dari source ke biner (dan balik)
```text
source code --(compile)--> assembly --(assemble)--> machine code (biner)
RE membalik:  biner --(disassemble)--> assembly --(decompile)--> pseudo-C
```
- **Disassembler** — ubah byte mesin → instruksi assembly.
- **Decompiler** — rekonstruksi pseudo-C agar lebih mudah dibaca (Ghidra/Hex-Rays).
- RE **tidak** memulihkan source asli persis — hanya pendekatan yang cukup untuk dipahami.

### Statis vs Dinamis
| Pendekatan | Apa | Alat |
|---|---|---|
| **Statis** | baca kode **tanpa menjalankan** (disasm/decompile, string, import) | Ghidra, IDA, radare2, `strings`, `objdump` |
| **Dinamis** | **jalankan** & amati (register, memori, syscall) | gdb (+pwndbg/GEF), x64dbg, ltrace/strace, Frida |

Praktik nyata = gabungan keduanya: statis untuk peta, dinamis untuk konfirmasi nilai runtime.

### Bekal yang perlu dipahami
- **Assembly x86-64 dasar** — register (RAX/RDI/RSP/RIP), instruksi (`mov`, `cmp`, `jmp`, `call`, `ret`), **calling convention** (argumen di RDI, RSI, RDX...).
- **Format biner** — **ELF** (Linux), **PE** (Windows; lihat [[Malware Analysis Dasar]]), Mach-O (macOS/iOS).
- **Struktur program** — fungsi, stack frame (→ [[Buffer Overflow (Stack-Based)]]), heap (→ [[Heap Exploitation]]), GOT/PLT.

### Patching biner
Mengubah byte instruksi untuk mengubah perilaku — mis. balik `je` (jump if equal) → `jne` untuk melewati cek lisensi/password. Inti dari menyelesaikan **crackme**.

## ⚙️ Praktik

```bash
# --- Triase awal sebuah biner ---
file ./target                      # arsitektur, statik/dinamik, stripped?
strings -n 8 ./target              # teks: password, URL, pesan error
checksec --file=./target           # proteksi: NX, PIE, RELRO, Canary (→ exploit dev)
nm ./target ; objdump -d ./target  # simbol & disassembly cepat

# --- Statis di radare2 ---
r2 -A ./target                     # analisis otomatis
> afl                              # list fungsi
> pdf @ main                       # disassemble fungsi main
> s sym.check_password ; pdf       # lihat fungsi target

# --- Dinamis di gdb (pwndbg) ---
gdb ./target
> break main
> run
> info registers
> x/20gx $rsp                      # periksa stack
```

```text
# --- Ghidra (GUI, gratis, decompiler kuat) ---
#  File > Import > target  →  Analyze (default)  →  double-click 'main'
#  Panel Decompiler menampilkan pseudo-C → telusuri logika cek/validasi
```

> [!tip] Alur menyelesaikan crackme
> 1) `strings`/`file` untuk petunjuk → 2) Ghidra: temukan fungsi pengecek → 3) pahami syarat lolos → 4) **keygen** (tulis input yang valid) atau **patch** (`radare2 -w`, ubah `je`→`jne`).

## 🧰 Tools

- **Ghidra** — suite RE NSA, gratis, decompiler sangat baik (rekomendasi pemula).
- **IDA Pro / IDA Free** — disassembler/decompiler de-facto industri (Hex-Rays).
- **radare2 / Cutter** — RE open-source CLI + GUI.
- **Binary Ninja** — komersial, API skripting bagus.
- **gdb + pwndbg/GEF**, **x64dbg** (Windows) — debugger dinamis.
- **Frida** — instrumentasi dinamis (hook fungsi runtime; lihat [[Lab — Mobile (Android-iOS) Hacking]]).
- **angr** — analisis simbolik (selesaikan crackme otomatis).

## 🔗 Kaitan

- Fondasi exploit dev: [[Buffer Overflow (Stack-Based)]] → [[ROP (Return-Oriented Programming)]] → [[Format String Exploitation]] → [[Heap Exploitation]].
- Bedah target tertutup: firmware [[Lab — IoT & Embedded Hacking]], app mobile (DEX/Mach-O) [[Lab — Mobile (Android-iOS) Hacking]], ECU [[Automotive (CAN Bus) Hacking]].
- **Sisi Blue ↔** [[Malware Analysis Dasar]] (RE dipakai membongkar malware — keterampilan sama, tujuan berbeda) & [[DFIR Lanjutan (Memory Forensics)]].

## 🎯 Latihan

- **crackmes.one** — ribuan crackme bertingkat (mulai level 1).
- **pwn.college** & **Nightmare** — kurikulum RE + binexp terstruktur.
- **picoCTF — Reverse Engineering** & **Ghidra/IDA tutorial resmi**.
- Selesaikan 1 crackme dengan **dua cara**: keygen *dan* patch biner.

## 📖 Sumber

- **Ghidra** — https://ghidra-sre.org
- **OpenSecurityTraining2 — RE courses** (gratis).
- **Practical Malware Analysis** (RE bab awal) & **Reverse Engineering for Beginners** (Dennis Yurichev, gratis).
- **pwn.college** — https://pwn.college
