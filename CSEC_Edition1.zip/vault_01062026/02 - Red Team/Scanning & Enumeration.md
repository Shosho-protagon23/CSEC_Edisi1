# 📡 Scanning & Enumeration

> [!summary] Ringkasan
> Setelah recon, kita "mengetuk pintu" target: memetakan host yang hidup, port terbuka, layanan & versinya, lalu menggali detail tiap layanan (enumeration). Ini menentukan permukaan serangan (*attack surface*).

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Reconnaissance (Information Gathering)]], [[Jaringan Komputer]] · **Lanjut:** [[Vulnerability Assessment]]

---

## 🧠 Konsep Inti

- **Scanning** = menemukan host hidup + port terbuka + versi layanan.
- **Enumeration** = menggali lebih dalam tiap layanan: nama user, share file, versi software, konfigurasi salah.

Aturan emas: **enumerate, enumerate, enumerate.** Mayoritas jalan masuk ditemukan dari enumerasi yang teliti, bukan exploit ajaib.

## ⚙️ Praktik — Nmap (tool utama)

```bash
nmap -sn 192.168.1.0/24            # host discovery (siapa yang hidup?)
nmap -sV -sC 10.10.10.5            # versi layanan + script default
nmap -p- 10.10.10.5                # scan SEMUA 65535 port
nmap -sU 10.10.10.5                # scan UDP
nmap -A 10.10.10.5                 # agresif: OS, versi, script, traceroute
nmap --script vuln 10.10.10.5      # cek kerentanan umum
```

### Enumerasi per layanan
```bash
# Web (80/443)
gobuster dir -u http://10.10.10.5 -w /usr/share/wordlists/dirb/common.txt
whatweb http://10.10.10.5
# SMB (445) — sering bocor
enum4linux -a 10.10.10.5
smbclient -L //10.10.10.5/
# DNS (53)
dig axfr @10.10.10.5 example.com   # coba zone transfer
```

## 🧰 Tools

- **Nmap** — raja scanning port & layanan.
- **Gobuster / ffuf / dirb** — temukan direktori & file tersembunyi di web.
- **enum4linux / smbclient** — enumerasi SMB Windows.
- **Nikto** — scanner kerentanan web cepat.

## 🔗 Kaitan

- Hasilnya jadi input [[Vulnerability Assessment]] & [[Web Application Hacking (OWASP Top 10)]].
- **Sisi Blue ↔**: aktivitas ini sangat berisik & terdeteksi oleh [[Network Security (Firewall, IDS-IPS)]] dan terekam di [[Log Analysis & Monitoring]]. Pelajari keduanya untuk paham cara menyembunyikan/menangkapnya.

## 🎯 Latihan

- **TryHackMe — "Nmap"** (seri lengkap) & **"Enumeration"** rooms.
- **Hack The Box — Starting Point** (mesin mudah, fokus enumerasi).

## 📖 Sumber

- **Nmap Reference Guide** — https://nmap.org/book/man.html
- **TryHackMe — "Network Services 1 & 2"** (enumerasi SMB, FTP, NFS, dll).
