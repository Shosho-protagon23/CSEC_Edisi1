# 🎭 Social Engineering

> [!summary] Ringkasan
> **Social engineering** adalah seni **menipu manusia** agar membocorkan info, memberi akses, atau melakukan tindakan yang merugikan keamanan — bukan membobol mesin, tapi "membobol orang". Manusia adalah lapisan pertahanan **terlemah & terpenting** ([[Defense in Depth & Security Architecture]]), sehingga ini sering jadi jalan masuk termudah dibanding exploit teknis.

**Bagian dari:** [[Red Team (MOC)]] · memanfaatkan hasil [[OSINT (Open-Source Intelligence)]]
**Lawan defensifnya:** lapisan "Manusia" di [[Defense in Depth & Security Architecture]]

---

## 🧠 Konsep Inti

### Kenapa berhasil? (prinsip psikologi — Cialdini)
Penyerang mengeksploitasi pola pikir bawah sadar:
- **Authority (otoritas)** — mengaku bos/IT/polisi → korban patuh.
- **Urgency (mendesak)** — "akun akan diblokir dalam 1 jam!" → korban panik, tak sempat berpikir.
- **Scarcity (kelangkaan)** — "promo terbatas" → takut ketinggalan.
- **Social proof** — "semua rekanmu sudah melakukannya".
- **Liking/Reciprocity** — ramah dulu / beri sesuatu → korban merasa wajib membalas.
- **Fear** — ancaman ("ada virus di komputermu").

### Hubungan dengan OSINT
Serangan yang meyakinkan butuh **pretext** (skenario palsu) yang kredibel. Bahannya digali lewat [[OSINT (Open-Source Intelligence)]]: nama atasan, proyek terbaru, gaya email, jadwal cuti. Makin spesifik info → makin sulit korban curiga.

## 🗂️ Jenis-jenis Serangan

| Jenis | Media | Penjelasan |
|---|---|---|
| **Phishing** | Email massal | Email tipuan ke banyak orang sekaligus (`T1566`). |
| **Spear phishing** | Email bertarget | Diarahkan ke individu spesifik, dipersonalisasi via OSINT. |
| **Whaling** | Email | Spear phishing ke target "kakap" (CEO, CFO). |
| **BEC** *(Business Email Compromise)* | Email | Menyamar eksekutif untuk perintahkan transfer dana/data. |
| **Vishing** | Telepon/VoIP | Penipuan lewat suara ("voice phishing"). |
| **Smishing** | SMS | Phishing lewat pesan teks. |
| **Pretexting** | Apa saja | Membangun skenario/identitas palsu sebagai dasar tipuan. |
| **Baiting** | Fisik/digital | Umpan (USB "tergeletak", unduhan gratis) berisi malware. |
| **Quid pro quo** | Telepon | Tawarkan "bantuan" (mis. mengaku IT support) demi akses. |
| **Tailgating / Piggybacking** | Fisik | Membuntuti orang masuk pintu ber-akses tanpa kartu. |
| **Impersonation** | Fisik/online | Menyamar sebagai kurir, teknisi, karyawan. |

## ⚙️ Praktik (lab beretika)

> [!warning] Etika & Legalitas
> Social engineering terhadap orang sungguhan **wajib ada izin tertulis** (scope engagement). Latih hanya pada diri sendiri, lab, atau target yang mengizinkan. Lihat etika di [[Red Team (MOC)]] & dokumentasi scope di [[Reporting & Sertifikasi (OSCP-dll)]].

```bash
# GoPhish — framework simulasi phishing (kampanye, landing page, tracking)
#   1) jalankan server gophish → buka dashboard
#   2) buat Sending Profile (SMTP), Email Template, Landing Page
#   3) kirim ke grup uji → ukur siapa yang klik/submit

# SET (Social-Engineer Toolkit) — Kali
setoolkit
#   menu: Social-Engineering Attacks → Website Attack Vectors
#         → Credential Harvester (kloning halaman login utk demo lab)

# Evilginx2 — reverse-proxy phishing (bypass MFA via pencurian session) — lanjutan
```

## 🧰 Tools

- **GoPhish** — simulasi kampanye phishing + pelaporan (favorit untuk awareness training).
- **SET (Social-Engineer Toolkit)** — multi-vektor SE di Kali.
- **Evilginx2 / Modlishka** — phishing man-in-the-middle yang dapat mencuri session (bypass MFA).
- **King Phisher** — alternatif kampanye phishing.
- **Maltego / theHarvester** — penggalian target ([[OSINT (Open-Source Intelligence)]]).
- **BeEF** — Browser Exploitation Framework (lanjutan, hook browser korban).

## 🔵 Sisi Blue Team (pertahanan)

Karena targetnya manusia, pertahanan utamanya **manusia + proses**, bukan cuma teknologi:
- **Security Awareness Training** — latih karyawan kenali tanda phishing; lapisan "Manusia" di [[Defense in Depth & Security Architecture]].
- **Kontrol teknis** — filter email (SPF/DKIM/DMARC), sandboxing lampiran, [[Endpoint Security & EDR]], MFA tahan-phishing (FIDO2).
- **Proses** — verifikasi out-of-band untuk permintaan transfer/kredensial; kebijakan "jangan colok USB asing".
- **Deteksi & respons** — laporan email mencurigakan masuk ke [[SOC & SIEM]]; playbook phishing di [[Incident Response]].

## 🟣 Sisi Purple Team (kolaborasi)

- **Red** menjalankan kampanye phishing simulasi (GoPhish) → ukur *click-rate* & *submit-rate*.
- **Blue** memeriksa: apakah email lolos filter? Apakah klik/eksekusi terdeteksi [[Endpoint Security & EDR]] / [[SOC & SIEM]]?
- **Loop**: tutup celah (perbaiki filter, retraining karyawan yang tertipu, tuning deteksi) → uji ulang. Pola di [[Purple Team]].
- Petakan ke MITRE ATT&CK: `T1566` Phishing, `T1598` Phishing for Information, `T1656` Impersonation.

## 🔗 Kaitan

- Mengonsumsi hasil [[OSINT (Open-Source Intelligence)]] untuk membangun pretext meyakinkan.
- Sering jadi **Initial Access** di [[Cyber Kill Chain & MITRE ATT&CK]] (tahap *Delivery*), pintu menuju [[Exploitation & Metasploit]] & [[Password Attacks]].
- **Akses fisik ke gedung:** [[RFID-NFC & Physical Red Teaming]] (tailgating, clone badge, drop device) — sisi teknis dari rekayasa sosial fisik.
- Sisi Blue: [[Defense in Depth & Security Architecture]] (lapisan Manusia), [[Incident Response]] (playbook phishing), [[Endpoint Security & EDR]].
- Pertemuan Red↔Blue: [[Purple Team]].

## 🎯 Latihan

- **TryHackMe — "Phishing"**, **"Social Engineering"**, **"Red Team Engagement" rooms**.
- Bangun kampanye **GoPhish** di [[Setup Lab (Virtualisasi)|lab]] terhadap email uji milikmu sendiri — amati metrik click-rate.
- Audit dirimu: cek email/akunmu di **Have I Been Pwned**, lalu bayangkan pretext yang bisa dibuat dari data itu.

## 📖 Sumber

- **The Social-Engineer Toolkit** & **social-engineer.org** (Christopher Hadnagy).
- **GoPhish** — https://getgophish.com
- **MITRE ATT&CK — Phishing (T1566)** — https://attack.mitre.org/techniques/T1566/
- **TryHackMe — Social Engineering content**.
