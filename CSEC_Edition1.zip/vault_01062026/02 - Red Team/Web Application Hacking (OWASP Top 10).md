# 🕸️ Web Application Hacking (OWASP Top 10)

> [!summary] Ringkasan
> Aplikasi web adalah target tersering karena selalu terbuka ke internet. **OWASP Top 10** adalah daftar 10 risiko keamanan web paling kritis — peta wajib bagi pemula offensive. Ini area paling "ramah pemula" untuk mulai latihan nyata.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Jaringan Komputer]], [[Scanning & Enumeration]]

---

## 🧠 Konsep Inti — OWASP Top 10 (edisi 2021)

1. **Broken Access Control** — bisa akses hal yang seharusnya tidak boleh (mis. ubah `?id=1` → `?id=2` lihat data orang lain = IDOR).
2. **Cryptographic Failures** — data sensitif tak terenkripsi/enkripsi lemah → [[Kriptografi Dasar]].
3. **Injection** — input jahat dieksekusi sistem. Paling terkenal: **SQL Injection** (`' OR 1=1-- `) & **Command Injection**.
4. **Insecure Design** — cacat keamanan sejak desain → [[Threat Modeling]].
5. **Security Misconfiguration** — default password, halaman admin terbuka, header salah.
6. **Vulnerable & Outdated Components** — pakai library/versi rentan → [[Vulnerability Assessment]].
7. **Identification & Authentication Failures** — login lemah, brute-force → [[Password Attacks]].
8. **Software & Data Integrity Failures** — update/serialisasi tak tervalidasi.
9. **Security Logging & Monitoring Failures** — serangan tak terdeteksi (sisi blue: [[Log Analysis & Monitoring]]).
10. **Server-Side Request Forgery (SSRF)** — server dipaksa request ke tujuan internal.

### Bonus penting: **XSS (Cross-Site Scripting)**
Menyuntik JavaScript ke halaman agar berjalan di browser korban (mencuri cookie/session). Tipe: *Reflected, Stored, DOM*.

## ⚙️ Praktik

```sql
-- Contoh deteksi SQL Injection (di field login/parameter):
'  OR  '1'='1
admin'--
```
```bash
# Brute-force direktori & temukan endpoint tersembunyi
ffuf -u http://target/FUZZ -w wordlist.txt
sqlmap -u "http://target/item?id=1" --dbs   # otomatisasi SQLi
```

Alur belajar: gunakan **Burp Suite** untuk mencegat & memodifikasi request HTTP — ini skill inti web hacking.

## 🧰 Tools

- **Burp Suite (Community)** — proxy untuk mencegat/memodifikasi HTTP. Tool #1 web hacking.
- **OWASP ZAP** — alternatif open-source Burp.
- **sqlmap** — otomatisasi SQL Injection.
- **ffuf / gobuster** — fuzzing direktori & parameter.

## 🔗 Kaitan

- **Lanjut ke teknik server-side modern:** [[Web Exploitation Lanjutan]] (SSRF mendalam, deserialization, SSTI, XXE, JWT, request smuggling).
- **Sisi client-side:** [[Client-Side Attacks]] (XSS lanjutan/DOM, CSRF, CORS, postMessage, clickjacking, prototype pollution).
- **Sisi API:** [[API Hacking (REST-GraphQL)]] (BOLA/BFLA, mass assignment, GraphQL introspection) — backend SPA & mobile.
- Banyak celah di sini perlu [[Exploitation & Metasploit]] untuk dieksekusi penuh & [[Password Attacks]].
- **Sisi Blue ↔** [[Log Analysis & Monitoring]] (mendeteksi pola serangan web di log) & WAF di [[Network Security (Firewall, IDS-IPS)]].
- **Padanan mobile:** [[Lab — Mobile (Android-iOS) Hacking]] — aplikasi mobile berkomunikasi ke API back-end yang sama; banyak bug-nya = bug web di server-nya.

## 🎯 Latihan

- **PortSwigger Web Security Academy** (GRATIS, terbaik di kelasnya) — https://portswigger.net/web-security
- **OWASP Juice Shop** & **DVWA** di [[Setup Lab (Virtualisasi)]].
- **TryHackMe — "OWASP Top 10"** & **"Web Fundamentals" path**.

## 📖 Sumber

- **OWASP Top 10** — https://owasp.org/www-project-top-ten/
- **OWASP Web Security Testing Guide (WSTG)** — https://owasp.org/www-project-web-security-testing-guide/
- **PortSwigger** (lihat di atas) — teori + lab dalam satu tempat.
