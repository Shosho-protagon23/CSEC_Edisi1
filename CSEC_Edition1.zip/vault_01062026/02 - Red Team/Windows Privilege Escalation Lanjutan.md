# 🪟⬆️ Windows Privilege Escalation Lanjutan

> [!summary] Ringkasan
> Lanjutan dari [[Privilege Escalation]] khusus **Windows**, mendalami jalur naik dari user biasa → **Administrator/SYSTEM**: **token impersonation** (keluarga *Potato* lewat `SeImpersonatePrivilege`), **abuse privilege khusus** (SeBackup/SeDebug/SeRestore), **UAC bypass**, **service misconfig** (unquoted path, izin lemah), **DLL hijacking**, dan **AlwaysInstallElevated**. Berkaitan erat dengan [[Active Directory Attacks Lanjutan]] di lingkungan domain.

**Bagian dari:** [[Red Team (MOC)]]
**Prasyarat:** [[Privilege Escalation]], [[Windows & Active Directory Dasar]]

> [!note] Kapan ini relevan
> Setelah nyaman dengan `winPEAS`/`whoami /priv` dasar. Kunci Windows privesc adalah membaca output **`whoami /priv`** & **`whoami /groups`** — privilege spesial sering = jalan pintas ke SYSTEM.

---

## 🧠 Konsep Inti — vektor lanjutan

### 1. Privilege token istimewa (`whoami /priv`)
| Privilege | Jalur eksploitasi |
|---|---|
| **SeImpersonatePrivilege** | keluarga **Potato** → curi token SYSTEM (umum di akun service/IIS/MSSQL) |
| **SeBackupPrivilege** | baca file apa pun → dump `SAM`/`SYSTEM`/`NTDS.dit` |
| **SeRestorePrivilege** | tulis file apa pun → ganti biner sistem/service |
| **SeDebugPrivilege** | akses memori proses lain → inject ke proses SYSTEM, dump LSASS |
| **SeTakeOwnershipPrivilege** | ambil alih objek → ubah ACL biner/service |

### 2. Keluarga "Potato" (SeImpersonate → SYSTEM)
Paksa layanan istimewa autentikasi ke kita lalu **impersonate** token-nya:
- **JuicyPotato** (lama, sblm Win10 1809), **RoguePotato**, **PrintSpoofer** (abuse spooler), **GodPotato / JuicyPotatoNG** (modern, lintas versi). Pilih sesuai versi Windows.

### 3. Service misconfig
- **Unquoted service path** — path berspasi tanpa kutip (`C:\Program Files\My App\svc.exe`) → Windows coba `C:\Program.exe` dulu → taruh biner di situ.
- **Weak service permissions** — bisa `sc config` ubah `binPath` service → jalankan biner kita sebagai SYSTEM.
- **Weak file/registry perms** pada biner service → ganti biner-nya.

### 4. DLL hijacking / DLL search-order
Aplikasi (sering SYSTEM/auto-start) memuat DLL dari direktori yang **bisa kita tulis** sebelum lokasi sah → taruh DLL jahat dengan nama yang dicari.

### 5. UAC bypass
Dari admin "ter-filter" (Medium IL) → High IL tanpa prompt: abuse auto-elevate binary (**fodhelper**, **eventvwr**, **sdclt**) + registry hijack. (Lihat juga teknik di [[AV-EDR Evasion & AV Bypass]].)

### 6. AlwaysInstallElevated
Dua registry key aktif → semua `.msi` jalan sebagai SYSTEM. Buat MSI jahat (`msfvenom -f msi`) → install.

### 7. Kredensial tersimpan
`cmdkey /list`, Credential Manager, Unattend/`sysprep.xml`, registry **Autologon**, file konfigurasi, riwayat PowerShell → sambung ke [[Password Attacks]].

## ⚙️ Praktik

```powershell
# --- Enumerasi terarah ---
.\winPEASx64.exe                       # menyeluruh
whoami /priv                           # PRIVILEGE — baris paling penting
whoami /groups
.\PowerUp.ps1 ; Invoke-AllChecks       # audit service/DLL/registry

# --- Unquoted service path ---
wmic service get name,pathname,startmode | findstr /i "auto" | findstr /i /v "c:\windows\\"
# taruh payload di celah path, restart service

# --- Weak service perms: ubah binPath ke SYSTEM ---
sc qc <svc>
sc config <svc> binPath= "C:\temp\rev.exe"
sc stop <svc> & sc start <svc>

# --- AlwaysInstallElevated ---
reg query HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
msiexec /quiet /qn /i evil.msi
```
```cmd
:: --- SeImpersonate → SYSTEM (PrintSpoofer / GodPotato) ---
PrintSpoofer64.exe -i -c cmd
GodPotato -cmd "cmd /c whoami"

:: --- SeBackup: dump hash ---
reg save HKLM\SAM sam.hive & reg save HKLM\SYSTEM system.hive
:: lalu secretsdump.py -sam sam.hive -system system.hive LOCAL
```

> [!tip] Baca `whoami /priv` dulu
> 90% kasus privesc Windows modern (terutama dari akun service/web) selesai lewat **SeImpersonatePrivilege → Potato**. Cek itu sebelum hal lain.

## 🧰 Tools

- **winPEAS** — enumerasi privesc otomatis (PEASS-ng).
- **PowerUp / SharpUp** — audit service/DLL/registry misconfig.
- **PrintSpoofer / GodPotato / RoguePotato / JuicyPotatoNG** — SeImpersonate → SYSTEM.
- **accesschk** (Sysinternals) — periksa izin service/file/registry.
- **secretsdump.py / mimikatz** — dump kredensial (lihat [[Password Attacks]]).
- **LOLBAS** — biner sah yang bisa disalahgunakan — https://lolbas-project.github.io

## 🔗 Kaitan

- Dasar: [[Privilege Escalation]]; setelah SYSTEM → [[Post-Exploitation & Pivoting]] · [[Pivoting & Tunneling Lanjutan]].
- Di domain: menyatu dengan [[Active Directory Attacks]] → [[Active Directory Attacks Lanjutan]] (token/delegation).
- Padanan Linux: [[Linux Privilege Escalation Lanjutan]]; UAC/injection bersinggungan dgn [[AV-EDR Evasion & AV Bypass]].
- Kredensial hasil dump: [[Password Attacks]].
- **Sisi Blue ↔** [[Hardening & Vulnerability Management]] (least-priv, perbaiki ACL service, matikan AlwaysInstallElevated, LAPS), [[Endpoint Security & EDR]] (deteksi Potato/LSASS dump), [[Threat Hunting]].

## 🎯 Latihan

- **TryHackMe — "Windows PrivEsc" (Tib3rius)** & **"Windows PrivEsc Arena"** (standar emas).
- **HackTheBox — Windows Privilege Escalation** (Academy module).
- Lab: buat service dengan unquoted path & weak perms sendiri, lalu eksploitasi.

## 📖 Sumber

- **HackTricks — Windows Local Privilege Escalation** — https://book.hacktricks.xyz/windows-hardening/windows-local-privilege-escalation
- **PayloadsAllTheThings — Windows PrivEsc** — https://github.com/swisskyrepo/PayloadsAllTheThings
- **LOLBAS** — https://lolbas-project.github.io
- **Sushant747 — Total OSCP Guide (Windows priv esc)**.
