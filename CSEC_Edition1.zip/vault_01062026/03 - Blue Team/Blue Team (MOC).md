# 🔵 Blue Team (MOC)

> [!summary] Ringkasan
> Jalur **defensive**: mendeteksi, mencegah, dan merespons serangan. Jika red team mencari satu jalan masuk, blue team harus menutup semuanya — pekerjaan yang lebih sulit, dan tulang punggung keamanan organisasi sehari-hari.

⬅️ Kembali ke [[00 - START HERE]] · Sisi lawan: [[Red Team (MOC)]]

---

## 🎯 Prasyarat

Selesaikan dulu [[Fondasi (MOC)]] — terutama [[Jaringan Komputer]], [[Linux Dasar untuk Security]], [[Windows & Active Directory Dasar]], dan [[Konsep Dasar Keamanan (CIA Triad)]]. Pahami juga cara berpikir musuh di [[Cyber Kill Chain & MITRE ATT&CK]].

## 🗺️ Urutan Belajar

1. [[Defense in Depth & Security Architecture]] — filosofi pertahanan berlapis.
2. [[SOC & SIEM]] — pusat & otak operasi keamanan.
3. [[Log Analysis & Monitoring]] — membaca jejak aktivitas (skill inti analis).
4. [[Network Security (Firewall, IDS-IPS)]] — menyaring & memantau trafik.
5. [[Endpoint Security & EDR]] — melindungi laptop/server.
6. [[Threat Intelligence]] — mengenal musuh & taktiknya.
7. [[Incident Response]] — apa yang dilakukan saat terjadi insiden.
8. [[Digital Forensics (DFIR)]] — investigasi pasca-insiden. Pendalaman: [[DFIR Lanjutan (Memory Forensics)]] (analisis RAM dgn Volatility 3).
9. [[Malware Analysis Dasar]] — membedah software jahat.
10. [[Threat Hunting]] — berburu ancaman secara proaktif.
11. [[Hardening & Vulnerability Management]] — memperkecil permukaan serangan.
12. [[Cloud Detection & Response]] — deteksi & respons serangan di AWS/Azure/GCP (log API, CSPM, IR cloud).
13. [[Detection Engineering (Sigma-YARA Lanjutan)]] — membangun & memelihara aturan deteksi sbg kode (Sigma untuk log, YARA untuk file; lifecycle, tuning, coverage ATT&CK).
14. [[Network Security Lanjutan (NSM-NDR)]] — deteksi berbasis perilaku trafik: NSM/NDR, C2/beaconing, fingerprint TLS (JA3/JARM), DNS tunneling, micro-segmentation/Zero Trust, IDS evasion.

## 🔗 Hubungan dengan Red Team

Setiap pertahanan menangkal teknik serangan tertentu. Pelajari pasangannya:

| Blue (tahan/deteksi) | ↔ | Red (serang) |
|---|---|---|
| [[Network Security (Firewall, IDS-IPS)]] | ↔ | [[Scanning & Enumeration]] |
| [[Log Analysis & Monitoring]] | ↔ | [[Web Application Hacking (OWASP Top 10)]] |
| [[Endpoint Security & EDR]] | ↔ | [[Exploitation & Metasploit]] |
| [[Hardening & Vulnerability Management]] | ↔ | [[Privilege Escalation]] / [[Vulnerability Assessment]] |
| [[Incident Response]] / [[Threat Hunting]] | ↔ | [[Post-Exploitation & Pivoting]] |
| [[Network Security Lanjutan (NSM-NDR)]] | ↔ | [[Post-Exploitation & Pivoting]] (C2/beaconing) |
| [[Cloud Detection & Response]] | ↔ | [[Cloud Security (AWS-Azure-GCP)]] |

Pertemuan keduanya: [[Purple Team]].

## 📖 Sumber utama jalur ini

- **TryHackMe — "SOC Level 1" & "Cyber Defense" paths**.
- **Blue Team Labs Online (BTLO)** — https://blueteamlabs.online
- **LetsDefend** — https://letsdefend.io (simulasi SOC analyst).
