# ☁️🛡️ Cloud Detection & Response

> [!summary] Ringkasan
> Pasangan defensif dari [[Cloud Security (AWS-Azure-GCP)]]. Di cloud, "endpoint" bukan lagi laptop — sumber kebenaran adalah **log API control-plane** (CloudTrail/Activity Log/Audit Logs). Note ini membahas cara **mendeteksi & merespons** serangan cloud: dari mana datang telemetri, apa yang dimonitor (anomali IAM, akses metadata, exfiltrasi storage), layanan deteksi native tiap penyedia (GuardDuty/Defender/SCC), CSPM untuk postur, dan bagaimana **IR di cloud berbeda** dari on-prem. Ini perpanjangan [[SOC & SIEM]] & [[Incident Response]] ke ranah awan.

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[SOC & SIEM]], [[Log Analysis & Monitoring]], [[Incident Response]]

> [!note] Mengapa cloud butuh pendekatan deteksi sendiri
> Tak ada agen EDR di layanan terkelola (S3, Lambda, IAM). Yang kamu punya adalah **jejak API**: setiap aksi (buat user, unduh objek, assume role) tercatat sebagai event. Deteksi cloud = analisis log API + konfigurasi, bukan inspeksi memori/proses.

---

## 🧠 Konsep Inti

### Sumber telemetri (fondasi semua deteksi)
| Penyedia | Log control-plane | Identitas/sign-in | Jaringan |
|---|---|---|---|
| **AWS** | **CloudTrail** (semua API call) | CloudTrail + IAM | VPC Flow Logs |
| **Azure** | **Activity Log** | **Entra ID Sign-in/Audit Logs** | NSG Flow Logs |
| **GCP** | **Cloud Audit Logs** (Admin/Data Access) | Cloud Identity | VPC Flow Logs |

Prinsip #1: **aktifkan logging di semua region & akun**, kirim ke lokasi terpusat (S3+Athena / Log Analytics / BigQuery) lalu ke [[SOC & SIEM|SIEM]]. Serangan pertama penyerang sering **mematikan CloudTrail** — itu sendiri sinyal deteksi.

### Tiga lapis deteksi
1. **Posture (CSPM)** — apakah konfigurasi aman? (bucket publik, IAM longgar, MFA mati). Bersifat *preventif/audit*, bukan real-time.
2. **Threat detection (native)** — anomali perilaku dari log:
   - **AWS GuardDuty** — mis. kredensial EC2 dipakai dari IP luar, recon API, akses dari Tor.
   - **Azure Defender for Cloud** + **Microsoft Sentinel** (SIEM cloud-native).
   - **GCP Security Command Center** + Event Threat Detection.
3. **Custom detection** — aturan buatan sendiri di SIEM atas log API (detection engineering, lihat [[Threat Hunting]]).

### Apa yang dimonitor (sinyal serangan khas)
Memetakan ke **MITRE ATT&CK for Cloud**:
| Taktik | Sinyal yang dicari di log |
|---|---|
| **Credential Access** | kredensial role EC2 dipakai dari IP **di luar** instance (mencurigakan SSRF/pencurian) |
| **Discovery** | lonjakan `List*`/`Describe*`/`Get*` (enumerasi IAM, mis. ScoutSuite/Pacu) |
| **Privilege Escalation** | `iam:AttachUserPolicy`, `iam:PassRole`, `CreateAccessKey` untuk user lain |
| **Persistence** | buat IAM user/key baru, tambah login profile, backdoor Lambda |
| **Defense Evasion** | `StopLogging`/`DeleteTrail` (CloudTrail), ubah konfigurasi log |
| **Exfiltration** | `GetObject` massal, bucket dibuat publik, share snapshot ke akun luar |
| **Impact** | `Delete*` massal, ransomware via enkripsi KMS |

### Metadata abuse (jembatan dari SSRF)
Jika app rentan [[Web Exploitation Lanjutan|SSRF]], penyerang mencuri kredensial via metadata. **Deteksi:** kredensial **instance role** muncul dipakai dari **IP yang bukan instance itu** → GuardDuty `InstanceCredentialExfiltration`. Pencegahan: **IMDSv2** wajib.

---

## ⚙️ Cara Kerja / Praktik

### 1. Pastikan logging aktif & terlindungi
```bash
# AWS — cek trail aktif & multi-region:
aws cloudtrail describe-trails
aws cloudtrail get-trail-status --name <trail>
# lindungi: log file validation + bucket terkunci (cegah tamper)
```

### 2. Query log untuk hunt (contoh)
```sql
-- AWS CloudTrail via Athena — siapa membuat access key untuk user lain?
SELECT eventTime, userIdentity.arn, requestParameters.userName
FROM cloudtrail_logs
WHERE eventName = 'CreateAccessKey'
  AND userIdentity.arn NOT LIKE concat('%', requestParameters.userName, '%');
```
```kql
// Azure Sentinel (KQL) — sign-in dari lokasi tak biasa / impossible travel:
SigninLogs
| where ResultType == 0
| summarize Locations=make_set(Location) by UserPrincipalName
| where array_length(Locations) > 1
```
```sql
-- deteksi penonaktifan logging (defense evasion):
SELECT * FROM cloudtrail_logs WHERE eventName IN ('StopLogging','DeleteTrail');
```

### 3. Audit postur (CSPM)
```bash
prowler aws -M csv,html          # benchmark CIS → temuan misconfig
scoutsuite aws                   # snapshot postur multi-cloud
```

### 4. Respons saat insiden cloud
- **Containment khas cloud:** *revoke* sesi & **disable access key** yang bocor; lampirkan policy `Deny *` ke principal terdampak; isolasi instance via security group karantina (jangan langsung terminate — bukti hilang).
- **Preservasi bukti:** **snapshot EBS/disk**, ekspor log CloudTrail, simpan dengan immutability. Order of volatility tetap berlaku ([[Incident Response]]).
- **Eradication & recovery:** rotasi semua kredensial, IaC redeploy bersih, tutup misconfig.

> [!tip] Otomasi respons (SOAR cloud)
> Cloud sangat cocok untuk respons otomatis: trigger **EventBridge/Lambda** (AWS) atau **Logic App** (Azure) saat GuardDuty/Defender memunculkan finding → otomatis disable key, isolasi, & buka tiket. Lihat konsep SOAR di [[SOC & SIEM]].

---

## 🛡️ Praktik terbaik deteksi

- **Log everything, centralize, protect** — multi-region, akun terpusat, immutable, alert jika logging berhenti.
- **Baseline & anomali** — kenali pola normal (siapa biasa pakai API apa) → alert pada deviasi (impossible travel, IP baru, lonjakan enumerasi).
- **Least privilege + MFA** — mengecilkan dampak & memudahkan deteksi anomali ([[Hardening & Vulnerability Management]]).
- **Tabletop cloud** — latih skenario "access key bocor di GitHub" sebagai bagian [[Incident Response]].
- **Map ke ATT&CK Cloud** — jadikan kerangka coverage detection ([[Threat Intelligence]]).

## 🧰 Tools

- **AWS GuardDuty / Detective**, **Security Hub** (agregasi temuan + CIS).
- **Microsoft Defender for Cloud** + **Microsoft Sentinel** (SIEM cloud-native, KQL).
- **GCP Security Command Center** + Event Threat Detection.
- **Prowler / ScoutSuite / Cloud Custodian** — CSPM & audit/remediasi.
- **CloudTrail + Athena / Sigma untuk cloud** — custom detection di SIEM.
- **Falco** — runtime detection untuk container/K8s.

## 🔗 Kaitan

- **Sisi Red ↔** [[Cloud Security (AWS-Azure-GCP)]] (teknik yang note ini deteksi: IAM privesc, metadata abuse, exfil storage).
- Perpanjangan dari [[SOC & SIEM]] (CloudTrail→SIEM), [[Log Analysis & Monitoring]] (log API = log baru), [[Incident Response]] (IR cloud), [[Threat Hunting]] (hunt di log API), [[Threat Intelligence]] (ATT&CK Cloud).
- Postur & hardening: [[Hardening & Vulnerability Management]] (CSPM/CIS/IAM).
- Jembatan serangan: [[Web Exploitation Lanjutan]] (SSRF→metadata) yang dideteksi sbg credential exfiltration.

## 🎯 Latihan

- **AWS** — nyalakan CloudTrail di akun free-tier, lakukan aksi (buat user, akses S3), lalu cari event-nya di Athena/Console.
- **flaws.cloud** lalu **balik perspektif**: log apa yang akan menangkap tiap langkah penyerang?
- **LetsDefend / BTLO** — ada skenario "cloud incident" (investigasi CloudTrail).
- Tulis 3 aturan deteksi (CreateAccessKey anomali, StopLogging, impossible travel) sebagai write-up.

## 📖 Sumber

- **MITRE ATT&CK for Cloud** — https://attack.mitre.org/matrices/enterprise/cloud/
- **AWS — Security Incident Response Guide** (resmi) — https://docs.aws.amazon.com/whitepapers/latest/aws-security-incident-response-guide/
- **Microsoft Sentinel & Defender docs** — deteksi & KQL.
- **Sigma (cloud rules)** — https://github.com/SigmaHQ/sigma
- **flaws.cloud** (latihan, sisi defensif) — http://flaws.cloud
