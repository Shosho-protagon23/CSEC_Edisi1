# 🧠🔬 DFIR Lanjutan (Memory Forensics)

> [!summary] Ringkasan
> Lanjutan dari [[Digital Forensics (DFIR)]] — fokus mendalam ke **memory forensics**: menganalisis citra RAM untuk menemukan apa yang **tak tersimpan di disk**. RAM menyimpan proses berjalan, koneksi jaringan, kredensial plaintext, kunci enkripsi, malware **fileless/in-memory**, dan perintah yang baru diketik. Note ini membahas **alur investigasi memori end-to-end** dengan **Volatility 3**: dari akuisisi → triase proses → deteksi injeksi/hollowing → ekstraksi kredensial & IOC → timeline, plus melawan **anti-forensics**. Inilah keahlian yang membongkar serangan canggih yang menghindari deteksi disk.

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Digital Forensics (DFIR)]], [[Incident Response]], [[Malware Analysis Dasar]]

> [!note] Kenapa memori begitu berharga
> Malware modern sering **tak pernah menyentuh disk** (fileless, hidup di `powershell.exe`/`rundll32.exe`). EDR bisa di-bypass, log bisa dihapus — tapi untuk **berjalan**, kode harus ada di RAM. Memory forensics menangkapnya di tempat ia tak bisa bersembunyi.

---

## 🧠 Konsep Inti

### Apa yang hanya ada di RAM
- **Proses & thread** aktif (termasuk yang disembunyikan dari Task Manager).
- **Koneksi jaringan** hidup (C2 beaconing) — sering tak tercatat di disk.
- **Kode ter-inject** ke proses sah (process injection/hollowing).
- **Kredensial plaintext**, hash, tiket Kerberos, kunci enkripsi.
- **Command history**, isi clipboard, dekripsi data yang di disk terenkripsi.
- **Registry hive** versi memori (lebih mutakhir dari disk).

### Akuisisi (langkah paling kritis — sekali kesempatan)
RAM **volatile** — mati saat shutdown. Akuisisi harus **sebelum** mematikan mesin (ingat Order of Volatility, [[Digital Forensics (DFIR)]]):
- **Fisik (Windows):** WinPmem, FTK Imager, Magnet RAM Capture, DumpIt.
- **VM:** snapshot/`.vmem` (VMware), `.vmsn` — sumber memori "gratis" & bersih.
- **Linux:** AVML, LiME.
- Setelah dump → **hash** segera, kerjakan **salinan**, catat chain of custody.

### Symbol & profil
Volatility butuh tahu struktur OS. **Volatility 3** memakai **ISF symbol tables** (otomatis untuk banyak build Windows/Linux/Mac) — beda dari Vol2 yang butuh `--profile` manual. Linux/Mac sering perlu **bikin symbol table sendiri** dari kernel target.

### Teknik penyembunyian yang dicari (memetakan ke ATT&CK)
| Teknik penyerang | Jejak di memori |
|---|---|
| **Process Injection** (T1055) | kode RWX di region yang harusnya tak ada → `malfind` |
| **Process Hollowing** | image di disk ≠ image di memori (`ldrmodules` mismatch) |
| **DLL injection** | DLL termuat dari path aneh / tak ada di disk |
| **Rootkit / DKOM** | proses hilang dari list normal tapi muncul via scan pool (`psscan`) |
| **Fileless / LOLBins** | `powershell -enc`, `rundll32` dengan argumen mencurigakan di `cmdline` |

---

## ⚙️ Cara Kerja / Praktik — alur investigasi dengan Volatility 3

### 1. Orientasi & triase proses
```bash
vol -f mem.raw windows.info                # build, arsitektur, waktu
vol -f mem.raw windows.pslist              # proses (dari linked list)
vol -f mem.raw windows.psscan              # scan pool — temukan proses TERSEMBUNYI/mati
vol -f mem.raw windows.pstree              # hubungan induk-anak (cari anak janggal)
```
> Bandingkan `pslist` vs `psscan`: proses yang muncul di `psscan` **tapi tidak** di `pslist` = indikasi **rootkit/unlinking**. Cari juga parent-child anomali (mis. `winword.exe` → `cmd.exe` → `powershell.exe`).

### 2. Deteksi injeksi & kode tersembunyi
```bash
vol -f mem.raw windows.malfind             # region RWX/eksekusi mencurigakan (dump shellcode)
vol -f mem.raw windows.ldrmodules          # DLL tak ter-link / hollowing (kolom InLoad/InInit false)
vol -f mem.raw windows.dlllist --pid 1234  # DLL yang dimuat proses tertentu
```

### 3. Jaringan (cari C2)
```bash
vol -f mem.raw windows.netscan             # koneksi & socket → IP/port C2, proses pemilik
vol -f mem.raw windows.netstat
```

### 4. Command line, persistence, registry
```bash
vol -f mem.raw windows.cmdline             # argumen tiap proses (tangkap powershell -enc)
vol -f mem.raw windows.registry.printkey -K "Software\Microsoft\Windows\CurrentVersion\Run"
vol -f mem.raw windows.registry.userassist # bukti eksekusi program oleh user
```

### 5. Ekstraksi artefak & IOC
```bash
vol -f mem.raw windows.dumpfiles --pid 1234   # tarik file dari memori (mis. payload)
vol -f mem.raw windows.hashdump               # hash kredensial (SAM)
vol -f mem.raw windows.filescan | grep -i suspicious
# decode base64 / -enc PowerShell yang ditemukan, ekstrak IOC → korelasi
```

### 6. Timeline & korelasi
```bash
vol -f mem.raw timeliner.Timeliner          # super-timeline aktivitas memori
# gabungkan dengan timeline disk (plaso/log2timeline) & log → narasi insiden
```

> [!tip] Decode lalu pivot ke IOC
> Hasil `malfind`/`cmdline` sering berisi shellcode atau PowerShell ter-encode. **Dump → decode → ekstrak IOC** (IP/domain/hash) → bedah lebih lanjut di [[Malware Analysis Dasar]], dan jadikan **YARA/Sigma** untuk berburu di host lain ([[Threat Hunting]]).

### Anti-forensics yang dihadapi
- **Memory wiping / process termination** sebelum akuisisi → dump secepat mungkin.
- **Direct Kernel Object Manipulation (DKOM)** sembunyikan proses → andalkan `psscan` (pool scanning), bukan list.
- **Packing/encryption** di disk → tapi terdekripsi di RAM (keunggulan memory forensics).
- **Timestomping** artefak disk → memori memberi kebenaran waktu alternatif.

---

## 🛡️ Tempat dalam alur IR

Memory forensics adalah inti fase **Identification** & **Eradication** [[Incident Response]]:
1. **Akuisisi memori** sebelum isolasi/shutdown (kalau memungkinkan).
2. **Triase** → konfirmasi compromise, temukan proses/C2 jahat.
3. **Ekstrak IOC** → sebar ke EDR/SIEM untuk **scoping** (host lain terdampak?).
4. **Eradication** berbasis temuan, lalu **recovery**.
Otomasi triase massal: **Velociraptor**/**KAPE** mengumpulkan memori+artefak dari banyak host sekaligus.

## 🧰 Tools

- **Volatility 3** — analisis memori, standar industri (plugin di atas).
- **WinPmem / FTK Imager / Magnet RAM Capture / DumpIt** — akuisisi RAM Windows. **AVML/LiME** — Linux.
- **MemProcFS** — mount citra memori sebagai filesystem (eksplorasi mudah).
- **bulk_extractor** — tarik email/URL/kartu/IOC dari dump.
- **Velociraptor / KAPE** — akuisisi & triase skala-luas (DFIR at scale).
- **YARA** — scan citra memori dengan rule (cari malware di RAM).

## 🔗 Kaitan

- Dasar & cabang forensik lain (disk/jaringan): [[Digital Forensics (DFIR)]].
- Temuan dibedah di [[Malware Analysis Dasar]]; IOC → [[Threat Hunting]] & [[Threat Intelligence]].
- Bagian dari [[Incident Response]] (Identification/Eradication) & feed ke [[SOC & SIEM]].
- Deteksi runtime pelengkap: [[Endpoint Security & EDR]] (memori EDR ↔ forensik mendalam).
- **Sisi Red ↔** membongkar [[Post-Exploitation & Pivoting]] (process injection, fileless, persistence) & payload [[Exploitation & Metasploit]]/[[Heap Exploitation|shellcode in-memory]]; penyerang melakukan anti-forensics.

## 🎯 Latihan

- **Volatility** — unduh sampel memori publik (mis. *Cridex*, *Stuxnet* memdump) → jalankan `pslist`/`malfind`/`netscan`, tulis temuan.
- **CyberDefenders / DFIR challenges** — kasus "memory" (mis. *Hawk*, *Banking Troubles*).
- **TryHackMe — "Volatility"**, **BlueTeamLabs — memory investigations**.
- Ambil snapshot `.vmem` dari VM lab-mu yang terinfeksi, lalu investigasi sendiri.

## 📖 Sumber

- **Volatility 3 docs & cheat sheet** — https://volatility3.readthedocs.io
- **The Art of Memory Forensics** (Ligh dkk.) — buku rujukan utama.
- **SANS FOR508 / DFIR memory poster** — https://www.sans.org/posters/?focus-area=digital-forensics
- **MemLabs** (latihan CTF memory forensics) — https://github.com/stuxnet999/MemLabs
