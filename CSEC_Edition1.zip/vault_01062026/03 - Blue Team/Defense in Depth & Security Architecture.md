# 🧱 Defense in Depth & Security Architecture

> [!summary] Ringkasan
> Tidak ada satu pertahanan yang sempurna. **Defense in Depth** adalah strategi berlapis: jika satu lapis ditembus, lapis berikutnya masih menahan. Ini fondasi cara berpikir blue team.

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Konsep Dasar Keamanan (CIA Triad)]]

---

## 🧠 Konsep Inti

### Analogi kastil
Bayangkan kastil: parit → tembok → gerbang → penjaga → ruang harta terkunci. Penyerang harus menembus **semua** lapisan. Begitu pula keamanan IT.

### Lapisan pertahanan (contoh)
1. **Physical** — kunci ruang server, CCTV.
2. **Network** — firewall, IDS/IPS, segmentasi → [[Network Security (Firewall, IDS-IPS)]].
3. **Endpoint** — antivirus, EDR → [[Endpoint Security & EDR]].
4. **Application** — secure coding, WAF → [[Web Application Hacking (OWASP Top 10)]].
5. **Data** — enkripsi, backup → [[Kriptografi Dasar]].
6. **Identity** — MFA, least privilege → [[Hardening & Vulnerability Management]].
7. **Manusia** — pelatihan anti-phishing (lapisan terlemah & terpenting); lawan dari [[Social Engineering]].

### Konsep arsitektur modern
- **Zero Trust** — "jangan percaya siapa pun secara default, verifikasi terus" (never trust, always verify).
- **Segmentation** — pisahkan jaringan agar pelanggaran tidak menyebar (menghambat [[Post-Exploitation & Pivoting|lateral movement]]).
- **Least Privilege** — beri akses seminimal mungkin.

## 🔗 Kaitan

- Mengapa berlapis? Karena memutus **satu** mata rantai [[Cyber Kill Chain & MITRE ATT&CK|kill chain]] sudah menggagalkan serangan.
- **Sisi Red ↔** setiap lapisan adalah hambatan yang harus dilewati penyerang di [[Red Team (MOC)]].
- Diterapkan konkret di hampir semua catatan blue lainnya.

## 🎯 Latihan

- Petakan jaringan rumah/lab-mu: lapisan pertahanan apa saja yang sudah ada? Yang mana hilang?

## 📖 Sumber

- **NIST Cybersecurity Framework (CSF 2.0)** — fungsi Identify/Protect/Detect/Respond/Recover — https://www.nist.gov/cyberframework
- **CISA — Defense in Depth** & **Zero Trust Maturity Model** — https://www.cisa.gov
