# 🛠️🎯 Detection Engineering (Sigma & YARA Lanjutan)

> [!summary] Ringkasan
> **Detection Engineering** adalah disiplin membangun, menguji, dan memelihara aturan deteksi secara sistematis — **detection-as-code**: aturan diperlakukan seperti kode (versi di Git, di-review, di-test, di-CI/CD). Note ini memperdalam dua bahasa aturan inti: **Sigma** (deteksi *log/perilaku*, lintas-SIEM) dan **YARA** (deteksi *file/memori*, pola byte/string), beserta **siklus hidup deteksi**, **tuning false positive**, dan pengukuran *coverage* via ATT&CK. Ini menaikkan tim dari "menulis aturan ad-hoc" ([[Threat Hunting]]) menjadi proses rekayasa yang terukur.

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Threat Hunting]], [[Malware Analysis Dasar]], [[Log Analysis & Monitoring]], [[SOC & SIEM]]

> [!note] Posisi dalam ekosistem
> [[Threat Hunting]] **menemukan** perilaku jahat (ad-hoc). Detection engineering **mengubahnya menjadi deteksi tahan lama** yang otomatis berjalan di [[SOC & SIEM]]. Loop *Improve* dari hunt = pintu masuk ke disiplin ini.

---

## 🧠 Konsep Inti

### Detection-as-Code
Aturan deteksi diperlakukan seperti software:
- **Version control** (Git) — riwayat, review, rollback.
- **Testing** — tiap aturan diuji terhadap sampel jahat (*true positive*) **dan** data bersih (*false positive*).
- **CI/CD** — pipeline mengkonversi & men-deploy aturan ke SIEM/EDR otomatis.
- **Metrik** — lacak FP rate, coverage ATT&CK, waktu deteksi.

### Detection lifecycle (siklus hidup deteksi)
```
1. Ide/Requirement  → dari hunt, intel (TTP baru), insiden, atau gap ATT&CK
2. Riset            → pahami teknik, kumpulkan telemetri & sampel
3. Tulis aturan     → Sigma (log) / YARA (file) — sespesifik mungkin
4. Uji              → TP (sampel jahat) + FP (data produksi/bersih)
5. Deploy           → konversi ke target SIEM/EDR via pipeline
6. Tuning           → kurangi FP, tambah konteks; monitor performa
7. Maintain/Retire  → update saat lingkungan berubah; pensiunkan yg usang
```

### Pyramid of Pain — menyetir kualitas deteksi
Makin ke puncak, makin "menyakitkan" bagi penyerang untuk menghindar (kaitan [[Threat Intelligence]]):
```
   TTP / perilaku        ← paling tahan lama (target detection engineering)
   Tools
   Network/Host Artifacts
   Domain Names
   IP Addresses
   Hash Values           ← paling rapuh (gampang diganti penyerang)
```
Deteksi berbasis **TTP** (mis. "child process mencurigakan dari Office") jauh lebih bernilai daripada blokir hash tunggal.

### Signal vs noise (inti pekerjaan)
Aturan yang baik menyeimbangkan **true positive tinggi** & **false positive rendah**:
- Terlalu **luas** → alert fatigue ([[SOC & SIEM]]), analis mengabaikan.
- Terlalu **sempit** → mudah di-bypass (false negative), penyerang lolos.
- Solusi: deteksi **berlapis** (beberapa aturan dengan kepercayaan berbeda) + konteks (enrichment) + scoring.

---

## ⚙️ Sigma Lanjutan (deteksi log/perilaku)

Sigma = format YAML **generik** yang dikonversi ke query SIEM apa pun (Splunk SPL, ELK, Sentinel KQL) lewat **`sigma-cli`/pySigma**.

### Anatomi fitur lanjutan
```yaml
title: Suspicious Office Child Process Spawning Shell
id: 6f3e2c10-...                # UUID unik (wajib utk tracking)
status: stable
description: Office app menelurkan shell/script host (maldoc → eksekusi)
references: [https://attack.mitre.org/techniques/T1566/001/]
logsource:
  product: windows
  category: process_creation     # butuh Sysmon EID 1 / EID 4688
detection:
  selection_parent:
    ParentImage|endswith:
      - '\winword.exe'
      - '\excel.exe'
      - '\powerpnt.exe'
  selection_child:
    Image|endswith:
      - '\cmd.exe'
      - '\powershell.exe'
      - '\wscript.exe'
      - '\mshta.exe'
  filter_legit:
    CommandLine|contains: 'C:\Program Files\KnownAddin\'
  condition: selection_parent and selection_child and not filter_legit
fields: [ParentImage, Image, CommandLine, User]
falsepositives: [Add-in Office sah, makro internal]
level: high
tags: [attack.execution, attack.t1059, attack.t1566.001]
```
Teknik lanjutan yang dipakai di atas:
- **Modifier**: `|endswith`, `|contains`, `|re` (regex), `|base64offset|contains` (deteksi string ter-encode), `|cidr` (rentang IP).
- **Filter / pengecualian**: gabungkan `selection ... and not filter_legit` untuk menekan FP **tanpa** melemahkan inti.
- **`condition` kompleks**: `1 of selection_*`, `all of selection_*`, `count() by` (correlation, Sigma v2).
- **Metadata wajib**: `id` (UUID), `tags` ATT&CK, `falsepositives`, `level` → mendukung tracking & coverage.

### Konversi & uji
```bash
# konversi Sigma → query SIEM target:
sigma convert -t splunk rule.yml
sigma convert -t lucene -p ecs_windows rule.yml      # ELK/ECS
# uji terhadap log: jalankan query hasil konversi pada data TP & data bersih
```

---

## ⚙️ YARA Lanjutan (deteksi file/memori)

YARA = "pattern matching" untuk file & memori — inti deteksi malware ([[Malware Analysis Dasar]]).

### Rule lanjutan: kondisi, modul, performa
```yara
import "pe"                          // modul PE: akses header, section, imports
import "hash"

rule APT_Loader_Variant {
    meta:
        author = "blue-team"
        description = "Loader X — string + struktur PE"
        reference = "internal-IR-2026-014"
        hash = "ab12...."
    strings:
        $s1 = "Mozilla/5.0 (compatible; loaderX)" ascii
        $s2 = { 55 8B EC 83 EC ?? 53 56 57 }        // opcode prologue (wildcard ??)
        $s3 = /https?:\/\/[a-z0-9]{8,16}\.top\// nocase   // regex C2 pattern
        $api = "VirtualAllocExEx" wide
    condition:
        uint16(0) == 0x5A4D and              // header MZ (file PE)
        pe.number_of_sections < 5 and
        pe.imphash() == "9f2c...." and       // import hash — kuat utk varian
        2 of ($s*) and $api
}
```
Teknik lanjutan:
- **Hex string + wildcard** (`??`, `[2-4]` jump) → tangkap kode meski sedikit berubah.
- **Regex** (`/.../ nocase`) untuk pola C2/URL/mutex.
- **Modul `pe`** → `pe.imphash()`, `pe.sections`, `pe.entry_point`, deteksi anomali struktur (keunggulan vs string mentah).
- **Modul `math`** → `math.entropy()` deteksi **section ter-packing** (entropi tinggi).
- **`condition` numerik** (`uint16(0)==0x5A4D`) → cek magic byte, presisi tinggi.
- **Scan memori**: `yara rule.yar -p <pid>` atau pada citra RAM ([[DFIR Lanjutan (Memory Forensics)]]) → tangkap malware **fileless** yang terdekripsi.

> [!tip] String yang tahan lama > string rapuh
> Hindari mengikat rule ke string yang gampang berubah (pesan debug, path build). Targetkan **artefak struktural** (imphash, opcode prologue, algoritma) — analog "naik Pyramid of Pain" untuk YARA. Uji dengan **`yara -s`** untuk lihat string mana yang match.

### Hindari false positive & jaga performa
- **Anchor kondisi** dengan cek murah dulu (`uint16(0)==0x5A4D`) sebelum string mahal → YARA evaluasi kiri-ke-kanan.
- Uji rule terhadap **goodware corpus** besar (mis. file Windows bersih) untuk ukur FP.

---

## 🧪 Testing & validasi (jangan deploy tanpa uji)

- **Atomic Red Team** — jalankan teknik ATT&CK terkontrol → verifikasi aturanmu **berbunyi** (TP).
- **Detection Lab / purple exercise** — emulasi adversary ([[Purple Team]]) → ukur coverage nyata.
- **FP testing** — jalankan query/rule pada data produksi historis; hitung berapa alert palsu.
- **ATT&CK Navigator** — warnai matriks: teknik mana sudah punya deteksi, mana *gap*.

## 🧰 Tools

- **pySigma / sigma-cli** — konversi & lint aturan Sigma. **SigmaHQ** repo — ribuan rule komunitas.
- **YARA / yara-python** — engine + scripting. **yarGen / yara-forge** — bantu generate & kurasi rule.
- **Atomic Red Team** — emulasi teknik untuk uji TP.
- **Detection-as-code pipeline** — Git + CI (mis. konversi Sigma di GitHub Actions → deploy ke SIEM).
- **MITRE ATT&CK Navigator** — peta coverage. **DeTT&CT** — nilai kualitas log & coverage deteksi.
- **Nuclei / Elastic detection rules / Sigma correlation** — sumber & format tambahan.

## 🔗 Kaitan

- Hilir dari [[Threat Hunting]] (loop *Improve*: hunt → aturan permanen) & input ke [[SOC & SIEM]] (aturan dieksekusi & memicu alert).
- **YARA** memperdalam [[Malware Analysis Dasar]] (rule dari analisis) & dipakai di [[DFIR Lanjutan (Memory Forensics)]] (scan RAM).
- Diarahkan oleh [[Threat Intelligence]] (TTP/IOC → ide deteksi; Pyramid of Pain) & dipetakan ke [[Cyber Kill Chain & MITRE ATT&CK]].
- **Sisi Red ↔** menulis deteksi untuk TTP dari [[Post-Exploitation & Pivoting]], [[Active Directory Attacks Lanjutan]], [[Web Exploitation Lanjutan]]; disempurnakan via [[Purple Team]] (red jalankan TTP → blue buktikan terdeteksi).
- Deteksi cloud (analog, log API): [[Cloud Detection & Response]].

## 🎯 Latihan

- Ambil satu temuan dari [[Threat Hunting|hunt]]-mu → tulis **Sigma rule** lengkap (id, tags ATT&CK, falsepositives) → konversi ke SIEM-mu → uji TP & FP.
- Tulis **YARA rule** untuk sampel malware lab pakai `pe.imphash()` + 1 string struktural; uji `-s` & terhadap goodware.
- **Atomic Red Team** — jalankan satu atomic test, pastikan aturanmu berbunyi, catat di ATT&CK Navigator.
- Kontribusi/baca rule di **SigmaHQ** untuk belajar pola berkualitas.

## 📖 Sumber

- **SigmaHQ** (spec + ribuan rule) — https://github.com/SigmaHQ/sigma
- **YARA docs** — https://yara.readthedocs.io
- **Atomic Red Team** — https://github.com/redcanaryco/atomic-red-team
- **"Detection Engineering" (Palantir/Florian Roth blogs)** & **Awesome Detection Engineering** — praktik terbaik.
- **Pyramid of Pain** (David Bianco) — dasar prioritas deteksi.
