# 🔬 Digital Forensics (DFIR)

> [!summary] Ringkasan
> **Digital Forensics** adalah seni mengumpulkan, mengawetkan, dan menganalisis bukti digital untuk merekonstruksi "apa yang terjadi". Digabung dengan respons, disebut **DFIR** (Digital Forensics & Incident Response).

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Incident Response]], [[Windows & Active Directory Dasar]], [[Linux Dasar untuk Security]]

---

## 🧠 Konsep Inti

### Prinsip emas
- **Order of Volatility** — kumpulkan bukti yang paling mudah hilang dulu: **memori (RAM) → koneksi jaringan → disk → backup**.
- **Chain of Custody** — dokumentasikan siapa memegang bukti, kapan, agar sah secara hukum.
- **Jangan ubah bukti asli** — kerjakan **salinan (image)** + verifikasi dengan hash ([[Kriptografi Dasar]]).

### Cabang forensik
- **Disk forensics** — analisis filesystem, file terhapus, timeline.
- **Memory forensics** — analisis RAM (proses tersembunyi, [[Malware Analysis Dasar|malware]] in-memory, kredensial). Pendalaman: [[DFIR Lanjutan (Memory Forensics)]].
- **Network forensics** — analisis paket (PCAP) → terkait [[Log Analysis & Monitoring]].
- **Artefak Windows** — Registry, Prefetch, $MFT, Event Log, browser history.

## ⚙️ Praktik

```bash
# Buat image disk + hash (jaga integritas)
dd if=/dev/sdb of=evidence.img bs=4M
sha256sum evidence.img > evidence.hash

# Memory forensics dengan Volatility 3
vol -f memory.raw windows.pslist        # daftar proses
vol -f memory.raw windows.netscan       # koneksi jaringan
vol -f memory.raw windows.malfind       # cari injeksi kode mencurigakan
```

## 🧰 Tools

- **Autopsy / The Sleuth Kit** — forensik disk (GUI, ramah pemula).
- **Volatility 3** — forensik memori (standar industri).
- **Wireshark** — forensik jaringan (PCAP).
- **KAPE, FTK Imager, Eric Zimmerman tools** — akuisisi & artefak Windows.

## 🔗 Kaitan

- **Pendalaman memory forensics:** [[DFIR Lanjutan (Memory Forensics)]] (Volatility 3, deteksi injeksi/rootkit, fileless, anti-forensics).
- Bagian "Identification/Eradication" dari [[Incident Response]].
- Sering menemukan & memerlukan [[Malware Analysis Dasar]].
- **Sisi Red ↔** mengungkap jejak [[Post-Exploitation & Pivoting]] (persistence, lateral movement); penyerang melakukan *anti-forensics* untuk menghapus jejak.

## 🎯 Latihan

- **TryHackMe — "Digital Forensics" path**, **"Volatility"**, **"Autopsy"**.
- **CyberDefenders** & **DFIR challenges** — kasus forensik nyata.

## 📖 Sumber

- **Volatility Foundation** — https://volatilityfoundation.org
- **SANS DFIR posters & cheat sheets** — https://www.sans.org/posters/?focus-area=digital-forensics
