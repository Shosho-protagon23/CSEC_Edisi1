# 💻 Endpoint Security & EDR

> [!summary] Ringkasan
> **Endpoint** = perangkat akhir (laptop, server, HP). Karena di sinilah penyerang akhirnya menjalankan kode, perlindungan endpoint sangat krusial. **EDR** adalah evolusi antivirus: ia **merekam & menganalisis perilaku** (telemetri), bukan cuma mencocokkan signature — sehingga bisa menangkap malware yang belum dikenal.

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Windows & Active Directory Dasar]], [[Linux Dasar untuk Security]]

---

## 🧠 Konsep Inti

### Evolusi pertahanan endpoint
- **Antivirus (AV)** klasik — cocokkan **signature** malware dikenal (hash/pola byte). Cepat tapi mudah dikelabui malware baru/ter-pack ([[Malware Analysis Dasar|packing]]).
- **EPP (Endpoint Protection Platform)** — AV modern: signature + heuristik + machine learning untuk *mencegah* (preventif di garis depan).
- **EDR (Endpoint Detection & Response)** — rekam **perilaku** (proses, registry, jaringan), deteksi **anomali & TTP**, simpan telemetri untuk investigasi, bisa **respons** (isolasi host, hentikan proses).
- **XDR** — perluas korelasi lintas domain: endpoint + email + cloud + jaringan dalam satu pandangan.
- **MDR** — *Managed* DR: EDR yang dioperasikan tim eksternal 24/7 (untuk org tanpa SOC sendiri).

> EPP **mencegah** (sebelum eksekusi), EDR **mendeteksi & merespons** (saat/sesudah). Produk modern menggabungkan keduanya.

### Cara EDR mendeteksi
- **Signature** — yang sudah dikenal (cepat, tapi terbatas).
- **Heuristik / ML** — tebak berdasarkan ciri mencurigakan.
- **Behavioral / TTP** — rantai perilaku jahat dipetakan ke [[Cyber Kill Chain & MITRE ATT&CK|ATT&CK]] (mis. `winword.exe` → `powershell.exe -enc` → koneksi keluar = mencurigakan walau file-nya "bersih").
- **IOC matching** — cocokkan hash/IP/domain dari [[Threat Intelligence]] & [[Malware Analysis Dasar]].

### Apa yang dipantau EDR? (telemetri)
- **Proses & rantai induk-anak** — `winword.exe` membuka `powershell.exe` → tanda makro/[[Exploitation & Metasploit|payload]].
- **Process injection / hollowing** — kode disuntik ke proses sah (evasion).
- Perilaku [[Privilege Escalation]] & pembuatan token.
- **Persistence** — registry Run-key, service baru, scheduled task → [[Post-Exploitation & Pivoting]].
- **Koneksi C2 keluar** & beaconing.
- **LOLBins** — penyalahgunaan tool bawaan (`certutil`, `mshta`, `rundll32`).

### Kemampuan Response (huruf "R" di EDR)
- **Isolasi host** dari jaringan (tapi tetap terkendali EDR) — langkah *Containment* di [[Incident Response]].
- **Kill/quarantine** proses & file.
- **Remote shell / live response** untuk investigasi (mirip [[Digital Forensics (DFIR)]]).
- **Rollback** (sebagian produk) — kembalikan perubahan ransomware.

### Application control & hardening endpoint
- **Allowlisting (AppLocker / WDAC)** — hanya program disetujui yang boleh jalan (sangat efektif tapi butuh kelola).
- **ASR rules** (Microsoft Attack Surface Reduction) — blokir perilaku berisiko (makro buat proses anak, dll).
- **Disable makro, LAPS, credential guard** → [[Hardening & Vulnerability Management]].

### EDR evasion (kenapa EDR bukan peluru perak)
Penyerang mahir berusaha lolos: **AMSI bypass**, **unhooking** API, **BYOVD** (bawa driver rentan), *direct syscalls*, payload *in-memory*/fileless. Karena itu EDR dilengkapi [[Threat Hunting|perburuan manual]] & [[Log Analysis & Monitoring|log]] — pertahanan berlapis ([[Defense in Depth & Security Architecture]]).

## ⚙️ Praktik

```powershell
# Windows Defender — status & scan
Get-MpComputerStatus                       # status proteksi
Get-MpThreatDetection                       # ancaman terdeteksi
Start-MpScan -ScanType QuickScan

# Rantai induk-anak proses (deteksi rantai mencurigakan, mis. winword->powershell)
Get-CimInstance Win32_Process |
  Select-Object Name, ProcessId, ParentProcessId, CommandLine

# Lihat ASR rules yang aktif
Get-MpPreference | Select-Object -ExpandProperty AttackSurfaceReductionRules_Ids
```
```bash
# Linux: visibilitas endpoint cepat (audit/osquery)
osqueryi "SELECT name, path, pid FROM processes WHERE on_disk=0;"  # proses tanpa file di disk (mencurigakan)
ausearch -m EXECVE -ts recent                                       # eksekusi via auditd
```

## 🧰 Tools

- **Microsoft Defender for Endpoint**, **CrowdStrike Falcon**, **SentinelOne**, **Cortex XDR** — EDR/XDR komersial.
- **Wazuh** (EDR+SIEM open-source), **OSQuery** (query endpoint seperti DB), **Velociraptor** (DFIR & live response).
- **Sysmon** — logging perilaku detail (jembatan utama ke [[Log Analysis & Monitoring]] & [[Threat Hunting]]).
- **LimaCharlie** — EDR/telemetri yang bisa dipakai gratis untuk lab.

## 🔗 Kaitan

- Telemetri EDR → makanan utama [[SOC & SIEM]] & [[Threat Hunting]]; jejaknya juga di [[Log Analysis & Monitoring]] (via Sysmon).
- IOC/signature dari [[Malware Analysis Dasar]] & [[Threat Intelligence]] jadi aturan deteksi EDR.
- Temuan EDR memicu [[Incident Response]] (isolasi = fase Containment) & investigasi [[Digital Forensics (DFIR)]].
- Hardening endpoint diperdalam di [[Hardening & Vulnerability Management]].
- **Sisi Red ↔** [[Exploitation & Metasploit]] & [[Post-Exploitation & Pivoting]] — payload, injeksi, & C2 adalah persis yang dideteksi EDR; penyerang melakukan *evasion/obfuscation* untuk lolos. Menguji "apakah EDR menangkap teknik X?" = inti [[Purple Team]].

## 🎯 Latihan

- **TryHackMe — "Endpoint Security Monitoring"**, **"Sysmon"**, **"Velociraptor"**, **"Aurora EDR"**.
- Pasang **Sysmon + Wazuh agent** di [[Setup Lab (Virtualisasi)|lab]], jalankan satu payload Metasploit, lalu amati deteksi & rantai prosesnya.
- Aktifkan & uji satu **ASR rule** (mis. blokir Office membuat proses anak), lalu coba makro sederhana.

## 📖 Sumber

- **MITRE ATT&CK** — petakan deteksi EDR ke teknik — https://attack.mitre.org
- **Velociraptor docs** — https://docs.velociraptor.app
- **MITRE Engenuity ATT&CK Evaluations** — perbandingan EDR vendor — https://attackevals.mitre-engenuity.org
- **Microsoft ASR rules** — https://learn.microsoft.com/defender-endpoint/attack-surface-reduction
