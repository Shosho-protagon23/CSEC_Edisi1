# 🚨 Incident Response

> [!summary] Ringkasan
> **Incident Response (IR)** adalah proses **terstruktur** saat serangan benar-benar terjadi: dari mendeteksi, mengisolasi, mengusir penyerang, sampai pemulihan & belajar agar tak terulang. Tujuannya membatasi kerusakan dengan kepala dingin — bukan panik. Kesiapan dibangun *sebelum* insiden, bukan saat kebakaran.

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[SOC & SIEM]], [[Log Analysis & Monitoring]]

---

## 🧠 Konsep Inti — 6 Fase (model SANS / PICERL)

1. **Preparation** — siapkan tim, tools, kontak, & **playbook** *sebelum* insiden. (Fase paling penting & paling sering diabaikan!)
2. **Identification** — deteksi & konfirmasi: ini insiden nyata atau *false positive*? (dari alert [[SOC & SIEM]] / [[Endpoint Security & EDR]]). Tentukan **scope** & **severity**.
3. **Containment** — batasi penyebaran. **Short-term** (isolasi host via [[Endpoint Security & EDR|EDR]], putus jaringan) vs **long-term** (patch sementara, perketat akses sambil siapkan eradication).
4. **Eradication** — hapus akar masalah: malware ([[Malware Analysis Dasar]]), akun penyerang, [[Post-Exploitation & Pivoting|backdoor/persistence]]. Pastikan benar-benar bersih sebelum recovery.
5. **Recovery** — pulihkan sistem ke operasi normal & aman (restore dari backup bersih), **pantau ketat** apakah penyerang kembali.
6. **Lessons Learned** — evaluasi dalam 1–2 minggu: apa yang gagal? perbaiki ke [[Hardening & Vulnerability Management]]; update playbook & deteksi [[SOC & SIEM]].

> Model **NIST SP 800-61** menyusun ulang jadi 4: Preparation → Detection & Analysis → Containment/Eradication/Recovery → Post-Incident Activity. Isinya setara.

### Containment: keputusan kunci
> [!warning] Jangan langsung matikan / cabut listrik
> Mematikan mesin **menghapus bukti volatile** (memori RAM, koneksi aktif, proses). **Isolasi** dari jaringan (cabut kabel/blokir via EDR), jangan di-shutdown — kecuali ada risiko kerusakan aktif (mis. ransomware sedang mengenkripsi → pertimbangkan isolasi cepat).

### Konsep pendukung
- **Chain of Custody** — catat siapa memegang bukti, kapan, perubahan apa — jaga integritas untuk ranah hukum → [[Digital Forensics (DFIR)]].
- **Order of Volatility** — kumpulkan bukti dari yang **paling cepat hilang** dulu: RAM & koneksi → disk → log → arsip.
- **Playbook / Runbook** — langkah baku per jenis insiden (ransomware, phishing → [[Social Engineering]], akun ter-compromise, data breach).
- **Tabletop exercise** — simulasi insiden "di atas kertas" untuk melatih tim & menguji playbook.
- **War room & komunikasi** — saluran terpisah (penyerang mungkin memantau email internal!), peran jelas (Incident Commander, scribe, comms).
- **SLA / severity tiering** — klasifikasi P1–P4 menentukan kecepatan & eskalasi respons.

### Siapa yang terlibat (CSIRT)
Tim respons (**CSIRT/CERT**) bukan cuma teknis: + manajemen, **legal**, **PR/komunikasi**, HR. Insiden besar (breach data pribadi) sering punya **kewajiban lapor regulator** (mis. notifikasi pelanggaran data) dalam tenggat tertentu.

### Metrik
- **MTTD / MTTR** — *Mean Time To Detect / Respond* (lihat juga [[SOC & SIEM]]).
- **Dwell time** — berapa lama penyerang tak terdeteksi di dalam (makin pendek makin baik).

## ⚙️ Praktik (langkah triase awal)

```text
1. Tetap tenang. JANGAN langsung matikan mesin (bukti memori hilang).
2. Isolasi host dari jaringan (cabut/blokir via EDR), bukan dimatikan.
3. Kumpulkan bukti volatile dulu sesuai Order of Volatility:
   - RAM (memory dump) → koneksi & proses aktif → disk image → log.
4. Tentukan scope: host lain yang terdampak? akun apa yang dipakai?
5. Catat TIMELINE & semua tindakan (untuk Lessons Learned, chain of custody, hukum).
6. Komunikasikan via saluran out-of-band yang aman.
```
```powershell
# Snapshot cepat kondisi host yang dicurigai (sebelum perubahan)
Get-NetTCPConnection -State Established | Sort RemoteAddress   # koneksi aktif (C2?)
Get-CimInstance Win32_Process | Select Name,ProcessId,ParentProcessId,CommandLine
Get-LocalUser; Get-LocalGroupMember Administrators              # akun & admin baru?
Get-ScheduledTask | Where State -ne 'Disabled'                  # persistence
```

## 🧰 Tools

- **TheHive + Cortex** — manajemen kasus IR & otomatisasi analisis (SOAR ringan).
- **Velociraptor / GRR** — respons & pengumpulan bukti jarak jauh skala armada.
- **KAPE** — pengumpulan artefak forensik cepat (Windows) → [[Digital Forensics (DFIR)]].
- **EDR** ([[Endpoint Security & EDR|Defender/CrowdStrike/Wazuh]]) — isolasi & live response.
- **Memory capture** — WinPmem / DumpIt / FTK Imager (untuk RAM).

## 🔗 Kaitan

- Dipicu oleh alert [[SOC & SIEM]] & [[Endpoint Security & EDR]]; investigasinya pakai [[Log Analysis & Monitoring]] & [[Digital Forensics (DFIR)]].
- Sampel yang ditemukan → [[Malware Analysis Dasar]]; IOC → [[Threat Intelligence]] & aturan deteksi baru.
- Lessons Learned → [[Hardening & Vulnerability Management]] & [[Threat Hunting]] (buru sisa jejak).
- **Sisi Red ↔** [[Post-Exploitation & Pivoting]] — IR adalah usaha mengusir penyerang yang sudah masuk; memahami teknik post-ex (persistence, lateral movement) membuat IR jauh lebih efektif. Latihan IR vs serangan red nyata = [[Purple Team]].

## 🎯 Latihan

- **TryHackMe — "Incident Response" path**, **"Eradication & Remediation"**, **"Tardigrade"**.
- **LetsDefend / CyberDefenders / Blue Team Labs Online** — kasus IR end-to-end.
- Buat **playbook** ringkas untuk 1 skenario (mis. "laptop kena ransomware") di lab, lalu jalankan sebagai **tabletop exercise**.

## 📖 Sumber

- **SANS Incident Handler's Handbook** — https://www.sans.org/white-papers/33901/
- **NIST SP 800-61 (Computer Security Incident Handling Guide)** — https://csrc.nist.gov/pubs/sp/800/61/r2/final
- **NIST SP 800-86** (integrasi forensik ke IR) & **PICERL** (SANS 6 fase).
