# 📊 Log Analysis & Monitoring

> [!summary] Ringkasan
> Setiap aktivitas di sistem meninggalkan jejak di **log**. Kemampuan membaca log dan menemukan pola mencurigakan adalah skill **paling inti** seorang analis blue team — di sinilah serangan benar-benar terdeteksi. *"Kalau tidak di-log, tidak akan ketahuan."*

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Linux Dasar untuk Security]], [[Windows & Active Directory Dasar]]

---

## 🧠 Konsep Inti

### Logging vs Monitoring
- **Logging** — *merekam* peristiwa (pasif, untuk diperiksa nanti / forensik).
- **Monitoring** — *mengawasi* log secara aktif & memberi peringatan real-time → bahan [[SOC & SIEM]].
Keduanya saling melengkapi: log tanpa monitoring = bukti yang tak pernah dilihat; monitoring tanpa log lengkap = buta.

### Sumber log penting
- **Windows Event Log** — Event ID kunci yang wajib hafal:

  | ID | Arti | Relevansi |
  |---|---|---|
  | `4624` | Login sukses | + **Logon Type** (3=jaringan, 10=RDP) |
  | `4625` | Login **gagal** | Lonjakan = brute-force ([[Password Attacks]]) |
  | `4634/4647` | Logoff | Korelasi durasi sesi |
  | `4688` | Proses dibuat | + CommandLine → deteksi eksekusi jahat |
  | `4672` | Hak istimewa diberikan | Login admin/SYSTEM |
  | `4720` | Akun user dibuat | Persistence ([[Post-Exploitation & Pivoting]]) |
  | `4768/4769` | Tiket Kerberos (TGT/TGS) | Deteksi [[Active Directory Attacks|Kerberoasting/AS-REP]] |
  | `4104` | PowerShell ScriptBlock | Command ter-encode/obfuscate |
  | `7045` | Service baru dipasang | Persistence/lateral movement |
  | **Sysmon 1/3/11/13** | Proses/koneksi/file/registry | Telemetri terkaya (lihat di bawah) |

- **Linux** — `/var/log/auth.log` (login/sudo, Debian) atau `/var/log/secure` (RHEL), `/var/log/syslog`, `journalctl`, `.bash_history`.
- **Web server** — `access.log` & `error.log` → deteksi [[Web Application Hacking (OWASP Top 10)|serangan web]].
- **Firewall / IDS** — koneksi diblokir, signature cocok → [[Network Security (Firewall, IDS-IPS)]].
- **Cloud/SaaS** — AWS CloudTrail, Azure AD sign-in, Microsoft 365 audit.

### Sysmon — kenapa wajib
Windows Event Log bawaan terbatas. **Sysmon** (Sysinternals) menambah telemetri detail: proses + **hash** + induknya (Event 1), koneksi jaringan per-proses (3), pembuatan file (11), perubahan registry (13), DNS query (22). Pakai config **SwiftOnSecurity / Olaf Hartong** sebagai awal. Ini fondasi [[Threat Hunting]].

### Apa yang dicari? (indikator umum)
- Lonjakan **login gagal** lalu satu sukses (brute-force berhasil).
- Login di **jam aneh** / lokasi mustahil (*impossible travel*).
- **Proses anak mencurigakan**: `winword.exe` → `powershell.exe` (makro jahat); PowerShell ter-encode (`-enc`).
- **LOLBins**: `certutil`, `mshta`, `rundll32` mengunduh dari internet.
- **Trafik keluar tak biasa** — beaconing C2 / exfiltration ([[Post-Exploitation & Pivoting]]).
- **Penghapusan log** (Event `1102` Security log cleared) — tanda anti-forensik.

### Kualitas log: 3 hal yang sering gagal
- **Time sync (NTP)** — jam antar-sistem harus sinkron, kalau tidak timeline berantakan. Pakai **UTC**.
- **Centralization** — kirim log ke server terpusat agar penyerang tak bisa hapus jejak lokal.
- **Retention** — simpan cukup lama (banyak breach baru ketahuan berbulan kemudian).

## ⚙️ Praktik

```bash
# Linux: IP dengan login gagal terbanyak (brute-force)
grep "Failed password" /var/log/auth.log | awk '{print $11}' | sort | uniq -c | sort -nr
grep "Accepted password" /var/log/auth.log          # login yang BERHASIL
grep -E "sudo:.*COMMAND" /var/log/auth.log          # eskalasi sudo

# Web access.log: IP teratas + tanda serangan web
awk '{print $1}' access.log | sort | uniq -c | sort -nr | head
grep -E "sqlmap|union.select|\.\./|<script" access.log   # SQLi/LFI/XSS
awk '$9>=500' access.log                              # error 5xx (mungkin dieksploitasi)
```
```powershell
# Windows: login gagal terbaru
Get-WinEvent -FilterHashtable @{LogName='Security';ID=4625} -MaxEvents 50 |
  Select-Object TimeCreated, @{n='User';e={$_.Properties[5].Value}}, @{n='SrcIP';e={$_.Properties[19].Value}}

# Proses dibuat dengan PowerShell ter-encode (butuh audit 4688 + Sysmon)
Get-WinEvent -FilterHashtable @{LogName='Security';ID=4688} |
  Where-Object { $_.Message -match '-enc|FromBase64String' }

# Cek log Security pernah dibersihkan (anti-forensik)
Get-WinEvent -FilterHashtable @{LogName='Security';ID=1102}
```

> Alur baca log: **filter** (waktu/ID/host) → **agregasi** (`sort | uniq -c`) → **cari anomali** → **pivot** (dari IP ke user ke proses). Pola yang sama naik skala di SPL/KQL → [[SOC & SIEM]].

## 🧰 Tools

- **grep / awk / cut / sort / uniq** — analisis log cepat di terminal ([[Linux Dasar untuk Security]]).
- **Event Viewer / Get-WinEvent** — log Windows.
- **Sysmon** (Windows) — logging detail super berguna untuk deteksi.
- **Splunk / ELK / Wazuh** — analisis terpusat → [[SOC & SIEM]].
- **Chainsaw / Hayabusa / EvtxECmd** — parsing cepat file `.evtx` Windows (forensik).
- **GoAccess / lnav** — analisis log web/aplikasi interaktif.

## 🔗 Kaitan

- Bahan bakar [[SOC & SIEM]] (dikumpulkan & dikorelasikan di sana) & dasar [[Threat Hunting]].
- Hash/IOC dari [[Malware Analysis Dasar]] dicocokkan ke log; jejak insiden dipakai [[Incident Response]] & [[Digital Forensics (DFIR)]].
- **Sisi Red ↔** hampir setiap teknik di [[Red Team (MOC)]] meninggalkan jejak di sini — terutama [[Scanning & Enumeration]], [[Password Attacks]], [[Web Application Hacking (OWASP Top 10)]]. Penyerang berusaha menghapus/menghindari jejak (anti-forensik); menguji jejak mana yang tertangkap = [[Purple Team]].

## 🎯 Latihan

- **TryHackMe — "Windows Event Logs"**, **"Sysmon"**, **"Splunk" rooms**.
- **CyberDefenders** (https://cyberdefenders.org) & **Blue Team Labs Online** — challenge analisis log nyata.
- Deploy Sysmon di [[Setup Lab (Virtualisasi)|lab]], lakukan satu serangan ringan, lalu temukan jejaknya di Event Log (latihan deteksi end-to-end).

## 📖 Sumber

- **Microsoft — Windows Security Event IDs** — https://learn.microsoft.com/windows/security/threat-protection/auditing/
- **Sysmon (Sysinternals)** — https://learn.microsoft.com/sysinternals/downloads/sysmon
- **SwiftOnSecurity Sysmon config** — https://github.com/SwiftOnSecurity/sysmon-config
- **Windows logging cheat sheets (Malware Archaeology)**.
