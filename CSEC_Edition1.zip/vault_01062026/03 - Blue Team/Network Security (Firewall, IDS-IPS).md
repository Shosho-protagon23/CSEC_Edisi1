# 🧯 Network Security (Firewall, IDS/IPS)

> [!summary] Ringkasan
> Lapisan pertahanan di jaringan: **firewall** menyaring trafik berdasarkan aturan, **IDS** mendeteksi serangan, **IPS** mendeteksi *dan memblokir*. Ini gerbang pertama yang ditemui penyerang.

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Jaringan Komputer]], [[Model OSI & TCP-IP]]

---

## 🧠 Konsep Inti

### Firewall
Menyaring trafik berdasarkan aturan (IP, port, protokol).
- **Stateless** — cek tiap paket sendiri-sendiri.
- **Stateful** — paham konteks koneksi (lebih pintar).
- **Next-Gen Firewall (NGFW)** — + inspeksi aplikasi (Layer 7), bisa lihat isi, bukan cuma port.
- **WAF (Web Application Firewall)** — khusus melindungi web dari [[Web Application Hacking (OWASP Top 10)|serangan OWASP]].

### IDS vs IPS
- **IDS** (Intrusion *Detection*) — **memberi tahu** ada serangan (pasif, seperti alarm).
- **IPS** (Intrusion *Prevention*) — **memblokir** serangan secara aktif (inline).
- Metode deteksi: **signature-based** (cocokkan pola serangan dikenal) vs **anomaly-based** (deteksi penyimpangan dari "normal").

### Segmentasi & VPN
- **Network segmentation / VLAN** — pisahkan jaringan agar serangan tak menyebar (lihat [[Defense in Depth & Security Architecture]]).
- **VPN** — terowongan terenkripsi untuk akses jarak jauh aman.

## ⚙️ Praktik

```bash
# Firewall Linux (ufw / iptables)
sudo ufw enable
sudo ufw allow 22/tcp
sudo ufw deny 23/tcp
sudo iptables -L -n

# Snort/Suricata: contoh rule IDS sederhana
# alert tcp any any -> any 80 (msg:"Kemungkinan SQLi"; content:"union select"; sid:1000001;)
```

## 🧰 Tools

- **Snort / Suricata** — IDS/IPS open-source.
- **pfSense / OPNsense** — firewall open-source lengkap.
- **iptables / ufw / nftables** — firewall di Linux.
- **Zeek (Bro)** — network security monitoring mendalam.

## 🔗 Kaitan

- **Sisi Red ↔** [[Scanning & Enumeration]] — aktivitas scan Nmap inilah yang dideteksi/diblokir di sini. Penyerang lalu mencoba menghindarinya (evasion).
- Alert dari IDS mengalir ke [[SOC & SIEM]] & [[Log Analysis & Monitoring]].
- **Pendalaman:** [[Network Security Lanjutan (NSM-NDR)]] — deteksi berbasis perilaku trafik (NSM/NDR), C2/beaconing, JA3/JARM, DNS tunneling, micro-segmentation, IDS evasion.
- **Lab praktik perangkat jaringan:** [[Lab — Hardening Perangkat Jaringan]] (port-security/DHCP snooping/DAI/SSH) vs sisi serang [[Lab — Serangan Jaringan (Network Pentest)]] (ARP spoof/VLAN hopping) — dibangun di [[Lab — Jaringan Vulnerable (Networking)]].

## 🎯 Latihan

- **TryHackMe — "Snort"**, **"Firewalls"**, **"Network Security Solutions"**.
- Pasang **pfSense** di [[Setup Lab (Virtualisasi)]], buat aturan, uji dengan Nmap dari Kali.

## 📖 Sumber

- **Suricata docs** — https://docs.suricata.io
- **Snort** — https://www.snort.org/documents
