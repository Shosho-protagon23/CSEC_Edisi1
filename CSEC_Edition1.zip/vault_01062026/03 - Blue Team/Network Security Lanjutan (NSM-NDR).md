# 🛰️ Network Security Lanjutan (NSM & NDR)

> [!summary] Ringkasan
> Pendalaman dari [[Network Security (Firewall, IDS-IPS)]] ke **deteksi berbasis perilaku trafik** — bukan lagi sekadar memblok port, tapi *memburu* aktivitas jahat di jaringan: **Network Security Monitoring (NSM)** & **Network Detection & Response (NDR)**. Fokus: mendeteksi **C2/beaconing**, menganalisis **trafik terenkripsi** tanpa dekripsi (JA3/JARM), menangkap **DNS tunneling/exfiltration**, menerapkan **micro-segmentation/Zero Trust**, serta memahami & menangkal **IDS/IPS evasion**.

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Network Security (Firewall, IDS-IPS)]], [[Model OSI & TCP-IP]], [[Log Analysis & Monitoring]]

---

## 🧠 Konsep Inti

### Dari IDS klasik → NSM → NDR
- **IDS/IPS** (dasar) — cocokkan **signature** serangan dikenal. Buta terhadap serangan baru & trafik terenkripsi.
- **NSM (Network Security Monitoring)** — kumpulkan & simpan bukti jaringan lengkap untuk analisis & perburuan, bukan sekadar alert. Tiga jenis data Bejtlich:
  - **Full packet capture (PCAP)** — rekaman mentah, bukti paling kaya (mahal di storage).
  - **Session/flow data** — ringkasan koneksi (NetFlow/IPFIX, log `conn.log` Zeek): siapa→siapa, berapa byte, berapa lama. Murah, ideal untuk deteksi beaconing.
  - **Transaction/protocol logs** — Zeek mem-parse protokol jadi log per-event (`dns.log`, `http.log`, `ssl.log`, `x509.log`).
- **NDR (Network Detection & Response)** — generasi modern: NSM + **machine learning/baseline perilaku** + **respons** (integrasi ke firewall/EDR untuk isolasi otomatis). Pasangan jaringan dari [[Endpoint Security & EDR|EDR]].

### Mendeteksi C2 & Beaconing
Malware yang sudah masuk akan "menelepon pulang" ke **C2 server** secara berkala → lihat [[Post-Exploitation & Pivoting]].
- **Beaconing** = koneksi keluar **berulang dengan interval teratur** (mis. tiap 60 detik + jitter). Sinyal kunci: keteraturan waktu, bukan isi paket.
- Indikator: koneksi ke domain/IP reputasi buruk, **JA3 hash** cocok dgn tool C2 dikenal, user-agent aneh, rasio data upload≫download (mungkin exfil), koneksi ke domain baru terdaftar (newly-registered domain).
- Tool **RITA** (Real Intelligence Threat Analytics) menganalisis log Zeek untuk skor beaconing otomatis.

### Analisis trafik terenkripsi (tanpa dekripsi)
~90%+ trafik kini TLS. Dekripsi penuh sering tak praktis/legal. Solusinya **fingerprinting metadata handshake**:
- **JA3 / JA3S** — hash dari parameter *ClientHello* (cipher suites, ekstensi). Banyak malware/tool punya JA3 khas → cocokkan dgn blacklist.
- **JARM** — fingerprint aktif sisi *server*; berguna memetakan server C2 (mis. default Cobalt Strike/Metasploit).
- **Sertifikat (x509.log)** — sertifikat self-signed, CN acak, validitas singkat = mencurigakan.

### DNS sebagai jalur serang & deteksi
- **DNS tunneling / exfiltration** — data diselundupkan dalam query DNS (subdomain panjang) karena DNS jarang difilter. Deteksi: query TXT abnormal, panjang/entropi nama tinggi, volume query ke satu domain melonjak.
- **DGA (Domain Generation Algorithm)** — malware buat ribuan domain acak; deteksi via entropi nama domain.

### Micro-segmentation & Zero Trust
Kelanjutan dari segmentasi/VLAN dasar:
- **Micro-segmentation** — kebijakan per-workload/host (bukan per-subnet), membatasi **lateral movement** → menghambat [[Post-Exploitation & Pivoting]].
- **Zero Trust** — "never trust, always verify": tidak ada jaringan "dalam" yang otomatis dipercaya; tiap akses diverifikasi identitas + konteks. Menekan dampak setelah perimeter ditembus.

### IDS/IPS Evasion (& cara menangkal)
Penyerang menghindari deteksi → kita harus paham caranya:
- **Fragmentasi paket / overlapping fragments**, **manipulasi TTL**, **timing/slow scan** (lihat opsi `-T0/-T1`, `-f`, `--scan-delay` di [[Scanning & Enumeration]]).
- **Enkripsi/tunneling** (HTTPS, DNS, ICMP tunnel), **port non-standar**, **domain fronting**.
- **Penangkal:** normalisasi paket di IPS (reassembly konsisten), inspeksi berbasis perilaku (bukan hanya signature), kurangi blind spot dgn **TLS inspection** di titik sah + monitoring DNS terpusat.

### Deception (jebakan)
- **Honeypot / honeynet** — sistem umpan untuk mendeteksi & mempelajari penyerang.
- **Honeytoken** — kredensial/file palsu; begitu disentuh → alert pasti high-fidelity (false positive nyaris nol).

## ⚙️ Praktik

```bash
# Zeek: hasilkan log protokol dari sebuah PCAP
zeek -r capture.pcap
# → conn.log, dns.log, http.log, ssl.log, x509.log, dll.

# Cari koneksi beaconing kandidat dari conn.log (durasi & jumlah byte mirip-berulang)
cat conn.log | zeek-cut id.orig_h id.resp_h duration orig_bytes | sort | uniq -c | sort -rn | head

# RITA: impor log Zeek lalu lihat skor beaconing
rita import /opt/zeek/logs/ dataset1
rita show-beacons dataset1 | head

# Suricata: jalankan terhadap PCAP & baca alert (EVE JSON)
suricata -r capture.pcap -l ./out/
jq 'select(.event_type=="alert") | .alert.signature' ./out/eve.json

# Hitung JA3 dari trafik (via Suricata/Zeek plugin) lalu cocokkan ke daftar JA3 malware
# Deteksi DNS tunneling sederhana: query dgn nama subdomain sangat panjang
cat dns.log | zeek-cut query | awk '{ if (length($0) > 50) print }' | sort | uniq -c | sort -rn
```

## 🧰 Tools

- **Zeek** — network security monitoring & parsing protokol (jantung NSM).
- **Suricata** — IDS/IPS + ekstraksi metadata (JA3, TLS, flow) modern.
- **RITA** — analisis beaconing/C2 dari log Zeek.
- **Arkime (Moloch)** — indeks & cari full PCAP skala besar.
- **Security Onion** — distro all-in-one (Zeek + Suricata + Elastic) untuk NSM lab.
- **JA3/JARM** — toolset fingerprint TLS.

## 🔗 Kaitan

- **Pendalaman dari:** [[Network Security (Firewall, IDS-IPS)]] (firewall/IDS/IPS dasar).
- **Sisi Red ↔** [[Post-Exploitation & Pivoting]] (C2/beaconing & lateral movement yang diburu di sini) & [[Scanning & Enumeration]] (teknik evasion scan).
- Alert & log mengalir ke [[SOC & SIEM]]; jadi sumber hipotesis [[Threat Hunting]].
- Aturan deteksi (Suricata/Sigma) dikelola sbg kode di [[Detection Engineering (Sigma-YARA Lanjutan)]].
- Filosofi segmentasi: [[Defense in Depth & Security Architecture]].

## 🎯 Latihan

- **TryHackMe — "Zeek"**, **"Zeek Exercises"**, **"Snort Challenge"**, **"Wireshark: Traffic Analysis"**.
- Pasang **Security Onion** di [[Setup Lab (Virtualisasi)]], capture trafik dari mesin [[Lab — VulnHub]] saat di-scan/eksploit, lalu buru beaconing dgn RITA.
- Analisis PCAP C2 publik (mis. malware-traffic-analysis.net) → ekstrak JA3 & domain C2.

## 📖 Sumber

- **Zeek docs** — https://docs.zeek.org
- **The Practice of Network Security Monitoring** (Richard Bejtlich) — buku rujukan NSM.
- **RITA** — https://github.com/activecm/rita
- **JA3** — https://github.com/salesforce/ja3
- **malware-traffic-analysis.net** — latihan PCAP nyata.
