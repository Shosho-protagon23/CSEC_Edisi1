# 🏢 SOC & SIEM

> [!summary] Ringkasan
> **SOC (Security Operations Center)** adalah tim/ruang yang memantau keamanan organisasi 24/7. **SIEM** adalah tool utama mereka: mengumpulkan log dari seluruh sistem ke satu tempat, mengkorelasikannya, dan memunculkan **alert**. Ini titik masuk karier blue team paling umum (**SOC Analyst Tier 1**).

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Defense in Depth & Security Architecture]]

---

## 🧠 Konsep Inti

### SOC — tiga tingkatan analis
- **Tier 1 (triase)** — saring alert: mana nyata, mana *false positive*. Eskalasi yang serius. Pintu masuk karier.
- **Tier 2 (investigasi)** — selidiki alert tereskalasi secara mendalam → [[Incident Response]].
- **Tier 3 (hunter/forensik)** — [[Threat Hunting|berburu proaktif]] & forensik lanjut → [[Digital Forensics (DFIR)]]. Juga **detection engineering** (menulis aturan baru).
- Pendukung: **SOC Manager**, **Threat Intel analyst** ([[Threat Intelligence]]).

### Cara kerja SIEM (alurnya)
1. **Collection** — kumpulkan log dari banyak sumber (lihat [[Log Analysis & Monitoring]]).
2. **Normalization / Parsing** — samakan format log yang beragam jadi field seragam (mis. semua punya `src_ip`, `user`, `timestamp`).
3. **Correlation** — gabungkan beberapa peristiwa jadi satu makna: *"login gagal 10× lalu sukses → kemungkinan brute-force berhasil"*.
4. **Alerting** — picu peringatan saat aturan terpenuhi.
5. **Dashboard & reporting** — visualisasi kondisi & metrik.

### Komponen & istilah kunci
- **Log source** — asal data (firewall, server, endpoint/[[Endpoint Security & EDR|EDR]], aplikasi, cloud).
- **Parser / normalization** — pemetaan log mentah ke field standar (mis. ECS di Elastic).
- **Correlation rule** — "jika X lalu Y dalam Z menit → alert".
- **Use case / detection** — skenario serangan yang ingin dideteksi, dipetakan ke [[Cyber Kill Chain & MITRE ATT&CK|ATT&CK]].
- **Alert vs Event vs Incident** — *event* = satu baris log; *alert* = event yang memicu aturan; *incident* = alert terkonfirmasi jahat → masuk [[Incident Response]].

### Tantangan nyata SOC
- **Alert fatigue** — terlalu banyak alert (banyak *false positive*) → analis kelelahan & melewatkan yang asli. Solusi: tuning aturan, prioritas berbasis risiko.
- **False positive vs False negative** — FP = alarm palsu (mengganggu); **FN = serangan lolos tak terdeteksi (paling berbahaya)**. Tuning adalah menyeimbangkan keduanya.
- **Log coverage** — tak bisa mendeteksi apa yang tak di-log. Pastikan sumber penting aktif (lihat Sysmon di [[Threat Hunting]]).

### Konsep pendukung & metrik
- **SOAR** *(Security Orchestration, Automation & Response)* — playbook **otomatis** untuk respons rutin (mis. blokir IP, isolasi host) → kurangi beban manual.
- **EDR / XDR** — telemetri & respons endpoint, sering jadi sumber utama → [[Endpoint Security & EDR]].
- **MTTD / MTTR** — *Mean Time To Detect / Respond*: makin kecil makin baik (metrik kinerja utama SOC).
- **Detection engineering** — disiplin menulis & menguji aturan deteksi (Sigma → lihat [[Threat Hunting]]).

### Model SOC modern
- **Tiers vs Tierless** — sebagian SOC modern menghapus tier kaku agar analis fleksibel.
- **Threat-informed** — prioritas deteksi diarahkan [[Threat Intelligence]] & relevansi ATT&CK.

## ⚙️ Praktik — contoh query (Splunk SPL)

```spl
# 1. Brute-force: banyak login gagal dari satu sumber (T1110)
index=windows EventCode=4625
| stats count by src_ip, user
| where count > 10

# 2. "Impossible travel": user login dari 2 negara dalam waktu mustahil
index=auth | stats dc(country) AS negara values(country) by user
| where negara > 1

# 3. Korelasi sederhana: login gagal banyak LALU sukses (brute-force berhasil)
index=windows (EventCode=4625 OR EventCode=4624)
| transaction user maxspan=5m
| search EventCode=4625 EventCode=4624

# 4. Akun baru dibuat di luar jam kerja (T1136)
index=windows EventCode=4720 date_hour>=20 OR date_hour<=5
```

> Membaca query SPL: `index=` (di mana data), `| stats` (agregasi), `| where` (filter hasil). Pola yang sama ada di KQL (Sentinel) & EQL/Lucene (Elastic).

## 🧰 Tools (SIEM populer)

- **Splunk** — paling banyak dipakai industri; bahasa **SPL** (ada versi gratis/terbatas).
- **Elastic Stack (ELK) / Elastic Security** — open-source kuat; bahasa **KQL/EQL**.
- **Microsoft Sentinel** — SIEM cloud; bahasa **KQL**.
- **Wazuh** — open-source SIEM+XDR (favorit untuk lab/rumah).
- **Graylog**, **Chronicle (Google SecOps)**.
- **TheHive + Cortex** — case management (jembatan ke [[Incident Response]]).

## 🔗 Kaitan

- Bahan bakarnya: [[Log Analysis & Monitoring]] (dan telemetri [[Endpoint Security & EDR]]).
- Alert terkonfirmasi → memicu [[Incident Response]].
- Aturan deteksi dipetakan ke [[Cyber Kill Chain & MITRE ATT&CK]] & diperkaya [[Threat Intelligence]].
- Tier 3 menjalankan [[Threat Hunting]]; hasil hunt → aturan SIEM baru (loop *improve*).
- IOC/signature dari [[Malware Analysis Dasar]] menjadi aturan deteksi.
- **Sisi Red ↔** penyerang berusaha **tidak memicu** alert ini (anti-forensik, "low & slow"); kelemahan logging = OWASP #9 di [[Web Application Hacking (OWASP Top 10)]]. Menguji apakah SIEM mendeteksi serangan red = [[Purple Team]].

## 🎯 Latihan

- **TryHackMe — "Intro to SIEM"**, **"Splunk: Basics"**, **"Investigating with Splunk"**.
- **LetsDefend** — https://letsdefend.io & **CyberDefenders** — https://cyberdefenders.org (simulasi shift SOC analyst nyata).
- Pasang **Wazuh** di [[Setup Lab (Virtualisasi)|lab]], kirim log dari Windows+Sysmon, lalu picu alert dengan satu serangan ringan.

## 📖 Sumber

- **Splunk Free / Search Tutorial** — https://docs.splunk.com
- **Wazuh docs** — https://documentation.wazuh.com
- **Elastic Security docs** — https://www.elastic.co/security
- **MITRE ATT&CK** (peta use-case deteksi) — https://attack.mitre.org
