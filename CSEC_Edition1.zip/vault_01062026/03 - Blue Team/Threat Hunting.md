# 🏹 Threat Hunting

> [!summary] Ringkasan
> **Threat hunting** adalah perburuan **proaktif** terhadap penyerang yang sudah lolos dari deteksi otomatis. Asumsinya: **"anggap kita sudah dibobol — mana buktinya?"** (*assume breach*). Kebalikan dari menunggu alert ([[SOC & SIEM]]) — hunter aktif mencari yang belum berbunyi.

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Log Analysis & Monitoring]], [[Cyber Kill Chain & MITRE ATT&CK]], [[Threat Intelligence]]

---

## 🧠 Konsep Inti

### Reaktif vs Proaktif
- SOC tradisional **reaktif** — merespons alert yang sudah ada.
- Threat hunting **proaktif** — mencari ancaman yang *belum* memicu alert. Penyerang canggih (APT) sengaja memakai teknik yang tak ada signature-nya, jadi harus diburu manual.

### Tiga pendekatan berburu
- **Hypothesis-driven** — mulai dari hipotesis berbasis [[Threat Intelligence|TTP]]: *"jika APT X aktif, kita akan lihat T1059.001 (PowerShell ter-encode)"* → cari buktinya di log. Pendekatan paling matang.
- **IOC-driven** — cari indikator yang sudah dikenal (hash, IP, domain) dari [[Threat Intelligence]] / [[Malware Analysis Dasar]].
- **Anomaly-driven (baseline)** — cari penyimpangan dari "normal" (mis. login jam 3 pagi, proses langka, lonjakan data keluar). Butuh baseline dulu.

### Loop perburuan (PEAK / siklus hunt)
1. **Hypothesis** — rumuskan dugaan spesifik & dapat diuji (berbasis TTP/intel).
2. **Collect** — tentukan data yang dibutuhkan ([[Log Analysis & Monitoring]], EDR, Sysmon).
3. **Investigate** — query, pivot antar data, cari pola.
4. **Respond** — jika ketemu jahat → picu [[Incident Response]].
5. **Improve** — apa pun hasilnya, **otomatiskan** jadi aturan deteksi baru di [[SOC & SIEM]] agar tak perlu diburu manual lagi. Hunt yang "nihil" pun tetap berharga (mengurangi area gelap).

### Data yang diburu (kualitas > kuantitas)
Hunt hanya sebaik datanya. Sumber paling berguna:
- **Sysmon** (Windows) — proses, koneksi jaringan, perubahan registry, image load. Wajib di-deploy dulu.
- **EDR telemetry** → [[Endpoint Security & EDR]].
- **Log proses** (Event ID 4688), **PowerShell logging** (4104), **autentikasi** (4624/4625), **DNS/proxy**.

### Tingkat kematangan (Hunting Maturity Model)
HM0 (hanya andalkan alert) → HM1 (lapor indikator) → HM2 (ikut prosedur hunt orang lain) → HM3 (buat prosedur sendiri) → HM4 (otomatisasi hunt). Tujuannya naik level, bukan diam di HM0.

### Pyramid of Pain (kaitan dgn intel)
Berburu **TTP/perilaku** (puncak piramida) jauh lebih menyakitkan bagi penyerang daripada memblokir hash/IP yang gampang diganti → lihat [[Threat Intelligence]].

## ⚙️ Praktik — contoh hunt

```spl
# Splunk: PowerShell ter-encode (T1059.001) — favorit attacker utk menyembunyikan command
index=windows EventCode=4688 (CommandLine="*-enc*" OR CommandLine="*FromBase64String*")

# "Beaconing" C2: koneksi berkala & berulang ke IP/domain yang sama (T1071)
index=network | stats count by dest_ip | where count > 1000
# beaconing sejati: lihat KETERATURAN interval, bukan cuma jumlah (jitter rendah = mencurigakan)

# Persistence via Run key (T1547.001)
index=windows EventCode=13 TargetObject="*\\CurrentVersion\\Run\\*"

# Living-off-the-Land: tool bawaan Windows dipakai jahat (LOLBins)
index=windows (Image="*\\certutil.exe" OR Image="*\\mshta.exe") CommandLine="*http*"
```

> **Pivoting** = bergerak dari satu temuan ke data lain: dari IP mencurigakan → cari proses yang membuka koneksi → cari proses induknya → cari host lain yang menghubungi IP sama. Inilah inti analisis hunt.

### Menulis deteksi: Sigma
Hasil hunt yang valid diubah jadi **Sigma rule** (aturan deteksi generik, lintas-SIEM) agar otomatis ke depan. Sigma untuk *log/perilaku*; pasangannya **YARA** untuk *file* → lihat [[Malware Analysis Dasar]]. Pendalaman menulis & memelihara aturan secara sistematis (detection-as-code): [[Detection Engineering (Sigma-YARA Lanjutan)]].
```yaml
title: PowerShell Encoded Command
logsource: { product: windows, category: process_creation }
detection:
  selection:
    CommandLine|contains: ['-enc', 'FromBase64String']
  condition: selection
level: high
```

## 🧰 Tools

- **SIEM** ([[SOC & SIEM|Splunk/ELK/Wazuh]]) — sumber data & mesin query utama.
- **Sysmon + Sigma** — telemetri kaya + aturan deteksi generik lintas-SIEM.
- **Velociraptor / OSQuery** — query endpoint langsung (live) saat berburu.
- **HELK / Security Onion** — platform hunting siap pakai.
- **Jupyter Notebook + Pandas** — analisis data hunt skala besar.
- **MITRE ATT&CK Navigator** — petakan *coverage* hunt ke matriks TTP.

## 🔗 Kaitan

- Memakai [[Log Analysis & Monitoring]] sebagai data & [[Threat Intelligence]] sebagai arah (hipotesis).
- IOC/signature dari [[Malware Analysis Dasar]] jadi titik awal IOC-driven hunt.
- Temuan memicu [[Incident Response]] & memperbaiki aturan [[SOC & SIEM]] (loop *Improve*).
- **Sisi Red ↔** langsung memburu jejak [[Post-Exploitation & Pivoting]] & [[Active Directory Attacks]]: persistence, lateral movement, C2 beaconing. "Kucing-kucingan" red vs blue tingkat lanjut — disempurnakan lewat [[Purple Team]] (red jalankan TTP → blue buktikan bisa diburu).

## 🎯 Latihan

- **TryHackMe — "Threat Hunting" rooms**, **"Tactical Detection"**, **"Hunt Me" series**.
- Deploy **Sysmon** (config SwiftOnSecurity) di [[Setup Lab (Virtualisasi)|lab]], jalankan satu teknik [[Post-Exploitation & Pivoting|post-ex]], lalu buru jejaknya — ini purple teaming pribadi.
- Tulis & uji **Sigma rule** dari satu temuan: https://github.com/SigmaHQ/sigma

## 📖 Sumber

- **MITRE ATT&CK** — https://attack.mitre.org (peta TTP untuk hipotesis).
- **The ThreatHunting Project** — https://www.threathunting.net
- **Sigma** — https://sigmahq.io
- **PEAK Threat Hunting Framework** (Splunk) & **Sqrrl Hunting Maturity Model**.
