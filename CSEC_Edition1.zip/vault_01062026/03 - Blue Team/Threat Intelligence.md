# 🌍 Threat Intelligence

> [!summary] Ringkasan
> **Cyber Threat Intelligence (CTI)** adalah informasi terolah tentang ancaman: siapa penyerangnya, alat & taktik mereka, dan indikatornya. Tujuannya: berhenti reaktif, mulai antisipatif — "kenali musuhmu".

**Bagian dari:** [[Blue Team (MOC)]]
**Prasyarat:** [[Cyber Kill Chain & MITRE ATT&CK]]

---

## 🧠 Konsep Inti

### Tingkatan intelligence
- **Strategic** — gambaran besar untuk pimpinan (tren, risiko bisnis).
- **Operational** — kampanye & kelompok penyerang tertentu.
- **Tactical** — TTP (Tactics, Techniques, Procedures) → dipetakan ke [[Cyber Kill Chain & MITRE ATT&CK]].
- **Technical** — IOC konkret (hash file, IP, domain jahat).

### IOC vs IOA
- **IOC (Indicator of Compromise)** — bukti bahwa sistem *sudah* ter-compromise (hash malware, IP C2).
- **IOA (Indicator of Attack)** — tanda serangan *sedang* terjadi (perilaku), lebih sulit dikelabui.

### APT (Advanced Persistent Threat)
Kelompok penyerang canggih & gigih (sering disponsori negara), mis. APT28, Lazarus. Dipetakan di MITRE ATT&CK Groups.

### Pyramid of Pain
Makin "menyakitkan" indikator yang kamu blokir bagi penyerang: hash (mudah diganti) < IP < domain < tools < **TTP** (paling sulit diganti — incar ini).

## ⚙️ Praktik

```text
# Cek reputasi indikator (di browser):
VirusTotal      → https://virustotal.com   (cek hash/URL/IP)
AbuseIPDB       → https://abuseipdb.com     (reputasi IP)
MITRE ATT&CK    → cari grup APT & TTP-nya
```
Bagikan/terima intel via format **STIX/TAXII** & platform **MISP**.

## 🧰 Tools

- **MISP** — platform berbagi threat intelligence open-source.
- **OpenCTI** — manajemen knowledge CTI.
- **VirusTotal, AbuseIPDB, AlienVault OTX** — sumber reputasi/feed.

## 🔗 Kaitan

- Memberi makan aturan deteksi di [[SOC & SIEM]] & arah perburuan di [[Threat Hunting]].
- **Sisi Red ↔** intel ini dibangun dari mengamati teknik [[Red Team (MOC)]] di dunia nyata; recon penyerang ([[Reconnaissance (Information Gathering)]]) adalah CTI versi offensive.
- Dibangun memakai teknik [[OSINT (Open-Source Intelligence)]] yang sama (sumber terbuka) — bedanya arah: CTI memprofilkan penyerang, OSINT red memprofilkan target.

## 🎯 Latihan

- **TryHackMe — "Threat Intelligence Tools"**, **"MITRE"**, **"Cyber Threat Intelligence" rooms**.

## 📖 Sumber

- **MITRE ATT&CK Groups** — https://attack.mitre.org/groups/
- **MISP Project** — https://www.misp-project.org
- **The Pyramid of Pain (David Bianco)** — konsep klasik CTI.
