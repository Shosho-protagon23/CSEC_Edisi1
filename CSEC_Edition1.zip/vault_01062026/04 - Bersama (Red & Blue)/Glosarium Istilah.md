# 📕 Glosarium Istilah

> [!summary] Ringkasan
> Kamus istilah cyber security yang sering muncul di vault ini. Buka saat ketemu istilah asing. Istilah dibiarkan dalam Bahasa Inggris sesuai penggunaan industri.

**Bagian dari:** [[00 - START HERE]]

---

## A–C
- **0-day (zero-day)** — kerentanan yang belum ada patch-nya; sangat berbahaya.
- **APT** — *Advanced Persistent Threat*, kelompok penyerang canggih & gigih → [[Threat Intelligence]].
- **Attack Surface** — total titik yang bisa diserang; diperkecil lewat [[Hardening & Vulnerability Management]].
- **Backdoor** — jalan masuk tersembunyi untuk akses ulang → [[Post-Exploitation & Pivoting]].
- **Brute-force** — coba semua kombinasi password → [[Password Attacks]].
- **C2 (Command & Control)** — server yang mengendalikan korban dari jauh.
- **CIA Triad** — Confidentiality, Integrity, Availability → [[Konsep Dasar Keamanan (CIA Triad)]].
- **CVE** — ID unik kerentanan publik → [[Vulnerability Assessment]].
- **CVSS** — skor keparahan kerentanan (0–10).

## D–H
- **DFIR** — Digital Forensics & Incident Response → [[Digital Forensics (DFIR)]].
- **DoS / DDoS** — serangan membanjiri layanan hingga down (serang *Availability*).
- **EDR** — Endpoint Detection & Response → [[Endpoint Security & EDR]].
- **Enumeration** — menggali detail layanan target → [[Scanning & Enumeration]].
- **Exploit** — kode yang memanfaatkan kerentanan → [[Exploitation & Metasploit]].
- **Hash** — sidik jari satu arah dari data → [[Kriptografi Dasar]].
- **Hardening** — mengeraskan konfigurasi → [[Hardening & Vulnerability Management]].

## I–O
- **IDS / IPS** — deteksi / pencegahan intrusi → [[Network Security (Firewall, IDS-IPS)]].
- **IOC** — *Indicator of Compromise*, bukti sistem ter-compromise → [[Threat Intelligence]].
- **Lateral Movement** — berpindah antar mesin di jaringan → [[Post-Exploitation & Pivoting]].
- **MITRE ATT&CK** — basis data taktik & teknik penyerang → [[Cyber Kill Chain & MITRE ATT&CK]].
- **MFA** — *Multi-Factor Authentication*, autentikasi berlapis.
- **OSINT** — intelijen dari sumber terbuka → [[OSINT (Open-Source Intelligence)]].
- **OWASP** — organisasi keamanan web → [[Web Application Hacking (OWASP Top 10)]].

## P–S
- **Payload** — kode yang dijalankan setelah exploit berhasil → [[Exploitation & Metasploit]].
- **Persistence** — mempertahankan akses → [[Post-Exploitation & Pivoting]].
- **Phishing** — menipu korban via email/pesan untuk mencuri data/akses → [[Social Engineering]].
- **Pivoting** — memakai mesin terkuasai sebagai loncatan → [[Post-Exploitation & Pivoting]].
- **Privilege Escalation** — menaikkan hak akses → [[Privilege Escalation]].
- **Ransomware** — malware pengunci/enkripsi data → [[Malware Analysis Dasar]].
- **Reverse Shell** — target connect balik ke penyerang → [[Exploitation & Metasploit]].
- **SIEM** — sistem agregasi log & alert → [[SOC & SIEM]].
- **SOC** — Security Operations Center → [[SOC & SIEM]].
- **SQL Injection** — menyuntik perintah SQL lewat input → [[Web Application Hacking (OWASP Top 10)]].

## T–Z
- **Threat Hunting** — perburuan ancaman proaktif → [[Threat Hunting]].
- **TTP** — Tactics, Techniques & Procedures (gaya bertindak penyerang) → [[Threat Intelligence]].
- **Vulnerability** — kelemahan yang bisa dieksploitasi → [[Vulnerability Assessment]].
- **WAF** — Web Application Firewall → [[Network Security (Firewall, IDS-IPS)]].
- **XSS** — Cross-Site Scripting → [[Web Application Hacking (OWASP Top 10)]].
- **Zero Trust** — model "jangan percaya, selalu verifikasi" → [[Defense in Depth & Security Architecture]].

---
> Istilah belum ada? Tambahkan sendiri saat belajar — vault ini milikmu. 😊
