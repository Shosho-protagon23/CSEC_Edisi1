# 🟣🎯 Purple Team Lanjutan (Adversary Emulation)

> [!summary] Ringkasan
> Pendalaman dari [[Purple Team]] ke **metodologi terstruktur**: bukan sekadar "red serang, blue lihat", tapi **adversary emulation** yang meniru aktor ancaman nyata secara terencana, mengukur **coverage deteksi** terhadap MITRE ATT&CK, lalu mengubah hasilnya jadi deteksi yang teruji. Fokus: bedakan **emulation vs simulation**, susun **emulation plan**, jalankan **BAS (Breach & Attack Simulation)**, terapkan **threat-informed defense**, dan ukur kematangan deteksi secara berkelanjutan (CI).

**Bagian dari:** [[00 - START HERE]] · pendalaman [[Purple Team]] · menggabungkan [[Red Team (MOC)]] + [[Blue Team (MOC)]]

---

## 🧠 Konsep Inti

### Adversary Emulation vs Simulation vs Pentest
- **Penetration test** — cari & buktikan kerentanan sebanyak mungkin (lebar). Tujuan: temukan jalan masuk.
- **Adversary *simulation*** — meniru *perilaku* serangan secara umum untuk menguji deteksi (tidak terikat satu aktor).
- **Adversary *emulation*** — meniru **aktor ancaman spesifik** (mis. APT29/FIN7) berdasarkan **threat intelligence**: pakai TTP, urutan, dan tool yang benar-benar mereka gunakan. Paling realistis & relevan bagi organisasi tertentu.
- Pemilihan aktor berbasis [[Threat Intelligence]] & [[Threat Modeling]] — emulasikan musuh yang **paling mungkin** menyerangmu, bukan yang paling seram.

### Threat-Informed Defense
Filosofi MITRE/CTID: keputusan pertahanan didorong oleh **pemahaman atas perilaku musuh nyata** (ATT&CK), bukan tebakan. Tiga pilar: (1) pahami musuh (CTI/ATT&CK), (2) uji pertahanan terhadap perilaku itu (purple/emulation), (3) perbaiki terukur (detection engineering).

### Adversary Emulation Plan
Dokumen terstruktur yang memandu satu latihan emulasi:
1. **Pilih aktor & scope** — berdasarkan relevansi (industri, geografi) dari laporan CTI.
2. **Petakan TTP** ke [[Cyber Kill Chain & MITRE ATT&CK|ATT&CK]] — daftar teknik per taktik (Initial Access → Impact) dalam urutan realistis.
3. **Bangun prosedur** — bagaimana tiap teknik dieksekusi (tool/command), dengan kontrol keamanan (jangan rusak produksi).
4. **Eksekusi & catat** — red jalankan; waktu, host, perintah dicatat presisi untuk korelasi.
5. **Ukur deteksi** — untuk tiap teknik: **Detected / Logged-but-not-alerted / Missed**.
6. **Tingkatkan & uji ulang** — celah → [[Detection Engineering (Sigma-YARA Lanjutan)|aturan deteksi]] baru → jalankan lagi sampai tertangkap.

> MITRE CTID merilis **adversary emulation plans** siap pakai (mis. APT29, FIN6, menuShell) sebagai blueprint.

### BAS — Breach & Attack Simulation
Otomasi purple teaming: platform menjalankan ribuan TTP terus-menerus & memberi **skor coverage** secara berkelanjutan (continuous validation), bukan latihan sekali setahun. Cocok untuk mengukur regresi deteksi setelah perubahan infrastruktur.

### Mengukur Coverage & Kematangan
- **ATT&CK Navigator** — heatmap teknik: hijau=terdeteksi, merah=blind spot. Output utama latihan purple.
- Bedakan **coverage** (punya aturan utk teknik X) vs **efektivitas** (aturan benar-benar memicu saat diuji). Emulation menguji yang kedua.
- Hindari "ATT&CK bingo" — mengejar centang semua teknik. Prioritaskan teknik yang **dipakai aktor relevan** + tinggi di [[Detection Engineering (Sigma-YARA Lanjutan)|Pyramid of Pain]] (TTP > tool > artifact > hash).

### Operasionalisasi (Detection-as-CI)
Latihan purple matang = **berulang & otomatis**: emulation plan dijalankan terjadwal (mis. tiap rilis aturan baru), hasil masuk dashboard, regresi deteksi memicu alert ke tim. Menyatukan [[Detection Engineering (Sigma-YARA Lanjutan)|detection-as-code]] dgn validasi adversarial.

## ⚙️ Praktik

```bash
# Atomic Red Team — jalankan satu teknik ATT&CK terukur (PowerShell, Invoke-Atomic)
Invoke-AtomicTest T1003.001        # OS Credential Dumping: LSASS Memory
Invoke-AtomicTest T1003.001 -Cleanup

# CALDERA — emulasi adversary otomatis: jalankan operation berbasis profil aktor
#   (server CALDERA + agent 'Sandcat' di host target → pilih adversary profile → run)

# Petakan hasil ke ATT&CK Navigator: ekspor layer JSON (teknik + skor) lalu render
#   Detected=score 0(hijau) / Missed=score 100(merah) di Navigator layer

# Prelude Operator / VECTR — catat hasil per-teknik (Detected/Logged/Missed) utk metrik
```

## 🧰 Tools

- **MITRE CALDERA** — platform emulasi adversary otomatis (operation, ability, profil aktor).
- **Atomic Red Team / Invoke-Atomic** — uji teknik ATT&CK granular & aman.
- **VECTR** — lacak & visualisasikan hasil latihan purple (heatmap deteksi, riwayat).
- **MITRE ATT&CK Navigator** — peta coverage deteksi.
- **CTID Adversary Emulation Library** — emulation plan aktor siap pakai.
- **BAS komersial** — AttackIQ, SafeBreach, Cymulate (continuous validation).

## 🔗 Kaitan

- **Pendalaman dari:** [[Purple Team]] (konsep & loop dasar).
- **Memilih target emulasi:** [[Threat Intelligence]] + [[Threat Modeling]] (aktor & skenario relevan).
- **Kerangka TTP:** [[Cyber Kill Chain & MITRE ATT&CK]].
- **Sisi Red:** seluruh rantai [[Red Team (MOC)]] (eksekusi TTP, mis. [[Active Directory Attacks Lanjutan]], [[Post-Exploitation & Pivoting]]).
- **Sisi Blue:** celah deteksi → [[Detection Engineering (Sigma-YARA Lanjutan)]] → diuji ulang; sinyal jaringan via [[Network Security Lanjutan (NSM-NDR)]]; alur ke [[SOC & SIEM]] & [[Threat Hunting]].

## 🎯 Latihan

- Ambil **satu emulation plan CTID** (mis. APT29), jalankan 3–4 teknik via CALDERA/Atomic di [[Setup Lab (Virtualisasi)|lab GOAD/AD]], catat Detected/Missed di VECTR, lalu tutup satu celah dgn Sigma rule & uji ulang.
- Bangun **ATT&CK Navigator layer** dari hasilnya — itu peta coverage pertamamu.

## 📖 Sumber

- **MITRE CTID — Adversary Emulation Library** — https://github.com/center-for-threat-informed-defense/adversary_emulation_library
- **MITRE CALDERA** — https://caldera.mitre.org
- **VECTR** — https://github.com/SecurityRiskAdvisors/VECTR
- **MITRE Engenuity ATT&CK Evaluations** — hasil uji vendor terhadap emulasi aktor.
- **Tim Wadhwa-Brown / SCYTHE — Purple Team Exercise Framework (PTEF)**.
