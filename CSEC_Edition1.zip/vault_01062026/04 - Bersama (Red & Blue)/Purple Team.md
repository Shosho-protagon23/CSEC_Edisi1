# 🟣 Purple Team

> [!summary] Ringkasan
> **Purple team** bukan tim ketiga, melainkan **kolaborasi** red + blue. Red menyerang, blue mengamati & memperbaiki deteksi — dalam satu loop umpan balik cepat. Tujuannya: meningkatkan pertahanan dengan cara paling efektif yang ada.

**Bagian dari:** [[00 - START HERE]] · menggabungkan [[Red Team (MOC)]] + [[Blue Team (MOC)]]

---

## 🧠 Konsep Inti

### Kenapa "purple"?
🔴 Merah + 🔵 Biru = 🟣 Ungu. Alih-alih red & blue bekerja terpisah (red lapor temuan, blue baca laporan berbulan kemudian), purple team mempertemukan keduanya secara langsung.

### Cara kerja (loop)
1. Pilih satu teknik dari [[Cyber Kill Chain & MITRE ATT&CK]] (mis. `T1003` Credential Dumping).
2. **Red** mengeksekusinya di lab/lingkungan ([[Password Attacks]], [[Active Directory Attacks]]).
3. **Blue** memeriksa: apakah [[SOC & SIEM]] / [[Endpoint Security & EDR]] mendeteksinya? ([[Log Analysis & Monitoring]]).
4. Jika **tidak** terdeteksi → buat/perbaiki aturan deteksi → uji ulang.
5. Ulangi untuk teknik berikutnya → tingkatkan **coverage** ATT&CK.

> Ini cara tercepat menutup *detection gap* nyata, bukan teoretis.

## 🧰 Tools

- **Atomic Red Team** — koleksi "atomic test" untuk mensimulasikan teknik ATT&CK dengan aman → https://github.com/redcanaryco/atomic-red-team
- **Caldera** (MITRE) — emulasi adversary otomatis.
- **Sigma** — menulis aturan deteksi hasil latihan (lihat [[Threat Hunting]]).

## 🔗 Kaitan

- **Pendalaman:** [[Purple Team Lanjutan (Adversary Emulation)]] — metodologi terstruktur (emulation vs simulation, emulation plan, BAS, ukur coverage ATT&CK).
- Menghubungkan hampir semua catatan: teknik [[Red Team (MOC)]] ↔ deteksi [[Blue Team (MOC)]].
- Memperkuat siklus [[Reporting & Sertifikasi (OSCP-dll)|reporting]] → [[Hardening & Vulnerability Management|remediasi]].
- Berbasis [[Threat Modeling]] & [[Threat Intelligence]] untuk memilih teknik prioritas.
- Latihan fase recon: red ber-[[OSINT (Open-Source Intelligence)]] terhadap organisasi, blue mengukur footprint & deteksinya.

## 🎯 Latihan

- Jalankan satu **Atomic Red Team** test di [[Setup Lab (Virtualisasi)|lab]] dengan Sysmon aktif, lalu cari jejaknya di [[Log Analysis & Monitoring|Event Log]]. Itu purple teaming dalam skala kecil.

## 📖 Sumber

- **Atomic Red Team** — https://atomicredteam.io
- **MITRE Caldera** — https://caldera.mitre.org
- **SANS — Purple Team** resources.
