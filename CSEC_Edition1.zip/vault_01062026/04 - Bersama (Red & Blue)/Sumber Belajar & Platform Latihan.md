# 🎓 Sumber Belajar & Platform Latihan

> [!summary] Ringkasan
> Cyber security dipelajari dengan **praktik**, bukan hanya membaca. Catatan ini mengumpulkan platform latihan, kanal belajar, dan komunitas terbaik — semua punya tier gratis.

**Bagian dari:** [[00 - START HERE]]

---

## 🧪 Platform Latihan Hands-On

### Ramah pemula (mulai di sini)
- **TryHackMe** — https://tryhackme.com — jalur belajar terstruktur, lab di browser. **Terbaik untuk pemula total.** Path: *Pre Security → Cyber Security 101 → Jr Penetration Tester / SOC Level 1*.
- **Hack The Box (HTB) + HTB Academy** — https://www.hackthebox.com — lebih menantang; *Starting Point* untuk pemula.
- **PortSwigger Web Security Academy** — https://portswigger.net/web-security — **gratis penuh**, terbaik untuk [[Web Application Hacking (OWASP Top 10)|web hacking]].

### Blue team / defensive
- **LetsDefend** — https://letsdefend.io — simulasi kerja SOC analyst.
- **Blue Team Labs Online (BTLO)** — https://blueteamlabs.online
- **CyberDefenders** — https://cyberdefenders.org — challenge DFIR & [[Log Analysis & Monitoring|analisis log]] nyata.

### Klasik & gratis
- **OverTheWire** — https://overthewire.org — wargames terminal (mulai "Bandit", lihat [[Linux Dasar untuk Security]]).
- **VulnHub** — https://www.vulnhub.com — VM rentan untuk [[Setup Lab (Virtualisasi)|lab]].
- **picoCTF** — https://picoctf.org — CTF ramah pemula.
- **Root-Me, PentesterLab** — latihan tambahan.

## 📚 Belajar Teori (gratis)

- **Professor Messer** (YouTube) — Network+, Security+ (fondasi terjernih).
- **John Hammond, IppSec, NetworkChuck** (YouTube) — walkthrough & konsep.
- **HackTricks** — https://book.hacktricks.xyz — wiki teknik ofensif (referensi, bukan untuk pemula murni).
- **PayloadsAllTheThings** — https://github.com/swisskyrepo/PayloadsAllTheThings — kumpulan payload & teknik.

## 🏆 Referensi Resmi (bookmark)

- **MITRE ATT&CK** — https://attack.mitre.org → [[Cyber Kill Chain & MITRE ATT&CK]]
- **OWASP** — https://owasp.org → [[Web Application Hacking (OWASP Top 10)]]
- **NIST CSRC** — https://csrc.nist.gov
- **NIST NVD (CVE)** — https://nvd.nist.gov → [[Vulnerability Assessment]]

## 🧭 Saran Alur untuk Pemula Total

1. [[Fondasi (MOC)]] + TryHackMe *Pre Security / Cyber Security 101*.
2. Bangun [[Setup Lab (Virtualisasi)|lab]].
3. Pilih [[Red Team (MOC)|🔴 Red]] atau [[Blue Team (MOC)|🔵 Blue]] → ikuti TryHackMe path yang sesuai.
4. Latihan rutin di HTB/PortSwigger/LetsDefend + **tulis catatan di vault ini**.
5. Kejar sertifikasi pertama → [[Reporting & Sertifikasi (OSCP-dll)]].

## 📖 Komunitas

- Reddit: r/netsec, r/cybersecurity, r/AskNetsec.
- Discord: TryHackMe, HTB, banyak server CTF Indonesia.
- Ikuti penulisan **write-up** CTF — cara belajar tercepat.
