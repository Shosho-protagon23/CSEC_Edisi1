# 🧩🔬 Threat Modeling Lanjutan

> [!summary] Ringkasan
> Pendalaman dari [[Threat Modeling]] dari "kenal STRIDE" ke **praktik nyata yang sistematis**: menggambar sistem dengan **DFD + trust boundary**, menerapkan STRIDE **per-elemen/per-interaksi** (bukan asal tebak), memilih metodologi yang tepat (**PASTA** untuk risiko bisnis, **LINDDUN** untuk privasi, **Attack Tree** untuk jalur serangan), menilai risiko secara **objektif** (CVSS/OWASP Risk Rating, bukan DREAD), lalu menjadikannya **kode & bagian pipeline** (threat-modeling-as-code, shift-left). Termasuk pemodelan domain modern: cloud/microservices, supply chain, dan **AI/ML via MITRE ATLAS**.

**Bagian dari:** [[00 - START HERE]] · pendalaman [[Threat Modeling]] · lintas [[Red Team (MOC)]] & [[Blue Team (MOC)]]
**Prasyarat:** [[Threat Modeling]], [[Konsep Dasar Keamanan (CIA Triad)]]

---

## 🧠 Konsep Inti

### 1. Menggambar sistem: DFD & Trust Boundary
Threat modeling yang baik dimulai dari **gambar**, bukan daftar. **Data Flow Diagram (DFD)** punya 4 elemen baku:

| Simbol | Elemen | Contoh |
|---|---|---|
| Persegi | **External Entity** (aktor di luar kendali kita) | user, browser, API pihak ketiga |
| Lingkaran | **Process** (kode yang mengolah data) | web server, fungsi auth |
| Dua garis sejajar | **Data Store** (tempat data diam) | database, file, cache |
| Panah | **Data Flow** (data bergerak) | request HTTP, query SQL |

**Trust boundary** = garis putus-putus tempat **tingkat kepercayaan berubah** (mis. internet → DMZ, user → server, container → host). **Inilah tempat ancaman lahir** — data yang menyeberang batas harus divalidasi/diautentikasi. Aturan praktis: *makin banyak data flow melintasi trust boundary, makin besar attack surface*.

### 2. Menerapkan STRIDE secara sistematis
[[Threat Modeling|STRIDE]] dasar cuma daftar 6 ancaman. Versi lanjutan memetakannya ke elemen DFD:

- **STRIDE-per-Element** — tiap elemen DFD rawan ancaman tertentu (tabel Microsoft): External Entity → S, R; Process → semua (STRIDE penuh); Data Store → T, I, D (+R jika log); Data Flow → T, I, D. → bikin checklist tidak ada ancaman terlewat.
- **STRIDE-per-Interaction** — periksa tiap **interaksi** (source → flow → destination) lintas trust boundary, bukan elemen sendiri-sendiri. Lebih sedikit false positive, lebih relevan ke alur nyata.

> Insecure Design ([[Web Application Hacking (OWASP Top 10)]] A04) pada dasarnya = **kegagalan threat modeling**: cacat ada di rancangan, bukan bug implementasi — tidak bisa ditambal patch, harus dimodelkan ulang.

### 3. Memilih metodologi (kapan pakai apa)

| Metodologi | Fokus | Kapan dipakai |
|---|---|---|
| **STRIDE** | jenis ancaman teknis per komponen | default untuk desain aplikasi/sistem |
| **PASTA** (7 tahap) | **risiko berbasis bisnis** | butuh justifikasi ke manajemen/risiko |
| **LINDDUN** | **privasi** (data pribadi) | sistem olah PII, kepatuhan GDPR/UU PDP |
| **Attack Tree** | enumerasi **jalur serangan** ke 1 goal | analisis "bagaimana attacker capai X" |
| **VAST / Trike / OCTAVE** | skala enterprise / berbasis aset | program AppSec besar, agile |

**PASTA — Process for Attack Simulation & Threat Analysis (7 tahap):**
1. Definisikan objektif bisnis & dampak.
2. Definisikan scope teknis (komponen, dependensi).
3. Dekomposisi aplikasi (DFD, trust boundary).
4. Analisis ancaman (intel + ATT&CK).
5. Analisis kerentanan (peta ke CWE/CVE).
6. Pemodelan serangan (attack tree, simulasi TTP).
7. Analisis risiko & dampak → prioritas mitigasi.
→ Menjembatani tim teknis dengan bahasa risiko bisnis. Lihat pemilihan aktor di [[Purple Team Lanjutan (Adversary Emulation)]].

**LINDDUN — privacy threat modeling.** Padanan STRIDE untuk privasi, 7 kategori:

| Huruf | Ancaman privasi |
|---|---|
| **L** | Linkability (data bisa dikaitkan) |
| **I** | Identifiability (subjek bisa diidentifikasi) |
| **N** | Non-repudiation (subjek tak bisa menyangkal — buruk untuk privasi) |
| **D** | Detectability (keberadaan data terdeteksi) |
| **D** | Disclosure of information (bocor) |
| **U** | Unawareness (subjek tak sadar datanya diolah) |
| **N** | Non-compliance (langgar regulasi) |

→ Sisi defensif dari teknik di [[OSINT Investigasi Individu (People OSINT)]]: kalau attacker bisa *link* & *identify* dari jejak publik, LINDDUN memodelkannya sejak desain.

### 4. Menilai risiko secara objektif (jangan pakai DREAD)
DREAD (di [[Threat Modeling|note dasar]]) **subjektif & tak konsisten** — Microsoft sendiri sudah meninggalkannya. Gantilah dengan skoring terstandar:
- **CVSS** — skor 0–10 untuk kerentanan (base/temporal/environmental). Standar industri.
- **OWASP Risk Rating** — `Risiko = Likelihood × Impact`, tiap faktor punya sub-faktor terdefinisi (skill attacker, exploitability, dampak teknis & bisnis).
- **Attack Tree** untuk hitung jalur termurah: beri tiap node biaya/probabilitas → cari path "paling mungkin", bukan "paling seram".

### 5. Threat Modeling as Code (otomasi & skala)
Pergeseran modern: model = **artefak versioned** di Git, bukan diagram Visio yang basi. Tetap up-to-date karena hidup bersama kode.
- **pytm** (OWASP) — definisikan sistem sebagai objek Python → auto-generate DFD + temuan STRIDE.
- **Threagile** — model YAML → render diagram + daftar risiko + mitigasi.
- **IriusRisk** — platform enterprise, integrasi Jira/CI.
- **OWASP Threat Dragon** & **MS Threat Modeling Tool** — versi GUI (dari note dasar).

### 6. Shift Left — integrasi ke SDLC/DevSecOps
- Threat model dibuat **saat desain** (paling murah memperbaiki cacat di sini), bukan setelah rilis.
- Dipicu di **pipeline CI/CD**: perubahan arsitektur → trigger review/threat-model-as-code.
- **Threat Modeling Manifesto** (2020) — *values*: temuan > template, kolaborasi > proses kaku, perjalanan > snapshot sekali jadi.

### 7. Pemodelan domain modern
- **Cloud & microservices** — tiap service = trust boundary; fokus IAM, identitas mesin, metadata service. → [[Cloud Security (AWS-Azure-GCP)]].
- **Supply chain** — modelkan ancaman dari dependensi/build pipeline (SolarWinds-style): siapa bisa inject ke artefak yang kamu percaya?
- **AI/ML** — kerangka **MITRE ATLAS** (padanan ATT&CK untuk ML): data poisoning, prompt injection, model evasion, model theft.

## ⚙️ Praktik

```bash
# pytm (OWASP) — model-as-code, hasilkan DFD + laporan ancaman STRIDE
pip install pytm
# tm.py — definisikan boundary, server, datastore, dataflow lalu:
python tm.py --report template.md > threats.md   # daftar ancaman
python tm.py --dfd | dot -Tpng -o dfd.png         # render DFD (butuh graphviz)
python tm.py --seq | java -jar plantuml.jar -p > seq.png

# Threagile — model YAML → risiko + diagram
threagile -model model.yaml -output ./hasil
```

```text
# Contoh kerangka pytm (potongan)
from pytm import TM, Server, Datastore, Dataflow, Boundary, Actor
tm = TM("Login App")
inet   = Boundary("Internet")
dmz    = Boundary("DMZ")
user   = Actor("User");        user.inBoundary = inet
web    = Server("Web Server");  web.inBoundary = dmz
db     = Datastore("User DB");  db.inBoundary = dmz
Dataflow(user, web, "HTTPS login")   # melintasi trust boundary → titik fokus STRIDE
Dataflow(web, db, "SQL query")
```

## 🧰 Tools

- **OWASP pytm** — threat modeling as code (Python).
- **Threagile** — model YAML, agile/CI-friendly.
- **OWASP Threat Dragon** — diagram + STRIDE, gratis & open source.
- **Microsoft Threat Modeling Tool** — DFD + STRIDE otomatis (Windows).
- **IriusRisk** — platform enterprise (integrasi SDLC).
- **MITRE ATLAS** — basis pengetahuan ancaman sistem AI/ML.

## 🔗 Kaitan

- **Pendalaman dari:** [[Threat Modeling]] (4 pertanyaan Shostack, STRIDE dasar, DREAD/PASTA sekilas).
- **Sisi Red:** mengarahkan apa yang dicari — Insecure Design di [[Web Application Hacking (OWASP Top 10)]], jalur di [[Cyber Kill Chain & MITRE ATT&CK]], domain [[Cloud Security (AWS-Azure-GCP)]]; privasi ↔ [[OSINT Investigasi Individu (People OSINT)]].
- **Sisi Blue:** mengarahkan apa yang dilindungi → [[Defense in Depth & Security Architecture]], [[Hardening & Vulnerability Management]]; cacat desain → kontrol & [[Detection Engineering (Sigma-YARA Lanjutan)|deteksi]].
- **Bersama:** memilih aktor & skenario emulasi di [[Purple Team Lanjutan (Adversary Emulation)]]; sumber ancaman dari [[Threat Intelligence]].

## 🎯 Latihan

- Ambil satu aplikasi (mis. form login dari [[Threat Modeling|note dasar]]), gambar **DFD lengkap dengan trust boundary**, lalu jalankan **STRIDE-per-element** — buat tabel ancaman + mitigasi per elemen.
- Ulang model yang sama dengan **pytm**: tulis sistemnya sebagai kode Python, generate laporan, bandingkan temuannya dengan hasil manualmu.
- Pilih satu fitur yang mengolah data pribadi, terapkan **LINDDUN** — temukan minimal satu ancaman privasi yang luput dari STRIDE.

## 📖 Sumber

- **Threat Modeling Manifesto** — https://www.threatmodelingmanifesto.org
- **OWASP Threat Modeling Process** — https://owasp.org/www-community/Threat_Modeling_Process
- **OWASP pytm** — https://github.com/OWASP/pytm
- **LINDDUN** — https://www.linddun.org
- **MITRE ATLAS** (AI/ML) — https://atlas.mitre.org
- **PASTA** — buku *Risk Centric Threat Modeling* (Tony UcedaVélez & Marco Morana).
- Buku: *Threat Modeling: Designing for Security* — Adam Shostack.
