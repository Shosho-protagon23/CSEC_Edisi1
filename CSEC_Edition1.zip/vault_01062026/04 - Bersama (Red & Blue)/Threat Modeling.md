# 🧩 Threat Modeling

> [!summary] Ringkasan
> **Threat modeling** adalah proses berpikir terstruktur: "apa yang bisa salah?" sebelum membangun atau menyerang sistem. Berguna bagi red (memetakan serangan) maupun blue (merancang pertahanan) — jembatan natural antara keduanya.

**Bagian dari:** [[00 - START HERE]] · lintas [[Red Team (MOC)]] & [[Blue Team (MOC)]]
**Prasyarat:** [[Konsep Dasar Keamanan (CIA Triad)]]

---

## 🧠 Konsep Inti

Empat pertanyaan inti (Shostack):
1. **Apa yang sedang kita bangun?** (gambarkan sistem, aliran data).
2. **Apa yang bisa salah?** (identifikasi ancaman).
3. **Apa yang akan kita lakukan?** (mitigasi).
4. **Apakah sudah cukup baik?** (evaluasi).

### STRIDE — kerangka ancaman (Microsoft)
Tiap huruf = jenis ancaman & pilar [[Konsep Dasar Keamanan (CIA Triad)|CIA]] yang dilanggar:

| Huruf | Ancaman | Lawan dari |
|---|---|---|
| **S** | Spoofing (memalsukan identitas) | Authentication |
| **T** | Tampering (mengubah data) | Integrity |
| **R** | Repudiation (menyangkal perbuatan) | Non-repudiation |
| **I** | Information Disclosure (bocor data) | Confidentiality |
| **D** | Denial of Service | Availability |
| **E** | Elevation of Privilege | Authorization ([[Privilege Escalation]]) |

### Kerangka lain
- **DREAD** — menilai risiko (Damage, Reproducibility, dll).
- **Attack Tree** — pohon kemungkinan jalur serangan.
- **PASTA** — proses 7 tahap berbasis risiko.

> [!tip] Pendalaman
> Praktik nyata (DFD + trust boundary, STRIDE-per-element, LINDDUN/privasi, skoring objektif, threat-modeling-as-code, shift-left) ada di [[Threat Modeling Lanjutan]].

## 🔗 Kaitan

- Mengarahkan apa yang dicari red team ([[Web Application Hacking (OWASP Top 10)|Insecure Design]] = kegagalan threat modeling).
- Mengarahkan apa yang dilindungi blue team → [[Defense in Depth & Security Architecture]], [[Hardening & Vulnerability Management]].
- Inti kolaborasi [[Purple Team]].

## 🎯 Latihan

- Buat threat model sederhana untuk satu aplikasi (mis. form login): gambar alurnya, terapkan STRIDE per komponen.
- Coba tool **OWASP Threat Dragon** (gratis).

## 📖 Sumber

- **OWASP Threat Modeling** — https://owasp.org/www-community/Threat_Modeling
- **Microsoft STRIDE / Threat Modeling Tool** — https://learn.microsoft.com/azure/security/develop/threat-modeling-tool
- Buku: *Threat Modeling: Designing for Security* — Adam Shostack.
