# {{judul}}

> [!summary] Ringkasan
> *(1–2 kalimat: ini apa & kenapa penting untuk dipelajari.)*

**Bagian dari:** (pilih: Fondasi / Red Team / Blue Team MOC)
**Prasyarat:** (link ke catatan prasyarat, mis. `[[Jaringan Komputer]]`)

---

## 🧠 Konsep Inti

*(Penjelasan dari nol untuk pemula. Apa, kenapa, kapan dipakai.)*

## ⚙️ Cara Kerja / Praktik

*(Langkah-langkah. Contoh command dalam blok kode:)*

```bash
# contoh command
```

## 🧰 Tools

- **Tool A** — fungsinya.
- **Tool B** — fungsinya.

## 🔗 Kaitan

- Lanjut ke: (link catatan berikutnya)
- Sisi lawan (Red/Blue): (link catatan pasangannya)

## 🎯 Latihan

- *(Room TryHackMe / mesin HTB / lab PortSwigger yang relevan.)*

## 📖 Sumber

- *(Link tepercaya + catatan singkat kenapa berguna.)*
